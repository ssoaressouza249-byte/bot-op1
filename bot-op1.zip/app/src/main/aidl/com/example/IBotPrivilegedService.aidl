package com.example;

interface IBotPrivilegedService {
    String executeCommand(String command);
    int getUid();
    void destroy();
}
