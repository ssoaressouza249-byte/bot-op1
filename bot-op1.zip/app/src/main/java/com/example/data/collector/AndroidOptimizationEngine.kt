package com.example.data.collector

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.nfc.NfcAdapter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.data.model.GameEngineInfo
import com.example.data.model.InstalledAppItem
import com.example.data.model.NetworkLatencyInfo
import com.example.data.model.RamCleanResult
import com.example.data.model.ThermalStatusInfo
import com.example.shizuku.ShizukuBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket

data class ActionOutcome(
    val success: Boolean,
    val message: String,
    val requiresIntent: Intent? = null,
    val requiresShizuku: Boolean = false
)

class AndroidOptimizationEngine(
    private val context: Context,
    private val shizuku: ShizukuBridge
) {

    fun hasWriteSettings(): Boolean = Settings.System.canWrite(context)

    fun hasDndAccess(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        return nm?.isNotificationPolicyAccessGranted == true
    }

    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun detectNativeGameEngine(): GameEngineInfo {
        val candidates = listOf(
            "com.motorola.gamemode" to "Motorola Gametime",
            "com.motorola.games" to "Motorola Games",
            "com.samsung.android.game.gamehome" to "Samsung Game Launcher",
            "com.samsung.android.game.gametools" to "Samsung Game Booster",
            "com.miui.securitycenter" to "Xiaomi Game Turbo",
            "com.oplus.games" to "OPlus Games",
            "com.oneplus.gamespace" to "OnePlus Game Space",
            "com.coloros.gamespace" to "ColorOS Game Space",
            "com.asus.gamewidget" to "ASUS Armoury Crate"
        )
        val pm = context.packageManager
        for ((pkg, label) in candidates) {
            val launch = pm.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                return GameEngineInfo(detected = true, engineName = label, packageName = pkg)
            }
        }
        return GameEngineInfo(detected = false, engineName = "Nenhum motor nativo detectado", packageName = null)
    }

    fun launchPackage(packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun readCurrentDpi(): Int = context.resources.displayMetrics.densityDpi

    fun isDndActive(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return false
        return nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
    }

    fun isRotationLocked(): Boolean {
        return try {
            Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        } catch (_: Throwable) {
            false
        }
    }

    fun isVibrationDisabled(): Boolean {
        return try {
            Settings.System.getInt(context.contentResolver, Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) == 0
        } catch (_: Throwable) {
            false
        }
    }

    fun readLongPressTimeout(): Int? {
        return try {
            Settings.Secure.getInt(context.contentResolver, "long_press_timeout")
        } catch (_: Throwable) {
            null
        }
    }

    fun readPointerSpeed(): Int {
        return try {
            Settings.System.getInt(context.contentResolver, "pointer_speed", 0)
        } catch (_: Throwable) {
            0
        }
    }

    fun readZeroAnimationEnabled(): Boolean {
        return try {
            val w = Settings.Global.getFloat(context.contentResolver, Settings.Global.WINDOW_ANIMATION_SCALE, 1f)
            val t = Settings.Global.getFloat(context.contentResolver, Settings.Global.TRANSITION_ANIMATION_SCALE, 1f)
            val a = Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
            w == 0f && t == 0f && a == 0f
        } catch (_: Throwable) {
            false
        }
    }

    fun readCaptivePortalDisabled(): Boolean {
        return try {
            Settings.Global.getInt(context.contentResolver, "captive_portal_mode", 1) == 0
        } catch (_: Throwable) {
            false
        }
    }

    fun readTouchSensitivity(): Boolean {
        return try {
            val a = Settings.Secure.getInt(context.contentResolver, "touch_sensitivity", 0)
            val b = Settings.System.getInt(context.contentResolver, "increase_touch_sensitivity", 0)
            a == 1 || b == 1
        } catch (_: Throwable) {
            false
        }
    }

    fun readBluetoothHardwareState(): Triple<Boolean, Boolean, Boolean> {
        val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = bm?.adapter ?: return Triple(false, false, false)
        val enabled = try {
            adapter.isEnabled
        } catch (_: SecurityException) {
            false
        }
        val audioConnected = if (enabled && hasBluetoothPermission()) {
            try {
                val headset = adapter.getProfileConnectionState(BluetoothProfile.HEADSET)
                val a2dp = adapter.getProfileConnectionState(BluetoothProfile.A2DP)
                headset == BluetoothProfile.STATE_CONNECTED || a2dp == BluetoothProfile.STATE_CONNECTED
            } catch (_: SecurityException) {
                false
            }
        } else false
        return Triple(true, enabled, audioConnected)
    }

    fun readNfcHardwareState(): Pair<Boolean, Boolean> {
        val nfc = NfcAdapter.getDefaultAdapter(context) ?: return false to false
        return true to nfc.isEnabled
    }

    suspend fun setDndEnabled(enable: Boolean): ActionOutcome {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return ActionOutcome(false, "NotificationManager indisponível.")

        if (!nm.isNotificationPolicyAccessGranted) {
            return ActionOutcome(
                success = false,
                message = "Conceda acesso ao Não Perturbe nas configurações do sistema.",
                requiresIntent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            )
        }
        return try {
            nm.setInterruptionFilter(
                if (enable) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            ActionOutcome(true, if (enable) "Não Perturbe ativado durante o jogo." else "Não Perturbe restaurado.")
        } catch (t: Throwable) {
            ActionOutcome(false, "Falha ao alterar Não Perturbe: ${t.message}")
        }
    }

    suspend fun setNoPopupsEnabled(enable: Boolean): ActionOutcome {
        if (shizuku.status.value.isReady) {
            val value = if (enable) "0" else "1"
            val res = shizuku.runCommand("settings put global heads_up_notifications_enabled $value")
            if (res.success) {
                return ActionOutcome(
                    true,
                    if (enable) "Notificações flutuantes (heads-up) desativadas via Shizuku." else "Pop-ups de notificação reativados."
                )
            }
        }
        val fallbackIntent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        }
        return ActionOutcome(
            success = false,
            message = "Bloquear heads-up globalmente requer Shizuku; abrindo ajustes de notificação.",
            requiresIntent = fallbackIntent,
            requiresShizuku = true
        )
    }

    suspend fun setZeroAnimation(enable: Boolean): ActionOutcome {
        val scale = if (enable) "0" else "1"
        if (shizuku.status.value.isReady) {
            val cmd = "settings put global window_animation_scale $scale && " +
                "settings put global transition_animation_scale $scale && " +
                "settings put global animator_duration_scale $scale"
            val res = shizuku.runCommand(cmd)
            if (res.success) {
                return ActionOutcome(
                    true,
                    if (enable) "Escalas de animação definidas para 0.0x via Shizuku." else "Animações restauradas para 1.0x."
                )
            }
        }
        return ActionOutcome(
            success = false,
            message = "Zero Animação requer Shizuku ativo ou ajuste manual em Opções do Desenvolvedor.",
            requiresIntent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
            requiresShizuku = true
        )
    }

    fun setRotationLocked(lock: Boolean): ActionOutcome {
        if (!hasWriteSettings()) {
            return ActionOutcome(
                success = false,
                message = "Permita 'Modificar configurações do sistema' para travar a rotação.",
                requiresIntent = Intent(
                    Settings.ACTION_MANAGE_WRITE_SETTINGS,
                    Uri.parse("package:${context.packageName}")
                )
            )
        }
        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.ACCELEROMETER_ROTATION,
                if (lock) 0 else 1
            )
            ActionOutcome(true, if (lock) "Rotação automática travada." else "Rotação automática reativada.")
        } catch (t: Throwable) {
            ActionOutcome(false, "Erro ao alterar rotação: ${t.message}")
        }
    }

    suspend fun setNoVibration(disable: Boolean): ActionOutcome {
        var applied = false
        if (hasWriteSettings()) {
            try {
                Settings.System.putInt(
                    context.contentResolver,
                    Settings.System.HAPTIC_FEEDBACK_ENABLED,
                    if (disable) 0 else 1
                )
                applied = true
            } catch (_: Throwable) {
            }
        }
        if (shizuku.status.value.isReady) {
            val v = if (disable) "0" else "1"
            val res = shizuku.runCommand(
                "settings put system haptic_feedback_enabled $v && settings put system vibrate_when_ringing $v"
            )
            if (res.success) applied = true
        }
        if (applied) {
            return ActionOutcome(
                true,
                if (disable) "Resposta tátil/vibração desativada." else "Vibração do sistema restaurada."
            )
        }
        return ActionOutcome(
            success = false,
            message = "Permita 'Modificar configurações do sistema' para controlar vibração.",
            requiresIntent = Intent(
                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:${context.packageName}")
            )
        )
    }

    fun readCurrentScreenBrightness(): Pair<Int, Int>? {
        return try {
            val mode = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE)
            val level = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            mode to level
        } catch (_: Throwable) {
            null
        }
    }

    fun applyThermalBrightnessReduction(reduce: Boolean, restoreMode: Int? = null, restoreLevel: Int? = null): Boolean {
        if (!hasWriteSettings()) return false
        return try {
            if (reduce) {
                Settings.System.putInt(
                    context.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 75)
            } else if (restoreMode != null && restoreLevel != null) {
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, restoreMode)
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, restoreLevel)
            }
            true
        } catch (_: Throwable) {
            false
        }
    }

    suspend fun applyCustomDpi(dpi: Int): ActionOutcome {
        if (!shizuku.status.value.isReady) {
            return ActionOutcome(
                success = false,
                message = "Alterar DPI (wm density) requer Shizuku ativo ou Opções do Desenvolvedor.",
                requiresIntent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
                requiresShizuku = true
            )
        }
        val clamped = dpi.coerceIn(280, 550)
        val res = shizuku.runCommand("wm density $clamped")
        return if (res.success) {
            ActionOutcome(true, "DPI alterado para $clamped via Shizuku. Confirme em até 15s.")
        } else {
            ActionOutcome(false, "Falha ao executar wm density: ${res.output}")
        }
    }

    suspend fun resetDpi(): ActionOutcome {
        if (!shizuku.status.value.isReady) {
            return ActionOutcome(false, "Shizuku inativo.", requiresShizuku = true)
        }
        val res = shizuku.runCommand("wm density reset")
        return if (res.success) {
            ActionOutcome(true, "DPI restaurado para o padrão original do dispositivo.")
        } else {
            ActionOutcome(false, "Falha ao resetar DPI: ${res.output}")
        }
    }

    suspend fun setLongPressTimeout(ms: Int?): ActionOutcome {
        val targetMs = ms ?: 400
        if (shizuku.status.value.isReady) {
            val res = shizuku.runCommand("settings put secure long_press_timeout $targetMs")
            if (res.success) {
                return ActionOutcome(
                    true,
                    if (ms == null) "Tempo de toque longo restaurado ($targetMs ms)." else "Toque longo definido para ${targetMs}ms."
                )
            }
        }
        return ActionOutcome(
            success = false,
            message = "Ajustar long_press_timeout requer Shizuku; abrindo Acessibilidade.",
            requiresIntent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
            requiresShizuku = true
        )
    }

    suspend fun setPointerSpeed(speed: Int): ActionOutcome {
        val clamped = speed.coerceIn(-7, 7)
        if (shizuku.status.value.isReady) {
            val res = shizuku.runCommand("settings put system pointer_speed $clamped")
            if (res.success) {
                return ActionOutcome(true, "Velocidade do ponteiro definida para $clamped via Shizuku.")
            }
        }
        if (hasWriteSettings()) {
            try {
                Settings.System.putInt(context.contentResolver, "pointer_speed", clamped)
                return ActionOutcome(true, "Velocidade do ponteiro aplicada ($clamped).")
            } catch (_: Throwable) {
            }
        }
        return ActionOutcome(
            success = false,
            message = "Ajustar pointer_speed requer Shizuku ou permissão de sistema.",
            requiresIntent = Intent(
                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:${context.packageName}")
            ),
            requiresShizuku = true
        )
    }

    suspend fun setTouchSensitivity(enable: Boolean): ActionOutcome {
        val v = if (enable) "1" else "0"
        if (shizuku.status.value.isReady) {
            val res = shizuku.runCommand(
                "settings put secure touch_sensitivity $v; settings put system increase_touch_sensitivity $v"
            )
            if (res.success) {
                return ActionOutcome(
                    true,
                    if (enable) "Sensibilidade aumentada de toque ativada." else "Sensibilidade padrão restaurada."
                )
            }
        }
        return ActionOutcome(
            success = false,
            message = "Modo Toque Sensível requer Shizuku ou ativação nas configurações de Tela.",
            requiresIntent = Intent(Settings.ACTION_DISPLAY_SETTINGS),
            requiresShizuku = true
        )
    }

    suspend fun setCaptivePortalDisabled(disable: Boolean): ActionOutcome {
        if (!shizuku.status.value.isReady) {
            return ActionOutcome(
                success = false,
                message = "Alterar captive_portal_mode requer Shizuku ativo.",
                requiresShizuku = true
            )
        }
        val mode = if (disable) "0" else "1"
        val res = shizuku.runCommand("settings put global captive_portal_mode $mode")
        return if (res.success) {
            ActionOutcome(
                true,
                if (disable) "Verificação de Captive Portal desativada (modo 0)." else "Captive Portal reativado."
            )
        } else {
            ActionOutcome(false, "Erro Shizuku: ${res.output}")
        }
    }

    suspend fun toggleBackgroundDataSaver(enable: Boolean): ActionOutcome {
        if (shizuku.status.value.isReady) {
            val cmd = "cmd netpolicy set restrict-background ${if (enable) "true" else "false"}"
            val res = shizuku.runCommand(cmd)
            if (res.success) {
                return ActionOutcome(
                    true,
                    if (enable) "Economia de dados em segundo plano ativada via netpolicy." else "Economia de dados desativada."
                )
            }
        }
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Intent(
                Settings.ACTION_IGNORE_BACKGROUND_DATA_RESTRICTIONS_SETTINGS,
                Uri.parse("package:${context.packageName}")
            )
        } else {
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        }
        return ActionOutcome(
            success = false,
            message = "Controle global de dados em segundo plano requer Shizuku; abrindo painel nativo.",
            requiresIntent = intent,
            requiresShizuku = true
        )
    }

    @Suppress("DEPRECATION")
    suspend fun disableBluetoothIfNoAudio(): ActionOutcome {
        val (hasHw, isEnabled, audioConnected) = readBluetoothHardwareState()
        if (!hasHw) {
            return ActionOutcome(false, "Indisponível — este dispositivo não possui hardware Bluetooth.")
        }
        if (audioConnected) {
            return ActionOutcome(false, "Fone/áudio Bluetooth conectado! Rádio mantido ativo para não cortar seu som.")
        }
        if (!isEnabled) {
            return ActionOutcome(true, "Bluetooth já está desligado.")
        }
        if (shizuku.status.value.isReady) {
            val res = shizuku.runCommand("svc bluetooth disable")
            if (res.success) {
                return ActionOutcome(true, "Bluetooth desligado via Shizuku (nenhum áudio conectado).")
            }
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU && hasBluetoothPermission()) {
            val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            if (bm?.adapter?.disable() == true) {
                return ActionOutcome(true, "Bluetooth desligado para economizar bateria/rádio.")
            }
        }
        return ActionOutcome(
            success = false,
            message = "No Android 13+, desligar Bluetooth sem Shizuku abre o painel rápido.",
            requiresIntent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS),
            requiresShizuku = true
        )
    }

    suspend fun toggleNfc(enable: Boolean): ActionOutcome {
        val (hasHw, _) = readNfcHardwareState()
        if (!hasHw) {
            return ActionOutcome(false, "Indisponível — Seu aparelho não possui chip NFC.")
        }
        if (shizuku.status.value.isReady) {
            val res = shizuku.runCommand("svc nfc ${if (enable) "enable" else "disable"}")
            if (res.success) {
                return ActionOutcome(true, if (enable) "NFC ativado via Shizuku." else "NFC desligado via Shizuku.")
            }
        }
        return ActionOutcome(
            success = false,
            message = "Controle direto de NFC requer Shizuku; abrindo configurações NFC.",
            requiresIntent = Intent(Settings.ACTION_NFC_SETTINGS),
            requiresShizuku = true
        )
    }

    suspend fun measureNetworkLatency(): NetworkLatencyInfo = withContext(Dispatchers.IO) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNet = cm?.activeNetwork
        val caps = cm?.getNetworkCapabilities(activeNet)

        val transport = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Dados Móveis"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "Conectado"
        }
        val downstreamKbps = caps?.linkDownstreamBandwidthKbps?.takeIf { it > 0 }
        val saverStatus = when (cm?.restrictBackgroundStatus) {
            ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED -> "Economia Ativa"
            ConnectivityManager.RESTRICT_BACKGROUND_STATUS_WHITELISTED -> "Permitido (Lista)"
            ConnectivityManager.RESTRICT_BACKGROUND_STATUS_DISABLED -> "Desativada"
            else -> "Desconhecido"
        }

        if (caps == null) {
            return@withContext NetworkLatencyInfo(
                pingMs = null,
                transportLabel = "Offline",
                downstreamKbps = null,
                dataSaverStatusLabel = saverStatus
            )
        }

        val host = "1.1.1.1"
        val port = 53
        val pingMs = try {
            val socket = Socket()
            val startNs = System.nanoTime()
            socket.connect(InetSocketAddress(host, port), 2000)
            val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
            socket.close()
            elapsedMs
        } catch (_: Throwable) {
            null
        }

        NetworkLatencyInfo(
            pingMs = pingMs,
            hostTested = "$host:$port",
            transportLabel = transport,
            downstreamKbps = downstreamKbps,
            dataSaverStatusLabel = saverStatus
        )
    }

    fun collectThermalStatus(): ThermalStatusInfo {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val tempC = if (rawTemp > 0) rawTemp / 10f else null

        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isPowerSave = pm?.isPowerSaveMode == true

        val (thermalLabel, throttling) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && pm != null) {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal (Sem estrangulamento)" to false
                PowerManager.THERMAL_STATUS_LIGHT -> "Aquecimento Leve" to false
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderado (Possível throttling)" to true
                PowerManager.THERMAL_STATUS_SEVERE -> "Severo (Throttling ativo)" to true
                PowerManager.THERMAL_STATUS_CRITICAL -> "Crítico (Redução máxima)" to true
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergência Térmica" to true
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Desligamento Iminente" to true
                else -> "Normal" to false
            }
        } else {
            val highTemp = (tempC ?: 0f) > 39f
            (if (highTemp) "Acima de 39°C" else "Normal") to highTemp
        }

        return ThermalStatusInfo(
            temperatureC = tempC,
            thermalStatusLabel = thermalLabel,
            isThermalThrottling = throttling,
            isPowerSaveMode = isPowerSave
        )
    }

    @SuppressLint("QueryPermissionsNeeded")
    suspend fun cleanRamAndCache(): RamCleanResult = withContext(Dispatchers.IO) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val beforeMem = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(beforeMem)

        val pm = context.packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launchIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launchIntent, 0)
        }

        var killedAttempts = 0
        val selfPkg = context.packageName
        resolved.mapNotNull { it.activityInfo?.packageName }
            .distinct()
            .filter { it != selfPkg }
            .forEach { pkg ->
                try {
                    am?.killBackgroundProcesses(pkg)
                    killedAttempts++
                } catch (_: Throwable) {
                }
            }

        val cacheBytesBefore = dirSize(context.cacheDir)
        clearDirectoryContents(context.cacheDir)
        val cacheBytesAfter = dirSize(context.cacheDir)
        val cacheCleared = (cacheBytesBefore - cacheBytesAfter).coerceAtLeast(0L)

        System.gc()
        Thread.sleep(220)

        val afterMem = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(afterMem)

        RamCleanResult(
            availableBeforeBytes = beforeMem.availMem,
            availableAfterBytes = afterMem.availMem,
            processesKilledHint = killedAttempts,
            cacheClearedBytes = cacheCleared,
            timestampMs = System.currentTimeMillis()
        )
    }

    suspend fun loadInstalledApps(): List<InstalledAppItem> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launchIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launchIntent, 0)
        }

        val selfPkg = context.packageName
        resolved.mapNotNull { info ->
            val appInfo = info.activityInfo?.applicationInfo ?: return@mapNotNull null
            val pkg = appInfo.packageName
            if (pkg == selfPkg) return@mapNotNull null
            val isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            InstalledAppItem(
                appName = pm.getApplicationLabel(appInfo).toString(),
                packageName = pkg,
                isEnabled = appInfo.enabled,
                isSystemApp = isSys
            )
        }
            .distinctBy { it.packageName }
            .sortedWith(compareBy<InstalledAppItem> { it.isSystemApp }.thenBy { it.appName.lowercase() })
    }

    suspend fun forceStopApp(packageName: String): ActionOutcome {
        if (shizuku.status.value.isReady) {
            val res = shizuku.runCommand("am force-stop $packageName")
            if (res.success) {
                return ActionOutcome(true, "Processo encerrado (am force-stop $packageName).")
            }
        }
        val detailsIntent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$packageName")
        )
        return ActionOutcome(
            success = false,
            message = "Forçar parada direto requer Shizuku; abrindo página do aplicativo.",
            requiresIntent = detailsIntent,
            requiresShizuku = true
        )
    }

    suspend fun setAppFrozen(packageName: String, freeze: Boolean): ActionOutcome {
        if (!shizuku.status.value.isReady) {
            val detailsIntent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")
            )
            return ActionOutcome(
                success = false,
                message = "Congelar/descongelar pacotes (pm disable-user) requer Shizuku; abrindo detalhes do app.",
                requiresIntent = detailsIntent,
                requiresShizuku = true
            )
        }
        val cmd = if (freeze) "pm disable-user --user 0 $packageName" else "pm enable $packageName"
        val res = shizuku.runCommand(cmd)
        return if (res.success) {
            ActionOutcome(
                true,
                if (freeze) "App congelado via Shizuku ($packageName)." else "App descongelado ($packageName)."
            )
        } else {
            ActionOutcome(false, "Erro ao alterar estado do pacote: ${res.output}")
        }
    }

    private fun dirSize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var sum = 0L
        dir.listFiles()?.forEach { child ->
            sum += if (child.isDirectory) dirSize(child) else child.length()
        }
        return sum
    }

    private fun clearDirectoryContents(dir: File?) {
        if (dir == null || !dir.exists()) return
        dir.listFiles()?.forEach { child ->
            if (child.isDirectory) clearDirectoryContents(child)
            child.delete()
        }
    }
}
