package com.example.data.collector

import android.app.ActivityManager
import android.content.Context
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import com.example.data.model.DataAvailability
import com.example.data.model.GpuInfo
import java.nio.IntBuffer

object EglGpuProbe {

    fun probe(context: Context): GpuInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val sysGlVersion = try {
            am?.deviceConfigurationInfo?.glEsVersion ?: "Desconhecido"
        } catch (_: Exception) {
            "Desconhecido"
        }

        var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
        var surface: EGLSurface = EGL14.EGL_NO_SURFACE
        var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT

        return try {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (display == EGL14.EGL_NO_DISPLAY) {
                return GpuInfo(
                    glEsSystemVersion = sysGlVersion,
                    availability = DataAvailability.PARTIAL,
                    errorNote = "Display EGL padrão indisponível neste dispositivo."
                )
            }

            val version = IntArray(2)
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) {
                return GpuInfo(
                    glEsSystemVersion = sysGlVersion,
                    availability = DataAvailability.PARTIAL,
                    errorNote = "Falha ao inicializar EGL14."
                )
            }

            val configAttribs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_NONE
            )

            val configs = arrayOfNulls<EGLConfig>(1)
            val numConfig = IntArray(1)
            if (!EGL14.eglChooseConfig(display, configAttribs, 0, configs, 0, 1, numConfig, 0) ||
                numConfig[0] == 0 ||
                configs[0] == null
            ) {
                return GpuInfo(
                    glEsSystemVersion = sysGlVersion,
                    availability = DataAvailability.PARTIAL,
                    errorNote = "Nenhuma configuração EGL OpenGL ES 2.0+ encontrada."
                )
            }

            val config = configs[0]!!
            val contextAttribs = intArrayOf(
                EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
                EGL14.EGL_NONE
            )
            eglContext = EGL14.eglCreateContext(
                display,
                config,
                EGL14.EGL_NO_CONTEXT,
                contextAttribs,
                0
            )
            if (eglContext == EGL14.EGL_NO_CONTEXT) {
                return GpuInfo(
                    glEsSystemVersion = sysGlVersion,
                    availability = DataAvailability.PARTIAL,
                    errorNote = "Não foi possível criar contexto EGL."
                )
            }

            val surfaceAttribs = intArrayOf(
                EGL14.EGL_WIDTH, 1,
                EGL14.EGL_HEIGHT, 1,
                EGL14.EGL_NONE
            )
            surface = EGL14.eglCreatePbufferSurface(display, config, surfaceAttribs, 0)
            if (surface == EGL14.EGL_NO_SURFACE) {
                return GpuInfo(
                    glEsSystemVersion = sysGlVersion,
                    availability = DataAvailability.PARTIAL,
                    errorNote = "Falha ao criar Pbuffer EGL."
                )
            }

            if (!EGL14.eglMakeCurrent(display, surface, surface, eglContext)) {
                return GpuInfo(
                    glEsSystemVersion = sysGlVersion,
                    availability = DataAvailability.PARTIAL,
                    errorNote = "Falha ao ativar contexto OpenGL ES."
                )
            }

            val renderer = GLES20.glGetString(GLES20.GL_RENDERER)?.takeIf { it.isNotBlank() }
            val vendor = GLES20.glGetString(GLES20.GL_VENDOR)?.takeIf { it.isNotBlank() }
            val glVersion = GLES20.glGetString(GLES20.GL_VERSION)?.takeIf { it.isNotBlank() }
            val glslVersion = GLES20.glGetString(GLES20.GL_SHADING_LANGUAGE_VERSION)?.takeIf { it.isNotBlank() }
            val rawExtensions = GLES20.glGetString(GLES20.GL_EXTENSIONS).orEmpty()
            val extensionsList = rawExtensions
                .split(' ')
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .sorted()

            val maxTexBuf = IntBuffer.allocate(1)
            GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, maxTexBuf)
            val maxTextureSize = maxTexBuf.get(0).takeIf { it > 0 }

            val viewportBuf = IntBuffer.allocate(2)
            GLES20.glGetIntegerv(GLES20.GL_MAX_VIEWPORT_DIMS, viewportBuf)
            val maxVpW = viewportBuf.get(0).takeIf { it > 0 }
            val maxVpH = viewportBuf.get(1).takeIf { it > 0 }

            val vertexBuf = IntBuffer.allocate(1)
            GLES20.glGetIntegerv(GLES20.GL_MAX_VERTEX_ATTRIBS, vertexBuf)
            val maxVertexAttribs = vertexBuf.get(0).takeIf { it > 0 }

            GpuInfo(
                glEsSystemVersion = sysGlVersion,
                renderer = renderer,
                vendor = vendor,
                glVersion = glVersion,
                glslVersion = glslVersion,
                maxTextureSize = maxTextureSize,
                maxViewportWidth = maxVpW,
                maxViewportHeight = maxVpH,
                maxVertexAttribs = maxVertexAttribs,
                extensions = extensionsList,
                availability = if (renderer != null) DataAvailability.AVAILABLE else DataAvailability.PARTIAL
            )
        } catch (t: Throwable) {
            GpuInfo(
                glEsSystemVersion = sysGlVersion,
                availability = DataAvailability.PARTIAL,
                errorNote = "Sonda EGL/OpenGL indisponível: ${t.message ?: "Erro desconhecido"}"
            )
        } finally {
            try {
                if (display != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(
                        display,
                        EGL14.EGL_NO_SURFACE,
                        EGL14.EGL_NO_SURFACE,
                        EGL14.EGL_NO_CONTEXT
                    )
                    if (surface != EGL14.EGL_NO_SURFACE) {
                        EGL14.eglDestroySurface(display, surface)
                    }
                    if (eglContext != EGL14.EGL_NO_CONTEXT) {
                        EGL14.eglDestroyContext(display, eglContext)
                    }
                    EGL14.eglTerminate(display)
                }
            } catch (_: Exception) {
            }
        }
    }
}
