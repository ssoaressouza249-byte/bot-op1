package com.example.data.collector

import com.example.data.model.BatteryInfo
import com.example.data.model.CpuInfo
import com.example.data.model.DataAvailability
import com.example.data.model.DeviceFullInfo
import com.example.data.model.DiagnosticCheckItem
import com.example.data.model.DiagnosticReport
import com.example.data.model.DiagnosticStatus
import com.example.data.model.DisplayInfo
import com.example.data.model.GpuInfo
import com.example.data.model.RamInfo
import com.example.data.model.StorageInfo
import com.example.util.Formatters

object SystemDiagnosticEngine {

    fun analyze(
        ram: RamInfo,
        cpu: CpuInfo,
        gpu: GpuInfo,
        storage: StorageInfo,
        battery: BatteryInfo,
        display: DisplayInfo,
        device: DeviceFullInfo
    ): DiagnosticReport {
        val checks = mutableListOf<DiagnosticCheckItem>()
        val missingNotes = mutableListOf<String>()

        // 1. RAM Analysis
        val ramStatus = when {
            ram.availability == DataAvailability.UNAVAILABLE -> DiagnosticStatus.RESTRICTED
            ram.isLowMemory || ram.usedPercent > 0.90f -> DiagnosticStatus.WARNING
            else -> DiagnosticStatus.OK
        }
        checks += DiagnosticCheckItem(
            id = "ram",
            title = "Memória Física (RAM)",
            subsystem = "RAM ANALYZER",
            status = ramStatus,
            summary = if (ram.totalBytes > 0) {
                "${Formatters.formatBytes(ram.availableBytes)} livres de ${Formatters.formatBytes(ram.totalBytes)} (${Formatters.formatPercent(ram.usedPercent)} em uso)"
            } else {
                "Leitura indisponível"
            },
            detail = "Classe de heap do app: ${ram.memoryClassMb} MB (Large: ${ram.largeMemoryClassMb} MB). Alerta de baixa memória: ${if (ram.isLowMemory) "ATIVO" else "Inativo"}.",
            recommendation = when (ramStatus) {
                DiagnosticStatus.WARNING -> "Pressão de memória elevada detectada. Feche aplicativos pesados em segundo plano para melhorar a fluidez."
                DiagnosticStatus.RESTRICTED -> "Não foi possível consultar o ActivityManager neste ambiente."
                else -> "Margem de memória saudável para multitarefa e renderização."
            }
        )

        // 2. CPU & ABI Compatibility
        val is64Bit = cpu.supportedAbis.any { it.contains("64") }
        val cpuStatus = when {
            !cpu.systemStatAccessible && cpu.coreFreqAccessibleCount == 0 -> DiagnosticStatus.RESTRICTED
            cpu.logicalProcessors >= 4 && is64Bit -> DiagnosticStatus.OK
            else -> DiagnosticStatus.WARNING
        }
        if (!cpu.systemStatAccessible) {
            missingNotes += "Carga global de CPU (/proc/stat) bloqueada pela política SELinux do Android."
        }
        if (cpu.coreFreqAccessibleCount == 0) {
            missingNotes += "Frequências por núcleo (/sys/devices/system/cpu) restritas pelo kernel."
        }
        checks += DiagnosticCheckItem(
            id = "cpu",
            title = "Processador & Arquitetura",
            subsystem = "CPU ANALYZER",
            status = cpuStatus,
            summary = "${cpu.logicalProcessors} núcleos lógicos • ABI ${cpu.primaryAbi}",
            detail = "Hardware: ${cpu.hardware} | SoC: ${cpu.socModel ?: cpu.cpuModelName ?: "Não exposto pelo OS"}. Frequências acessíveis: ${cpu.coreFreqAccessibleCount}/${cpu.logicalProcessors}.",
            recommendation = if (cpuStatus == DiagnosticStatus.RESTRICTED) {
                "Arquitetura ${if (is64Bit) "64-bit" else "32-bit"} compatível, mas métricas de clock do kernel estão protegidas pelo SELinux (comportamento padrão em Android moderno)."
            } else {
                "Processador compatível com instruções modernas (${cpu.supportedAbis.joinToString()})."
            }
        )

        // 3. GPU & OpenGL ES
        val gpuStatus = when {
            gpu.availability == DataAvailability.AVAILABLE && gpu.renderer != null -> DiagnosticStatus.OK
            gpu.availability == DataAvailability.PARTIAL -> DiagnosticStatus.WARNING
            else -> DiagnosticStatus.RESTRICTED
        }
        if (gpu.renderer == null) {
            missingNotes += "Nome exato do renderizador OpenGL ES indisponível via contexto EGL."
        }
        checks += DiagnosticCheckItem(
            id = "gpu",
            title = "Aceleração Gráfica (GPU)",
            subsystem = "GPU INFO",
            status = gpuStatus,
            summary = gpu.renderer ?: "OpenGL ES ${gpu.glEsSystemVersion}",
            detail = "Fabricante: ${gpu.vendor ?: "Desconhecido"} • Versão: ${gpu.glVersion ?: gpu.glEsSystemVersion} • Extensões: ${gpu.extensions.size}.",
            recommendation = if (gpuStatus == DiagnosticStatus.OK) {
                "Pipeline OpenGL ES operacional com suporte a texturas até ${gpu.maxTextureSize ?: 0}px."
            } else {
                "Verifique drivers gráficos ou suporte EGL do dispositivo."
            }
        )

        // 4. Storage Partition
        val storageStatus = when {
            storage.availability == DataAvailability.UNAVAILABLE -> DiagnosticStatus.RESTRICTED
            storage.internalUsedPercent >= 0.90f -> DiagnosticStatus.CRITICAL
            storage.internalUsedPercent >= 0.80f -> DiagnosticStatus.WARNING
            else -> DiagnosticStatus.OK
        }
        checks += DiagnosticCheckItem(
            id = "storage",
            title = "Armazenamento Interno (/data)",
            subsystem = "STORAGE",
            status = storageStatus,
            summary = "${Formatters.formatBytes(storage.internalAvailableBytes)} disponíveis de ${Formatters.formatBytes(storage.internalTotalBytes)}",
            detail = "Uso interno: ${Formatters.formatPercent(storage.internalUsedPercent)}. Sandbox deste app: ${Formatters.formatBytes(storage.appTotalUsedBytes)}.",
            recommendation = when (storageStatus) {
                DiagnosticStatus.CRITICAL -> "Armazenamento quase esgotado (>90%). Libere espaço urgentemente para evitar lentidão e falhas de atualização."
                DiagnosticStatus.WARNING -> "Armazenamento acima de 80%. Considere limpar caches e arquivos temporários."
                DiagnosticStatus.RESTRICTED -> "Partição de armazenamento inacessível."
                else -> "Espaço livre adequado na partição de dados do usuário."
            }
        )

        // 5. Battery Telemetry
        val batteryLevel = battery.levelPercent
        val batteryStatus = when {
            battery.availability == DataAvailability.UNAVAILABLE || batteryLevel == null -> DiagnosticStatus.RESTRICTED
            batteryLevel <= 15 && !battery.isCharging -> DiagnosticStatus.WARNING
            else -> DiagnosticStatus.OK
        }
        if (battery.temperatureC == null) {
            missingNotes += "Sensor de temperatura da bateria não reportado pelo controlador."
        }
        if (battery.chargeTimeRemainingMs == null && battery.isCharging) {
            missingNotes += "Tempo estimado de recarga indisponível no BatteryManager."
        }
        checks += DiagnosticCheckItem(
            id = "battery",
            title = "Energia & Bateria",
            subsystem = "BATTERY",
            status = batteryStatus,
            summary = if (batteryLevel != null) "$batteryLevel% • ${battery.statusLabel} (${battery.pluggedSourceLabel})" else "Sem telemetria",
            detail = "Tecnologia: ${battery.technology ?: "Indisponível"} • Tensão: ${battery.voltageMv?.let { "${it} mV" } ?: "Indisponível"} • Temp: ${battery.temperatureC?.let { "$it °C" } ?: "Indisponível"}.",
            recommendation = when (batteryStatus) {
                DiagnosticStatus.WARNING -> "Nível crítico de bateria (≤15%). Conecte a um carregador compatível."
                DiagnosticStatus.RESTRICTED -> "Serviço de bateria não forneceu leitura."
                else -> "Monitoramento de energia operando dentro dos parâmetros reportados pelo Android."
            }
        )

        // 6. Display & Graphics
        val displayStatus = if (display.widthPx > 0 && display.heightPx > 0) DiagnosticStatus.OK else DiagnosticStatus.WARNING
        checks += DiagnosticCheckItem(
            id = "display",
            title = "Tela & Renderização",
            subsystem = "DISPLAY",
            status = displayStatus,
            summary = "${display.widthPx}×${display.heightPx} px • ${display.refreshRateHz.toInt()} Hz",
            detail = "Densidade: ${display.densityDpi} dpi (${display.densityBucket}) • Wide Color: ${if (display.isWideColorGamut) "Sim" else "Não"} • HDR: ${if (display.hdrCapabilities.isEmpty()) "Padrão SDR" else display.hdrCapabilities.joinToString()}.",
            recommendation = "Resolução e densidade detectadas corretamente para escalonamento adaptativo."
        )

        // 7. OS & Sensors
        val osStatus = if (device.sdkInt >= 26) DiagnosticStatus.OK else DiagnosticStatus.WARNING
        checks += DiagnosticCheckItem(
            id = "os",
            title = "Plataforma Android & Sensores",
            subsystem = "DEVICE INFO",
            status = osStatus,
            summary = "Android ${device.androidVersion} (API ${device.sdkInt}) • ${device.sensors.size} sensores",
            detail = "Patch de segurança: ${device.securityPatch ?: "Não informado"} • Rede: ${device.networkStatus} (${device.networkTransport}).",
            recommendation = if (device.sdkInt >= 29) {
                "Versão moderna do Android com suporte completo a APIs de métricas e segurança."
            } else {
                "Dispositivo em API mais antiga; algumas métricas recentes (ex. estimativa de carga API 28+) podem não existir."
            }
        )

        val okCount = checks.count { it.status == DiagnosticStatus.OK }
        val warningCount = checks.count { it.status == DiagnosticStatus.WARNING || it.status == DiagnosticStatus.CRITICAL }
        val restrictedCount = checks.count { it.status == DiagnosticStatus.RESTRICTED }

        val rawScore = checks.sumOf {
            when (it.status) {
                DiagnosticStatus.OK -> 100
                DiagnosticStatus.RESTRICTED -> 75
                DiagnosticStatus.WARNING -> 55
                DiagnosticStatus.CRITICAL -> 25
            }
        }
        val scorePercent = if (checks.isNotEmpty()) (rawScore / checks.size).coerceIn(0, 100) else 0

        val overall = when {
            checks.any { it.status == DiagnosticStatus.CRITICAL } -> DiagnosticStatus.CRITICAL
            warningCount > 0 -> DiagnosticStatus.WARNING
            restrictedCount > 2 -> DiagnosticStatus.RESTRICTED
            else -> DiagnosticStatus.OK
        }

        return DiagnosticReport(
            timestampMs = System.currentTimeMillis(),
            scorePercent = scorePercent,
            overallStatus = overall,
            okCount = okCount,
            warningCount = warningCount,
            restrictedCount = restrictedCount,
            missingDataNotes = missingNotes,
            checks = checks
        )
    }
}
