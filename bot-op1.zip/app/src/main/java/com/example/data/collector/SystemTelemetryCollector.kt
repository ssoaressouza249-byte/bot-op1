package com.example.data.collector

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.os.storage.StorageManager
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import com.example.data.model.BatteryInfo
import com.example.data.model.CpuCoreInfo
import com.example.data.model.CpuInfo
import com.example.data.model.DataAvailability
import com.example.data.model.DeviceFullInfo
import com.example.data.model.DisplayInfo
import com.example.data.model.GpuInfo
import com.example.data.model.RamInfo
import com.example.data.model.SensorSummary
import com.example.data.model.StorageInfo
import java.io.File
import kotlin.math.pow
import kotlin.math.sqrt

class SystemTelemetryCollector(private val context: Context) {

    private var prevProcessCpuMs: Long = Process.getElapsedCpuTime()
    private var prevWallTimeMs: Long = SystemClock.elapsedRealtime()
    private var cachedGpuInfo: GpuInfo? = null

    fun collectRam(): RamInfo {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)

            val runtime = Runtime.getRuntime()
            val jvmUsed = (runtime.totalMemory() - runtime.freeMemory()).coerceAtLeast(0L)
            val jvmMax = runtime.maxMemory().coerceAtLeast(0L)
            val nativeAllocated = Debug.getNativeHeapAllocatedSize().coerceAtLeast(0L)

            val totalBytes = memInfo.totalMem.coerceAtLeast(0L)
            val availableBytes = memInfo.availMem.coerceAtLeast(0L)
            val availability = if (totalBytes > 0L) {
                DataAvailability.AVAILABLE
            } else {
                DataAvailability.PARTIAL
            }

            RamInfo(
                totalBytes = totalBytes,
                availableBytes = availableBytes,
                lowMemoryThresholdBytes = memInfo.threshold,
                isLowMemory = memInfo.lowMemory,
                memoryClassMb = am?.memoryClass ?: 0,
                largeMemoryClassMb = am?.largeMemoryClass ?: 0,
                jvmUsedBytes = jvmUsed,
                jvmMaxBytes = jvmMax,
                nativeHeapAllocatedBytes = nativeAllocated,
                availability = availability,
                limitationNote = "ActivityManager reporta RAM física total e memória disponível ao sistema; " +
                    "buffers de cache do kernel e processos em segundo plano podem variar a disponibilidade instantânea."
            )
        } catch (_: Exception) {
            RamInfo(
                availability = DataAvailability.UNAVAILABLE,
                limitationNote = "Não foi possível consultar ActivityManager.MemoryInfo."
            )
        }
    }

    fun collectCpu(): CpuInfo {
        val logicalCores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val abis = Build.SUPPORTED_ABIS?.toList().orEmpty()
        val primaryAbi = abis.firstOrNull() ?: "Desconhecido"
        val osArch = System.getProperty("os.arch") ?: "Desconhecido"

        val socManufacturer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MANUFACTURER.takeIf { it != Build.UNKNOWN && it.isNotBlank() }
        } else null

        val socModel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MODEL.takeIf { it != Build.UNKNOWN && it.isNotBlank() }
        } else null

        var cpuModelName: String? = null
        var cpuFeatures: String? = null
        try {
            val cpuInfoFile = File("/proc/cpuinfo")
            if (cpuInfoFile.canRead()) {
                cpuInfoFile.useLines { lines ->
                    lines.forEach { line ->
                        val parts = line.split(":", limit = 2)
                        if (parts.size == 2) {
                            val key = parts[0].trim().lowercase()
                            val value = parts[1].trim()
                            when {
                                (key == "hardware" || key == "model name" || key == "processor") &&
                                    cpuModelName == null && value.isNotEmpty() && !value.all { it.isDigit() } -> {
                                    cpuModelName = value
                                }
                                (key == "features" || key == "flags") && cpuFeatures == null && value.isNotEmpty() -> {
                                    cpuFeatures = value
                                }
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }

        val cores = (0 until logicalCores).map { index ->
            val cur = readSysLong("/sys/devices/system/cpu/cpu$index/cpufreq/scaling_cur_freq")
            val min = readSysLong("/sys/devices/system/cpu/cpu$index/cpufreq/cpuinfo_min_freq")
            val max = readSysLong("/sys/devices/system/cpu/cpu$index/cpufreq/cpuinfo_max_freq")
            CpuCoreInfo(index, cur, min, max)
        }
        val freqAccessibleCount = cores.count { it.currentFreqKhz != null || it.maxFreqKhz != null }

        val systemStatAccessible = try {
            val statFile = File("/proc/stat")
            statFile.exists() && statFile.canRead() && statFile.readLines().isNotEmpty()
        } catch (_: Exception) {
            false
        }

        val nowWallMs = SystemClock.elapsedRealtime()
        val nowCpuMs = Process.getElapsedCpuTime()
        val wallDelta = (nowWallMs - prevWallTimeMs).coerceAtLeast(1L)
        val cpuDelta = (nowCpuMs - prevProcessCpuMs).coerceAtLeast(0L)
        val processCpuPercent = if (wallDelta >= 200L) {
            prevWallTimeMs = nowWallMs
            prevProcessCpuMs = nowCpuMs
            ((cpuDelta.toFloat() / (wallDelta.toFloat() * logicalCores)) * 100f).coerceIn(0f, 100f)
        } else {
            null
        }

        val availability = when {
            freqAccessibleCount == logicalCores && systemStatAccessible -> DataAvailability.AVAILABLE
            freqAccessibleCount > 0 || cpuModelName != null -> DataAvailability.PARTIAL
            else -> DataAvailability.PARTIAL
        }

        val limitation = buildString {
            if (!systemStatAccessible) {
                append("No Android 8+, o SELinux restringe a leitura global de /proc/stat por apps de terceiros. ")
            }
            if (freqAccessibleCount < logicalCores) {
                append("Frequências individuais de núcleo (/sys/devices/system/cpu/) estão parcial ou totalmente restritas pelo kernel. ")
            }
            append("O gráfico exibe apenas o tempo de CPU medido do processo atual.")
        }

        return CpuInfo(
            logicalProcessors = logicalCores,
            primaryAbi = primaryAbi,
            supportedAbis = abis,
            osArch = osArch,
            hardware = Build.HARDWARE ?: "Desconhecido",
            board = Build.BOARD ?: "Desconhecido",
            socManufacturer = socManufacturer,
            socModel = socModel,
            cpuModelName = cpuModelName,
            cpuFeatures = cpuFeatures,
            cores = cores,
            coreFreqAccessibleCount = freqAccessibleCount,
            systemStatAccessible = systemStatAccessible,
            processCpuPercent = processCpuPercent,
            availability = availability,
            limitationNote = limitation
        )
    }

    fun collectGpu(forceRefresh: Boolean = false): GpuInfo {
        if (!forceRefresh && cachedGpuInfo != null) {
            return cachedGpuInfo!!
        }
        return EglGpuProbe.probe(context).also { cachedGpuInfo = it }
    }

    fun collectStorage(): StorageInfo {
        return try {
            val dataDir = Environment.getDataDirectory()
            val statFs = StatFs(dataDir.path)
            val total = statFs.totalBytes.coerceAtLeast(0L)
            val available = statFs.availableBytes.coerceAtLeast(0L)
            val free = statFs.freeBytes.coerceAtLeast(0L)

            val appFiles = dirSizeBytes(context.filesDir)
            val appCache = dirSizeBytes(context.cacheDir)

            val quotaBytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    val sm = context.getSystemService(Context.STORAGE_SERVICE) as? StorageManager
                    val uuid = sm?.getUuidForPath(context.filesDir)
                    if (sm != null && uuid != null) sm.getCacheQuotaBytes(uuid) else null
                } catch (_: Exception) {
                    null
                }
            } else null

            StorageInfo(
                internalTotalBytes = total,
                internalAvailableBytes = available,
                internalFreeBytes = free,
                appFilesBytes = appFiles,
                appCacheBytes = appCache,
                appCacheQuotaBytes = quotaBytes,
                availability = if (total > 0L) DataAvailability.AVAILABLE else DataAvailability.PARTIAL,
                limitationNote = "StatFs (/data) mede a partição interna de dados acessível ao usuário; " +
                    "partições de sistema (/system, /vendor) são separadas e a cota acima refere-se apenas ao sandbox do aplicativo."
            )
        } catch (_: Exception) {
            StorageInfo(
                availability = DataAvailability.UNAVAILABLE,
                limitationNote = "Não foi possível consultar StatFs ou StorageManager."
            )
        }
    }

    fun collectBattery(): BatteryInfo {
        return try {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

            if (intent == null) {
                val capacity = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    ?.takeIf { it in 0..100 }
                return BatteryInfo(
                    levelPercent = capacity,
                    availability = if (capacity != null) DataAvailability.PARTIAL else DataAvailability.UNAVAILABLE,
                    limitationNote = "Broadcast ACTION_BATTERY_CHANGED não retornou telemetria completa."
                )
            }

            val rawLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val rawScale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val levelPercent = if (rawLevel >= 0 && rawScale > 0) {
                ((rawLevel * 100f) / rawScale.toFloat()).toInt().coerceIn(0, 100)
            } else {
                bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)?.takeIf { it in 0..100 }
            }

            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
            val statusLabel = when (status) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "Carregando"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "Descarregando"
                BatteryManager.BATTERY_STATUS_FULL -> "Carga Completa"
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Não Carregando"
                else -> "Desconhecido"
            }
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            val pluggedLabel = when (plugged) {
                BatteryManager.BATTERY_PLUGGED_AC -> "Adaptador AC"
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                BatteryManager.BATTERY_PLUGGED_DOCK -> "Dock"
                else -> "Bateria (Desconectado)"
            }

            val tech = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.takeIf { it.isNotBlank() }
            val voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1).takeIf { it > 0 }
            val rawTemp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
            val temperatureC = if (rawTemp > 0) rawTemp / 10f else null

            val health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            val healthLabel = when (health) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Boa (Reportada pelo OS)"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Superaquecimento"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Crítica / Morta"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Sobretensão"
                BatteryManager.BATTERY_HEALTH_COLD -> "Fria"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Falha não especificada"
                else -> null
            }

            val currentNowMa = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
                ?.takeIf { it != Int.MIN_VALUE && it != 0 }
                ?.let { raw ->
                    // BatteryManager reports microamperes on most devices
                    if (kotlin.math.abs(raw) > 10_000) raw / 1000 else raw
                }

            val chargeCounterUah = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
                ?.takeIf { it != Int.MIN_VALUE && it > 0 }

            val chargeTimeRemainingMs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && isCharging) {
                try {
                    bm?.computeChargeTimeRemaining()?.takeIf { it >= 0L }
                } catch (_: Exception) {
                    null
                }
            } else null

            BatteryInfo(
                levelPercent = levelPercent,
                statusLabel = statusLabel,
                isCharging = isCharging,
                pluggedSourceLabel = pluggedLabel,
                technology = tech,
                voltageMv = voltage,
                temperatureC = temperatureC,
                healthLabel = healthLabel,
                currentNowMa = currentNowMa,
                chargeCounterUah = chargeCounterUah,
                chargeTimeRemainingMs = chargeTimeRemainingMs,
                availability = if (levelPercent != null) DataAvailability.AVAILABLE else DataAvailability.PARTIAL,
                limitationNote = "Valores como temperatura, corrente (mA) e tempo estimado só são exibidos quando fornecidos diretamente pelo controlador de energia do dispositivo."
            )
        } catch (_: Exception) {
            BatteryInfo(
                availability = DataAvailability.UNAVAILABLE,
                limitationNote = "Serviço de bateria indisponível."
            )
        }
    }

    @Suppress("DEPRECATION")
    fun collectDisplay(): DisplayInfo {
        return try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            val resourcesMetrics = context.resources.displayMetrics
            val realMetrics = DisplayMetrics()

            val display: Display? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    context.display
                } catch (_: Exception) {
                    wm?.defaultDisplay
                }
            } else {
                wm?.defaultDisplay
            }

            display?.getRealMetrics(realMetrics)

            val widthPx: Int
            val heightPx: Int
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && wm != null) {
                val bounds = wm.maximumWindowMetrics.bounds
                widthPx = bounds.width()
                heightPx = bounds.height()
            } else if (realMetrics.widthPixels > 0) {
                widthPx = realMetrics.widthPixels
                heightPx = realMetrics.heightPixels
            } else {
                widthPx = resourcesMetrics.widthPixels
                heightPx = resourcesMetrics.heightPixels
            }

            val density = resourcesMetrics.density.coerceAtLeast(0.5f)
            val densityDpi = resourcesMetrics.densityDpi
            val xdpi = (if (realMetrics.xdpi > 0) realMetrics.xdpi else resourcesMetrics.xdpi).coerceAtLeast(72f)
            val ydpi = (if (realMetrics.ydpi > 0) realMetrics.ydpi else resourcesMetrics.ydpi).coerceAtLeast(72f)

            val widthInches = widthPx / xdpi
            val heightInches = heightPx / ydpi
            val diagonalInches = sqrt(widthInches.pow(2) + heightInches.pow(2))

            val bucket = when {
                densityDpi <= 120 -> "ldpi (~120 dpi)"
                densityDpi <= 160 -> "mdpi (~160 dpi)"
                densityDpi <= 240 -> "hdpi (~240 dpi)"
                densityDpi <= 320 -> "xhdpi (~320 dpi)"
                densityDpi <= 480 -> "xxhdpi (~480 dpi)"
                else -> "xxxhdpi (~640 dpi)"
            }

            val orientation = if (context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                "Paisagem (Landscape)"
            } else {
                "Retrato (Portrait)"
            }

            val refreshRate = display?.refreshRate ?: 60f
            val supportedRates = try {
                display?.supportedModes?.map { it.refreshRate }?.distinct()?.sorted() ?: listOf(refreshRate)
            } catch (_: Exception) {
                listOf(refreshRate)
            }

            val isWideColor = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.resources.configuration.isScreenWideColorGamut
            } else false

            val hdrList = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try {
                    display?.hdrCapabilities?.supportedHdrTypes?.map { type ->
                        when (type) {
                            Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION -> "Dolby Vision"
                            Display.HdrCapabilities.HDR_TYPE_HDR10 -> "HDR10"
                            Display.HdrCapabilities.HDR_TYPE_HLG -> "HLG"
                            Display.HdrCapabilities.HDR_TYPE_HDR10_PLUS -> "HDR10+"
                            else -> "HDR ($type)"
                        }
                    }.orEmpty()
                } catch (_: Exception) {
                    emptyList()
                }
            } else emptyList()

            DisplayInfo(
                widthPx = widthPx,
                heightPx = heightPx,
                widthDp = (widthPx / density).toInt(),
                heightDp = (heightPx / density).toInt(),
                density = density,
                densityDpi = densityDpi,
                densityBucket = bucket,
                xdpi = xdpi,
                ydpi = ydpi,
                approximateDiagonalInches = diagonalInches,
                orientationLabel = orientation,
                refreshRateHz = refreshRate,
                supportedRefreshRatesHz = supportedRates,
                isWideColorGamut = isWideColor,
                hdrCapabilities = hdrList,
                availability = DataAvailability.AVAILABLE
            )
        } catch (_: Exception) {
            DisplayInfo(availability = DataAvailability.UNAVAILABLE)
        }
    }

    fun collectDeviceInfo(): DeviceFullInfo {
        val securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Build.VERSION.SECURITY_PATCH.takeIf { it.isNotBlank() }
        } else null

        val kernelVersion = try {
            val procVer = File("/proc/version")
            if (procVer.canRead()) procVer.readText().trim() else System.getProperty("os.version") ?: "Desconhecido"
        } catch (_: Exception) {
            System.getProperty("os.version") ?: "Desconhecido"
        }

        val (netStatus, netTransport) = readNetworkSummary()
        val sensors = readSensors()

        return DeviceFullInfo(
            manufacturer = Build.MANUFACTURER?.replaceFirstChar { it.uppercase() } ?: "Desconhecido",
            model = Build.MODEL ?: "Desconhecido",
            brand = Build.BRAND?.replaceFirstChar { it.uppercase() } ?: "Desconhecido",
            device = Build.DEVICE ?: "Desconhecido",
            product = Build.PRODUCT ?: "Desconhecido",
            board = Build.BOARD ?: "Desconhecido",
            hardware = Build.HARDWARE ?: "Desconhecido",
            bootloader = Build.BOOTLOADER ?: "Desconhecido",
            androidVersion = Build.VERSION.RELEASE ?: "Desconhecido",
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = securityPatch,
            buildId = Build.ID ?: "Desconhecido",
            fingerprint = Build.FINGERPRINT ?: "Desconhecido",
            kernelVersion = kernelVersion,
            vmName = System.getProperty("java.vm.name") ?: "ART",
            uptimeMs = SystemClock.elapsedRealtime(),
            networkStatus = netStatus,
            networkTransport = netTransport,
            sensors = sensors
        )
    }

    private fun readNetworkSummary(): Pair<String, String> {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val network = cm?.activeNetwork
            val caps = cm?.getNetworkCapabilities(network)
            if (caps == null) {
                "Offline" to "Nenhuma rede ativa"
            } else {
                val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                val transport = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Dados Móveis (Celular)"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
                    else -> "Outro Transporte"
                }
                (if (hasInternet) "Conectado" else "Conectado (Local)") to transport
            }
        } catch (_: Exception) {
            "Indisponível" to "Permissão ou serviço ausente"
        }
    }

    private fun readSensors(): List<SensorSummary> {
        return try {
            val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
            sm?.getSensorList(Sensor.TYPE_ALL)?.map { sensor ->
                SensorSummary(
                    name = sensor.name ?: "Sensor",
                    vendor = sensor.vendor ?: "Desconhecido",
                    typeLabel = mapSensorType(sensor.type),
                    powerMa = sensor.power
                )
            }.orEmpty()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun mapSensorType(type: Int): String {
        return when (type) {
            Sensor.TYPE_ACCELEROMETER -> "Acelerômetro"
            Sensor.TYPE_GYROSCOPE -> "Giroscópio"
            Sensor.TYPE_MAGNETIC_FIELD -> "Magnetômetro"
            Sensor.TYPE_LIGHT -> "Luminosidade"
            Sensor.TYPE_PROXIMITY -> "Proximidade"
            Sensor.TYPE_PRESSURE -> "Barômetro"
            Sensor.TYPE_GRAVITY -> "Gravidade"
            Sensor.TYPE_LINEAR_ACCELERATION -> "Aceleração Linear"
            Sensor.TYPE_ROTATION_VECTOR -> "Vetor de Rotação"
            Sensor.TYPE_STEP_COUNTER -> "Contador de Passos"
            Sensor.TYPE_STEP_DETECTOR -> "Detector de Passos"
            Sensor.TYPE_AMBIENT_TEMPERATURE -> "Temperatura Ambiente"
            else -> "Sensor (#$type)"
        }
    }

    private fun readSysLong(path: String): Long? {
        return try {
            val f = File(path)
            if (f.exists() && f.canRead()) {
                f.readText().trim().toLongOrNull()
            } else null
        } catch (_: Exception) {
            null
        }
    }

    private fun dirSizeBytes(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var total = 0L
        val stack = ArrayDeque<File>()
        stack.add(dir)
        while (stack.isNotEmpty()) {
            val current = stack.removeLast()
            val children = current.listFiles() ?: continue
            for (child in children) {
                if (child.isDirectory) {
                    stack.add(child)
                } else {
                    total += child.length()
                }
            }
        }
        return total
    }
}
