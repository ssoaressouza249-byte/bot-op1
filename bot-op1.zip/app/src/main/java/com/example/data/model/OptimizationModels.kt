package com.example.data.model

enum class FeatureStatus(val label: String) {
    ACTIVE("Ativo"),
    OFF("Desligado"),
    REQUIRES_SHIZUKU("Requer Shizuku"),
    REQUIRES_PERMISSION("Requer Permissão"),
    UNAVAILABLE_HARDWARE("Indisponível no hardware")
}

data class GameEngineInfo(
    val detected: Boolean = false,
    val engineName: String = "Nenhum motor nativo detectado",
    val packageName: String? = null
)

data class InstalledAppItem(
    val appName: String,
    val packageName: String,
    val isEnabled: Boolean,
    val isSystemApp: Boolean
)

data class NetworkLatencyInfo(
    val pingMs: Long? = null,
    val hostTested: String = "1.1.1.1:53",
    val transportLabel: String = "Verificando...",
    val downstreamKbps: Int? = null,
    val dataSaverStatusLabel: String = "Desconhecido",
    val isTesting: Boolean = false
)

data class ThermalStatusInfo(
    val temperatureC: Float? = null,
    val thermalStatusLabel: String = "Normal",
    val isThermalThrottling: Boolean = false,
    val isPowerSaveMode: Boolean = false,
    val shieldReducedBrightness: Boolean = false
)

data class RamCleanResult(
    val availableBeforeBytes: Long = 0L,
    val availableAfterBytes: Long = 0L,
    val processesKilledHint: Int = 0,
    val cacheClearedBytes: Long = 0L,
    val timestampMs: Long = 0L
) {
    val freedBytes: Long get() = (availableAfterBytes - availableBeforeBytes).coerceAtLeast(0L)
}

data class DpiCountdownState(
    val isActive: Boolean = false,
    val originalDpi: Int = 0,
    val appliedDpi: Int = 0,
    val secondsRemaining: Int = 15
)

data class OptimizationState(
    val profileEnabled: Boolean = false,
    val nativeGameEngine: GameEngineInfo = GameEngineInfo(),

    // Permissions snapshot
    val hasWriteSettings: Boolean = false,
    val hasDndPolicyAccess: Boolean = false,
    val hasBluetoothPermission: Boolean = false,
    val hasNotificationPermission: Boolean = false,

    // Hardware capability snapshot
    val hasBluetoothHardware: Boolean = false,
    val isBluetoothEnabled: Boolean = false,
    val hasBluetoothAudioConnected: Boolean = false,
    val hasNfcHardware: Boolean = false,
    val isNfcEnabled: Boolean = false,

    // Game Category 1: Durante o jogo
    val autoDndEnabled: Boolean = false,
    val noPopupsEnabled: Boolean = false,
    val thermalShieldEnabled: Boolean = false,
    val zeroAnimationEnabled: Boolean = false,
    val rotationLockedEnabled: Boolean = false,
    val noVibrationEnabled: Boolean = false,

    // Game Category 2: Toque, Mira e DPI
    val currentDpi: Int = 420,
    val originalDpi: Int = 420,
    val selectedDpi: Int = 420,
    val dpiCountdown: DpiCountdownState = DpiCountdownState(),
    val longPressTimeoutMs: Int? = null, // null = Padrão / OS default
    val pointerSpeed: Int = 0, // -3..+7
    val sensitiveTouchEnabled: Boolean = false,

    // System Tab: Internet & Hardware Radios
    val latencyInfo: NetworkLatencyInfo = NetworkLatencyInfo(),
    val captivePortalDisabled: Boolean = false,
    val restrictBackgroundDataEnabled: Boolean = false,
    val bluetoothAutoOffInGame: Boolean = false,

    // System Tab: Thermal & Power
    val thermalInfo: ThermalStatusInfo = ThermalStatusInfo(),

    // System Tab: Processor & Cleaner
    val lastRamCleanResult: RamCleanResult? = null,
    val isCleaningRam: Boolean = false,
    val installedApps: List<InstalledAppItem> = emptyList(),
    val isLoadingApps: Boolean = false
) {
    val activeFeatureCount: Int
        get() = listOf(
            autoDndEnabled,
            noPopupsEnabled,
            thermalShieldEnabled,
            zeroAnimationEnabled,
            rotationLockedEnabled,
            noVibrationEnabled,
            sensitiveTouchEnabled,
            captivePortalDisabled,
            restrictBackgroundDataEnabled,
            bluetoothAutoOffInGame,
            longPressTimeoutMs != null,
            pointerSpeed != 0,
            currentDpi != originalDpi
        ).count { it }
}
