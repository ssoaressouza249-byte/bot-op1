package com.example.data.model

enum class DataAvailability(val label: String) {
    AVAILABLE("DISPONÍVEL"),
    PARTIAL("PARCIAL"),
    RESTRICTED("RESTRITO PELO OS"),
    UNAVAILABLE("INDISPONÍVEL")
}

enum class DiagnosticStatus(val label: String) {
    OK("OK"),
    WARNING("ATENÇÃO"),
    RESTRICTED("RESTRITO"),
    CRITICAL("CRÍTICO")
}

data class RamPoint(
    val timestampMs: Long,
    val usedMb: Long,
    val totalMb: Long,
    val appHeapUsedMb: Long
) {
    val usedPercent: Float
        get() = if (totalMb > 0L) (usedMb.toFloat() / totalMb.toFloat()).coerceIn(0f, 1f) else 0f
}

data class RamInfo(
    val totalBytes: Long = 0L,
    val availableBytes: Long = 0L,
    val lowMemoryThresholdBytes: Long = 0L,
    val isLowMemory: Boolean = false,
    val memoryClassMb: Int = 0,
    val largeMemoryClassMb: Int = 0,
    val jvmUsedBytes: Long = 0L,
    val jvmMaxBytes: Long = 0L,
    val nativeHeapAllocatedBytes: Long = 0L,
    val availability: DataAvailability = DataAvailability.UNAVAILABLE,
    val limitationNote: String = ""
) {
    val usedBytes: Long get() = (totalBytes - availableBytes).coerceAtLeast(0L)
    val usedPercent: Float
        get() = if (totalBytes > 0L) (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}

data class CpuCoreInfo(
    val coreIndex: Int,
    val currentFreqKhz: Long?,
    val minFreqKhz: Long?,
    val maxFreqKhz: Long?
)

data class CpuPoint(
    val timestampMs: Long,
    val processCpuPercent: Float
)

data class CpuInfo(
    val logicalProcessors: Int = 0,
    val primaryAbi: String = "Desconhecido",
    val supportedAbis: List<String> = emptyList(),
    val osArch: String = "Desconhecido",
    val hardware: String = "Desconhecido",
    val board: String = "Desconhecido",
    val socManufacturer: String? = null,
    val socModel: String? = null,
    val cpuModelName: String? = null,
    val cpuFeatures: String? = null,
    val cores: List<CpuCoreInfo> = emptyList(),
    val coreFreqAccessibleCount: Int = 0,
    val systemStatAccessible: Boolean = false,
    val processCpuPercent: Float? = null,
    val availability: DataAvailability = DataAvailability.PARTIAL,
    val limitationNote: String = ""
)

data class GpuInfo(
    val glEsSystemVersion: String = "Desconhecido",
    val renderer: String? = null,
    val vendor: String? = null,
    val glVersion: String? = null,
    val glslVersion: String? = null,
    val maxTextureSize: Int? = null,
    val maxViewportWidth: Int? = null,
    val maxViewportHeight: Int? = null,
    val maxVertexAttribs: Int? = null,
    val extensions: List<String> = emptyList(),
    val availability: DataAvailability = DataAvailability.UNAVAILABLE,
    val errorNote: String? = null
)

data class StoragePoint(
    val timestampMs: Long,
    val usedBytes: Long,
    val totalBytes: Long
) {
    val usedPercent: Float
        get() = if (totalBytes > 0L) (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}

data class StorageInfo(
    val internalTotalBytes: Long = 0L,
    val internalAvailableBytes: Long = 0L,
    val internalFreeBytes: Long = 0L,
    val appFilesBytes: Long = 0L,
    val appCacheBytes: Long = 0L,
    val appCacheQuotaBytes: Long? = null,
    val availability: DataAvailability = DataAvailability.UNAVAILABLE,
    val limitationNote: String = ""
) {
    val internalUsedBytes: Long get() = (internalTotalBytes - internalAvailableBytes).coerceAtLeast(0L)
    val internalUsedPercent: Float
        get() = if (internalTotalBytes > 0L) (internalUsedBytes.toFloat() / internalTotalBytes.toFloat()).coerceIn(0f, 1f) else 0f
    val appTotalUsedBytes: Long get() = appFilesBytes + appCacheBytes
}

data class BatteryPoint(
    val timestampMs: Long,
    val levelPercent: Int,
    val isCharging: Boolean
)

data class BatteryInfo(
    val levelPercent: Int? = null,
    val statusLabel: String = "Desconhecido",
    val isCharging: Boolean = false,
    val pluggedSourceLabel: String = "Desconectado",
    val technology: String? = null,
    val voltageMv: Int? = null,
    val temperatureC: Float? = null,
    val healthLabel: String? = null,
    val currentNowMa: Int? = null,
    val chargeCounterUah: Int? = null,
    val chargeTimeRemainingMs: Long? = null,
    val availability: DataAvailability = DataAvailability.UNAVAILABLE,
    val limitationNote: String = ""
)

data class DisplayInfo(
    val widthPx: Int = 0,
    val heightPx: Int = 0,
    val widthDp: Int = 0,
    val heightDp: Int = 0,
    val density: Float = 1f,
    val densityDpi: Int = 160,
    val densityBucket: String = "mdpi",
    val xdpi: Float = 0f,
    val ydpi: Float = 0f,
    val approximateDiagonalInches: Float = 0f,
    val orientationLabel: String = "Retrato",
    val refreshRateHz: Float = 60f,
    val supportedRefreshRatesHz: List<Float> = emptyList(),
    val isWideColorGamut: Boolean = false,
    val hdrCapabilities: List<String> = emptyList(),
    val availability: DataAvailability = DataAvailability.AVAILABLE
)

data class SensorSummary(
    val name: String,
    val vendor: String,
    val typeLabel: String,
    val powerMa: Float
)

data class DeviceFullInfo(
    val manufacturer: String = "Desconhecido",
    val model: String = "Desconhecido",
    val brand: String = "Desconhecido",
    val device: String = "Desconhecido",
    val product: String = "Desconhecido",
    val board: String = "Desconhecido",
    val hardware: String = "Desconhecido",
    val bootloader: String = "Desconhecido",
    val androidVersion: String = "Desconhecido",
    val sdkInt: Int = 0,
    val securityPatch: String? = null,
    val buildId: String = "Desconhecido",
    val fingerprint: String = "Desconhecido",
    val kernelVersion: String = "Desconhecido",
    val vmName: String = "ART",
    val uptimeMs: Long = 0L,
    val networkStatus: String = "Desconhecido",
    val networkTransport: String = "Indisponível",
    val sensors: List<SensorSummary> = emptyList()
)

data class DiagnosticCheckItem(
    val id: String,
    val title: String,
    val subsystem: String,
    val status: DiagnosticStatus,
    val summary: String,
    val detail: String,
    val recommendation: String
)

data class DiagnosticReport(
    val timestampMs: Long = 0L,
    val scorePercent: Int = 0,
    val overallStatus: DiagnosticStatus = DiagnosticStatus.OK,
    val okCount: Int = 0,
    val warningCount: Int = 0,
    val restrictedCount: Int = 0,
    val missingDataNotes: List<String> = emptyList(),
    val checks: List<DiagnosticCheckItem> = emptyList()
)

data class AppSettings(
    val autoRefresh: Boolean = true,
    val refreshIntervalSec: Int = 3,
    val highGlowMode: Boolean = true
)

data class SystemTelemetryState(
    val ram: RamInfo = RamInfo(),
    val cpu: CpuInfo = CpuInfo(),
    val gpu: GpuInfo = GpuInfo(),
    val storage: StorageInfo = StorageInfo(),
    val battery: BatteryInfo = BatteryInfo(),
    val display: DisplayInfo = DisplayInfo(),
    val device: DeviceFullInfo = DeviceFullInfo(),
    val ramHistory: List<RamPoint> = emptyList(),
    val cpuHistory: List<CpuPoint> = emptyList(),
    val storageHistory: List<StoragePoint> = emptyList(),
    val batteryHistory: List<BatteryPoint> = emptyList(),
    val diagnosticReport: DiagnosticReport? = null,
    val isRefreshing: Boolean = false,
    val isScanningDiagnostic: Boolean = false,
    val scanProgress: Float = 0f,
    val scanStepLabel: String = "",
    val lastUpdatedMs: Long = 0L
)
