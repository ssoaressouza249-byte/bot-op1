package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AppSettings
import com.example.data.model.BatteryPoint
import com.example.data.model.RamPoint
import com.example.data.model.StoragePoint
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.botDataStore: DataStore<Preferences> by preferencesDataStore(name = "bot_op1_store")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val AUTO_REFRESH = booleanPreferencesKey("auto_refresh")
        val REFRESH_INTERVAL_SEC = intPreferencesKey("refresh_interval_sec")
        val HIGH_GLOW_MODE = booleanPreferencesKey("high_glow_mode")
        val RAM_HISTORY = stringPreferencesKey("ram_history_json")
        val STORAGE_HISTORY = stringPreferencesKey("storage_history_json")
        val BATTERY_HISTORY = stringPreferencesKey("battery_history_json")
    }

    val settingsFlow: Flow<AppSettings> = context.botDataStore.data.map { prefs ->
        AppSettings(
            autoRefresh = prefs[Keys.AUTO_REFRESH] ?: true,
            refreshIntervalSec = (prefs[Keys.REFRESH_INTERVAL_SEC] ?: 3).coerceIn(1, 30),
            highGlowMode = prefs[Keys.HIGH_GLOW_MODE] ?: true
        )
    }

    suspend fun setAutoRefresh(enabled: Boolean) {
        context.botDataStore.edit { it[Keys.AUTO_REFRESH] = enabled }
    }

    suspend fun setRefreshIntervalSec(seconds: Int) {
        context.botDataStore.edit { it[Keys.REFRESH_INTERVAL_SEC] = seconds.coerceIn(1, 30) }
    }

    suspend fun setHighGlowMode(enabled: Boolean) {
        context.botDataStore.edit { it[Keys.HIGH_GLOW_MODE] = enabled }
    }

    suspend fun loadHistories(): Triple<List<RamPoint>, List<StoragePoint>, List<BatteryPoint>> {
        val prefs = context.botDataStore.data.first()
        val ram = parseRamHistory(prefs[Keys.RAM_HISTORY])
        val storage = parseStorageHistory(prefs[Keys.STORAGE_HISTORY])
        val battery = parseBatteryHistory(prefs[Keys.BATTERY_HISTORY])
        return Triple(ram, storage, battery)
    }

    suspend fun saveHistories(
        ram: List<RamPoint>,
        storage: List<StoragePoint>,
        battery: List<BatteryPoint>
    ) {
        context.botDataStore.edit { prefs ->
            prefs[Keys.RAM_HISTORY] = serializeRamHistory(ram)
            prefs[Keys.STORAGE_HISTORY] = serializeStorageHistory(storage)
            prefs[Keys.BATTERY_HISTORY] = serializeBatteryHistory(battery)
        }
    }

    suspend fun clearLocalHistory() {
        context.botDataStore.edit { prefs ->
            prefs.remove(Keys.RAM_HISTORY)
            prefs.remove(Keys.STORAGE_HISTORY)
            prefs.remove(Keys.BATTERY_HISTORY)
        }
    }

    private fun serializeRamHistory(points: List<RamPoint>): String {
        val arr = JSONArray()
        points.forEach { p ->
            arr.put(JSONObject().apply {
                put("t", p.timestampMs)
                put("u", p.usedMb)
                put("tot", p.totalMb)
                put("app", p.appHeapUsedMb)
            })
        }
        return arr.toString()
    }

    private fun parseRamHistory(raw: String?): List<RamPoint> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                RamPoint(
                    timestampMs = obj.optLong("t"),
                    usedMb = obj.optLong("u"),
                    totalMb = obj.optLong("tot"),
                    appHeapUsedMb = obj.optLong("app")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun serializeStorageHistory(points: List<StoragePoint>): String {
        val arr = JSONArray()
        points.forEach { p ->
            arr.put(JSONObject().apply {
                put("t", p.timestampMs)
                put("u", p.usedBytes)
                put("tot", p.totalBytes)
            })
        }
        return arr.toString()
    }

    private fun parseStorageHistory(raw: String?): List<StoragePoint> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                StoragePoint(
                    timestampMs = obj.optLong("t"),
                    usedBytes = obj.optLong("u"),
                    totalBytes = obj.optLong("tot")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun serializeBatteryHistory(points: List<BatteryPoint>): String {
        val arr = JSONArray()
        points.forEach { p ->
            arr.put(JSONObject().apply {
                put("t", p.timestampMs)
                put("l", p.levelPercent)
                put("c", p.isCharging)
            })
        }
        return arr.toString()
    }

    private fun parseBatteryHistory(raw: String?): List<BatteryPoint> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                BatteryPoint(
                    timestampMs = obj.optLong("t"),
                    levelPercent = obj.optInt("l"),
                    isCharging = obj.optBoolean("c")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
