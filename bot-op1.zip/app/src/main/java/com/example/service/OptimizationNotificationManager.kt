package com.example.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object BotNotificationEventBus {
    private val _disableAllEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    val disableAllEvents: SharedFlow<Unit> = _disableAllEvents.asSharedFlow()

    fun emitDisableAll() {
        _disableAllEvents.tryEmit(Unit)
    }
}

class BotNotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == OptimizationNotificationManager.ACTION_DISABLE_ALL) {
            BotNotificationEventBus.emitDisableAll()
            context?.let { OptimizationNotificationManager.cancel(it) }
        }
    }
}

object OptimizationNotificationManager {
    private const val CHANNEL_ID = "bot_op1_profile_channel"
    private const val NOTIFICATION_ID = 2001
    const val ACTION_DISABLE_ALL = "com.example.ACTION_DISABLE_ALL_OPTIMIZATIONS"

    fun updateNotification(
        context: Context,
        profileActive: Boolean,
        activeCount: Int
    ) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        if (!profileActive || activeCount <= 0) {
            nm.cancel(NOTIFICATION_ID)
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        ensureChannel(nm)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            context,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val disableIntent = Intent(context, BotNotificationActionReceiver::class.java).apply {
            action = ACTION_DISABLE_ALL
        }
        val disablePending = PendingIntent.getBroadcast(
            context,
            1,
            disableIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("BOT OP1 • Perfil Ativo")
            .setContentText("$activeCount otimizações trabalhando em segundo plano")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPending)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Desativar Tudo",
                disablePending
            )
            .build()

        nm.notify(NOTIFICATION_ID, notification)
    }

    fun cancel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        nm.cancel(NOTIFICATION_ID)
    }

    private fun ensureChannel(nm: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Perfil de Otimização BOT OP1",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificação persistente de baixo consumo enquanto otimizações estiverem ativas."
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }
    }
}
