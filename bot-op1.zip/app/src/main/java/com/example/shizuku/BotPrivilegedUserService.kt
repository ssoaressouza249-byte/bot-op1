package com.example.shizuku

import android.content.Context
import android.os.Process
import androidx.annotation.Keep
import com.example.IBotPrivilegedService
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

@Keep
class BotPrivilegedUserService() : IBotPrivilegedService.Stub() {

    @Suppress("UNUSED_PARAMETER")
    constructor(context: Context) : this()

    override fun executeCommand(command: String?): String {
        if (command.isNullOrBlank()) return "ERR:EmptyCommand"
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
            val finished = process.waitFor(8, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                "ERR:Timeout"
            } else {
                val exit = process.exitValue()
                if (exit == 0) {
                    "OK:${stdout.trim()}"
                } else {
                    "ERR:($exit) ${stderr.trim().ifEmpty { stdout.trim() }}"
                }
            }
        } catch (t: Throwable) {
            "ERR:${t.message ?: "Exception"}"
        }
    }

    override fun getUid(): Int = Process.myUid()

    override fun destroy() {
        Thread {
            try {
                Thread.sleep(250)
            } catch (_: InterruptedException) {
            }
            exitProcess(0)
        }.start()
    }
}
