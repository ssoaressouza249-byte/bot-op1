package com.example.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.example.IBotPrivilegedService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

data class ShizukuStatus(
    val isShizukuInstalled: Boolean = false,
    val isBinderAlive: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val isServiceBound: Boolean = false,
    val shizukuVersion: Int = -1,
    val privilegedUid: Int = -1,
    val lastCommandOutput: String = ""
) {
    val isReady: Boolean
        get() = isBinderAlive && isPermissionGranted
}

data class ShellResult(
    val success: Boolean,
    val output: String
)

class ShizukuBridge(private val context: Context) {

    companion object {
        private const val REQUEST_CODE_SHIZUKU = 2041
        private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    }

    private val _status = MutableStateFlow(ShizukuStatus())
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private var userService: IBotPrivilegedService? = null
    private var pendingBindDeferred: CompletableDeferred<IBotPrivilegedService?>? = null

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(
            ComponentName(context.packageName, BotPrivilegedUserService::class.java.name)
        )
            .daemon(false)
            .version(2)
            .processNameSuffix("botop1_shizuku")
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
        if (_status.value.isReady) {
            bindServiceIfNeeded()
        }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        userService = null
        refreshStatus()
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_CODE_SHIZUKU) {
                refreshStatus()
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    bindServiceIfNeeded()
                }
            }
        }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            if (service != null && service.pingBinder()) {
                val iface = IBotPrivilegedService.Stub.asInterface(service)
                userService = iface
                val uid = try {
                    iface.uid
                } catch (_: Throwable) {
                    -1
                }
                _status.update {
                    it.copy(
                        isServiceBound = true,
                        privilegedUid = uid
                    )
                }
                pendingBindDeferred?.complete(iface)
            } else {
                pendingBindDeferred?.complete(null)
            }
            pendingBindDeferred = null
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            userService = null
            _status.update { it.copy(isServiceBound = false, privilegedUid = -1) }
        }
    }

    fun registerListeners() {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
        } catch (_: Throwable) {
        }
        refreshStatus()
    }

    fun unregisterListeners() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        } catch (_: Throwable) {
        }
        unbindService()
    }

    fun refreshStatus() {
        val installed = isPackageInstalled(SHIZUKU_PACKAGE)
        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
        val version = if (binderAlive) {
            try {
                Shizuku.getVersion()
            } catch (_: Throwable) {
                -1
            }
        } else -1
        val granted = if (binderAlive) {
            try {
                !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            } catch (_: Throwable) {
                false
            }
        } else false

        _status.update {
            it.copy(
                isShizukuInstalled = installed,
                isBinderAlive = binderAlive,
                isPermissionGranted = granted,
                shizukuVersion = version,
                isServiceBound = userService != null && userService?.asBinder()?.pingBinder() == true
            )
        }
    }

    fun requestPermission(): Boolean {
        refreshStatus()
        if (!_status.value.isBinderAlive) return false
        return try {
            if (!Shizuku.isPreV11() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                if (!Shizuku.shouldShowRequestPermissionRationale()) {
                    Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
                } else {
                    Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
                }
                true
            } else {
                bindServiceIfNeeded()
                true
            }
        } catch (_: Throwable) {
            false
        }
    }

    fun openShizukuApp(): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun bindServiceIfNeeded() {
        if (userService != null && userService?.asBinder()?.pingBinder() == true) return
        try {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        } catch (_: Throwable) {
        }
    }

    private fun unbindService() {
        try {
            userService?.destroy()
            Shizuku.unbindUserService(userServiceArgs, serviceConnection, false)
        } catch (_: Throwable) {
        }
        userService = null
    }

    suspend fun runCommand(command: String): ShellResult = withContext(Dispatchers.IO) {
        refreshStatus()
        if (!_status.value.isReady) {
            return@withContext ShellResult(false, "Shizuku inativo ou sem permissão.")
        }
        val service = ensureBoundService()
            ?: return@withContext ShellResult(false, "Falha ao conectar ao UserService Shizuku.")

        val raw = try {
            service.executeCommand(command) ?: "ERR:NullResponse"
        } catch (t: Throwable) {
            "ERR:${t.message ?: "BinderError"}"
        }

        val ok = raw.startsWith("OK:")
        val output = raw.removePrefix("OK:").removePrefix("ERR:")
        _status.update { it.copy(lastCommandOutput = output.ifBlank { if (ok) "OK" else "Erro" }) }
        ShellResult(ok, output)
    }

    private suspend fun ensureBoundService(): IBotPrivilegedService? {
        val current = userService
        if (current != null && current.asBinder().pingBinder()) return current

        val deferred = CompletableDeferred<IBotPrivilegedService?>()
        pendingBindDeferred = deferred
        withContext(Dispatchers.Main) {
            try {
                Shizuku.bindUserService(userServiceArgs, serviceConnection)
            } catch (_: Throwable) {
                pendingBindDeferred = null
                deferred.complete(null)
            }
        }
        return withTimeoutOrNull(4500L) { deferred.await() }
    }

    private fun isPackageInstalled(pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        } catch (_: Throwable) {
            false
        }
    }
}
