package com.example.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.PermanentDrawerSheet
import androidx.compose.material3.PermanentNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.data.model.AppSettings
import com.example.data.model.SystemTelemetryState
import com.example.ui.navigation.BotNavDestination
import com.example.ui.screens.BatteryAnalyzerScreen
import com.example.ui.screens.CpuAnalyzerScreen
import com.example.ui.screens.DeviceInfoScreen
import com.example.ui.screens.DisplayAnalyzerScreen
import com.example.ui.screens.GpuInfoScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.RamAnalyzerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StorageAnalyzerScreen
import com.example.ui.screens.SystemDiagnosticScreen
import com.example.ui.theme.BgPureBlack
import com.example.ui.theme.BotOp1Theme
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.NeonRedSoft
import com.example.ui.theme.StatusOk
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.SurfaceCarbon
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.BotOp1ViewModel
import kotlinx.coroutines.launch

@Composable
fun BotOp1App(
    viewModel: BotOp1ViewModel = viewModel()
) {
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    BotOp1Theme(highGlowMode = settings.highGlowMode) {
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentDest = BotNavDestination.fromRoute(navBackStackEntry?.destination?.route)
        val snackbarHostState = remember { SnackbarHostState() }
        val scope = rememberCoroutineScope()

        fun navigateTo(dest: BotNavDestination) {
            navController.navigate(dest.route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(BgPureBlack)
                .drawBehind {
                    if (settings.highGlowMode) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    NeonRed.copy(alpha = 0.14f),
                                    Color.Transparent
                                ),
                                center = Offset(size.width * 0.85f, size.height * 0.08f),
                                radius = size.maxDimension * 0.55f
                            )
                        )
                    }
                }
        ) {
            val isExpandedScreen = maxWidth >= 840.dp

            if (isExpandedScreen) {
                PermanentNavigationDrawer(
                    drawerContent = {
                        PermanentDrawerSheet(
                            modifier = Modifier.width(276.dp),
                            drawerContainerColor = SurfaceCarbon,
                            drawerContentColor = TextPrimary
                        ) {
                            BotDrawerContent(
                                currentDest = currentDest,
                                settings = settings,
                                onSelect = { navigateTo(it) }
                            )
                        }
                    }
                ) {
                    BotMainScaffold(
                        currentDest = currentDest,
                        telemetry = telemetry,
                        settings = settings,
                        showMenuButton = false,
                        onOpenMenu = {},
                        snackbarHostState = snackbarHostState,
                        navController = navController,
                        onNavigate = ::navigateTo,
                        onRefresh = {
                            viewModel.refreshNow()
                            scope.launch { snackbarHostState.showSnackbar("Análise de telemetria atualizada.") }
                        },
                        onRunDiagnostic = {
                            navigateTo(BotNavDestination.SYSTEM_DIAGNOSTIC)
                            viewModel.runFullDiagnostic {
                                scope.launch { snackbarHostState.showSnackbar("Diagnóstico completo finalizado.") }
                            }
                        },
                        onToggleAutoRefresh = viewModel::setAutoRefresh,
                        onSelectInterval = viewModel::setRefreshInterval,
                        onToggleHighGlow = viewModel::setHighGlowMode,
                        onClearHistory = {
                            viewModel.clearLocalHistory()
                            scope.launch { snackbarHostState.showSnackbar("Histórico local apagado.") }
                        }
                    )
                }
            } else {
                val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                ModalNavigationDrawer(
                    drawerState = drawerState,
                    scrimColor = BgPureBlack.copy(alpha = 0.78f),
                    drawerContent = {
                        ModalDrawerSheet(
                            modifier = Modifier.widthIn(max = 300.dp),
                            drawerContainerColor = SurfaceCarbon,
                            drawerContentColor = TextPrimary,
                            windowInsets = WindowInsets(0, 0, 0, 0)
                        ) {
                            BotDrawerContent(
                                currentDest = currentDest,
                                settings = settings,
                                onSelect = { dest ->
                                    scope.launch { drawerState.close() }
                                    navigateTo(dest)
                                }
                            )
                        }
                    }
                ) {
                    BotMainScaffold(
                        currentDest = currentDest,
                        telemetry = telemetry,
                        settings = settings,
                        showMenuButton = true,
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        snackbarHostState = snackbarHostState,
                        navController = navController,
                        onNavigate = ::navigateTo,
                        onRefresh = {
                            viewModel.refreshNow()
                            scope.launch { snackbarHostState.showSnackbar("Análise de telemetria atualizada.") }
                        },
                        onRunDiagnostic = {
                            navigateTo(BotNavDestination.SYSTEM_DIAGNOSTIC)
                            viewModel.runFullDiagnostic {
                                scope.launch { snackbarHostState.showSnackbar("Diagnóstico completo finalizado.") }
                            }
                        },
                        onToggleAutoRefresh = viewModel::setAutoRefresh,
                        onSelectInterval = viewModel::setRefreshInterval,
                        onToggleHighGlow = viewModel::setHighGlowMode,
                        onClearHistory = {
                            viewModel.clearLocalHistory()
                            scope.launch { snackbarHostState.showSnackbar("Histórico local apagado.") }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun BotDrawerContent(
    currentDest: BotNavDestination,
    settings: AppSettings,
    onSelect: (BotNavDestination) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .background(SurfaceCarbon)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.bot_op1_icon_1794581691859),
                contentDescription = stringResource(R.string.cd_bot_logo),
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, NeonRedBorder, RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Crop
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Text(
                    text = stringResource(R.string.app_subtitle),
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonRed,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        HorizontalDivider(color = SubtleBorder)
        Spacer(Modifier.height(10.dp))

        BotNavDestination.entries.forEach { dest ->
            val selected = dest == currentDest
            NavigationDrawerItem(
                label = {
                    Text(
                        text = dest.label,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                selected = selected,
                onClick = { onSelect(dest) },
                icon = {
                    Icon(
                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                        contentDescription = null
                    )
                },
                colors = NavigationDrawerItemDefaults.colors(
                    selectedContainerColor = NeonRedSoft,
                    selectedIconColor = NeonRed,
                    selectedTextColor = TextPrimary,
                    unselectedContainerColor = Color.Transparent,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .padding(vertical = 2.dp)
                    .testTag("nav_${dest.route}")
            )
        }

        Spacer(Modifier.height(16.dp))
        HorizontalDivider(color = SubtleBorder)
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "VER ${stringResource(R.string.app_version_label)}",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .background(if (settings.autoRefresh) StatusOk else TextMuted, CircleShape)
                )
                Text(
                    text = if (settings.autoRefresh) "LIVE ${settings.refreshIntervalSec}s" else "MANUAL",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (settings.autoRefresh) StatusOk else TextMuted
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BotMainScaffold(
    currentDest: BotNavDestination,
    telemetry: SystemTelemetryState,
    settings: AppSettings,
    showMenuButton: Boolean,
    onOpenMenu: () -> Unit,
    snackbarHostState: SnackbarHostState,
    navController: NavHostController,
    onNavigate: (BotNavDestination) -> Unit,
    onRefresh: () -> Unit,
    onRunDiagnostic: () -> Unit,
    onToggleAutoRefresh: (Boolean) -> Unit,
    onSelectInterval: (Int) -> Unit,
    onToggleHighGlow: (Boolean) -> Unit,
    onClearHistory: () -> Unit
) {
    Scaffold(
        containerColor = Color.Transparent,
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = SurfaceElevated,
                    contentColor = TextPrimary,
                    actionColor = NeonRed
                )
            }
        },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BgPureBlack.copy(alpha = 0.88f),
                    titleContentColor = TextPrimary,
                    navigationIconContentColor = TextPrimary,
                    actionIconContentColor = NeonRed
                ),
                navigationIcon = {
                    if (showMenuButton) {
                        IconButton(
                            onClick = onOpenMenu,
                            modifier = Modifier.testTag("drawer_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Menu,
                                contentDescription = stringResource(R.string.cd_open_menu)
                            )
                        }
                    }
                },
                title = {
                    Column {
                        Text(
                            text = if (currentDest == BotNavDestination.HOME) "BOT OP1" else currentDest.label,
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (currentDest == BotNavDestination.HOME) {
                                stringResource(R.string.app_subtitle)
                            } else {
                                "BOT OP1 • ${if (settings.autoRefresh) "LIVE ${settings.refreshIntervalSec}s" else "MANUAL"}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonRed,
                            maxLines = 1
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier.testTag("topbar_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = stringResource(R.string.cd_refresh_telemetry),
                            tint = NeonRed
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            NavHost(
                navController = navController,
                startDestination = BotNavDestination.HOME.route,
                enterTransition = { fadeIn(tween(180)) },
                exitTransition = { fadeOut(tween(150)) },
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 860.dp)
            ) {
                composable(BotNavDestination.HOME.route) {
                    HomeDashboardScreen(
                        state = telemetry,
                        onRefreshClick = onRefresh,
                        onRunFullDiagnostic = onRunDiagnostic,
                        onNavigate = onNavigate
                    )
                }
                composable(BotNavDestination.RAM_ANALYZER.route) {
                    RamAnalyzerScreen(
                        state = telemetry,
                        autoRefreshEnabled = settings.autoRefresh,
                        refreshIntervalSec = settings.refreshIntervalSec,
                        onRefreshClick = onRefresh
                    )
                }
                composable(BotNavDestination.CPU_ANALYZER.route) {
                    CpuAnalyzerScreen(
                        state = telemetry,
                        onOpenGpuInfo = { onNavigate(BotNavDestination.GPU_INFO) }
                    )
                }
                composable(BotNavDestination.STORAGE.route) {
                    StorageAnalyzerScreen(
                        state = telemetry,
                        onRefreshClick = onRefresh
                    )
                }
                composable(BotNavDestination.BATTERY.route) {
                    BatteryAnalyzerScreen(
                        state = telemetry,
                        onRefreshClick = onRefresh
                    )
                }
                composable(BotNavDestination.DISPLAY.route) {
                    DisplayAnalyzerScreen(
                        state = telemetry,
                        onRefreshClick = onRefresh
                    )
                }
                composable(BotNavDestination.GPU_INFO.route) {
                    GpuInfoScreen(
                        state = telemetry,
                        onRefreshClick = onRefresh
                    )
                }
                composable(BotNavDestination.SYSTEM_DIAGNOSTIC.route) {
                    SystemDiagnosticScreen(
                        state = telemetry,
                        onRunDiagnostic = onRunDiagnostic
                    )
                }
                composable(BotNavDestination.DEVICE_INFO.route) {
                    DeviceInfoScreen(state = telemetry)
                }
                composable(BotNavDestination.SETTINGS.route) {
                    SettingsScreen(
                        settings = settings,
                        telemetry = telemetry,
                        onToggleAutoRefresh = onToggleAutoRefresh,
                        onSelectInterval = onSelectInterval,
                        onToggleHighGlow = onToggleHighGlow,
                        onClearHistory = onClearHistory
                    )
                }
            }
        }
    }
}
