package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DeepCrimson
import com.example.ui.theme.LocalBotThemeExtras
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun NeonRadialGauge(
    progress: Float,
    centerLabel: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    size: Dp = 128.dp,
    accentColor: Color = NeonRed,
    strokeWidth: Dp = 10.dp
) {
    val highGlow = LocalBotThemeExtras.current.highGlowMode
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
        label = "gauge_progress"
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(6.dp)) {
            val strokePx = strokeWidth.toPx()
            val arcDiameter = kotlin.math.min(this.size.width, this.size.height) - strokePx
            val topLeft = Offset(
                (this.size.width - arcDiameter) / 2f,
                (this.size.height - arcDiameter) / 2f
            )
            val arcSize = Size(arcDiameter, arcDiameter)

            // Track arc
            drawArc(
                color = SurfaceElevated,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Glow halo under active arc
            if (highGlow && animatedProgress > 0.01f) {
                drawArc(
                    color = accentColor.copy(alpha = 0.25f),
                    startAngle = 135f,
                    sweepAngle = 270f * animatedProgress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx * 1.9f, cap = StrokeCap.Round)
                )
            }

            // Active gradient arc
            if (animatedProgress > 0.005f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(DeepCrimson, accentColor, NeonRedBright)
                    ),
                    startAngle = 135f,
                    sweepAngle = 270f * animatedProgress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerLabel,
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
fun NeonAreaLineChart(
    values: List<Float>,
    minValue: Float = 0f,
    maxValue: Float = 100f,
    unitSuffix: String = "%",
    lineColor: Color = NeonRed,
    emptyMessage: String = "Coletando amostras reais...",
    modifier: Modifier = Modifier,
    chartHeight: Dp = 150.dp
) {
    val highGlow = LocalBotThemeExtras.current.highGlowMode

    if (values.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(chartHeight)
                .background(SurfaceElevated.copy(alpha = 0.45f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Timeline,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = emptyMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
        return
    }

    val latest = values.last()
    val peak = values.maxOrNull() ?: latest
    val low = values.minOrNull() ?: latest
    val effectiveMax = maxOf(maxValue, peak, minValue + 1f)
    val effectiveMin = minOf(minValue, low)

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "ATUAL: ${formatChartValue(latest)}$unitSuffix",
                style = MaterialTheme.typography.labelMedium,
                color = lineColor
            )
            Text(
                text = "MIN ${formatChartValue(low)}$unitSuffix  •  MÁX ${formatChartValue(peak)}$unitSuffix",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(chartHeight)
                .background(SurfaceElevated.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 14.dp)
        ) {
            val w = size.width
            val h = size.height
            val range = (effectiveMax - effectiveMin).coerceAtLeast(1f)

            // Subtle horizontal grid
            val gridSteps = 3
            for (i in 0..gridSteps) {
                val y = h * (i / gridSteps.toFloat())
                drawLine(
                    color = SubtleBorder.copy(alpha = 0.6f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            val points = if (values.size == 1) {
                val y = h - ((values[0] - effectiveMin) / range).coerceIn(0f, 1f) * h
                listOf(Offset(0f, y), Offset(w, y))
            } else {
                values.mapIndexed { idx, value ->
                    val x = w * (idx.toFloat() / (values.size - 1).toFloat())
                    val norm = ((value - effectiveMin) / range).coerceIn(0f, 1f)
                    val y = h - norm * h
                    Offset(x, y)
                }
            }

            val linePath = Path().apply {
                moveTo(points.first().x, points.first().y)
                for (i in 1 until points.size) {
                    val prev = points[i - 1]
                    val curr = points[i]
                    val midX = (prev.x + curr.x) / 2f
                    cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                }
            }

            val fillPath = Path().apply {
                addPath(linePath)
                lineTo(points.last().x, h)
                lineTo(points.first().x, h)
                close()
            }

            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        lineColor.copy(alpha = if (highGlow) 0.36f else 0.22f),
                        lineColor.copy(alpha = 0.02f)
                    )
                )
            )

            if (highGlow) {
                drawPath(
                    path = linePath,
                    color = lineColor.copy(alpha = 0.28f),
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }

            drawPath(
                path = linePath,
                color = lineColor,
                style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // Latest point beacon
            val lastPt = points.last()
            drawCircle(
                color = lineColor.copy(alpha = 0.35f),
                radius = 7.dp.toPx(),
                center = lastPt
            )
            drawCircle(
                color = TextPrimary,
                radius = 3.2.dp.toPx(),
                center = lastPt
            )
        }
    }
}

@Composable
fun NeonCoreFrequencyBars(
    items: List<Pair<String, Float>>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach { (label, fraction) ->
            val animFrac by animateFloatAsState(
                targetValue = fraction.coerceIn(0f, 1f),
                animationSpec = tween(450, easing = FastOutSlowInEasing),
                label = "bar_$label"
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    modifier = Modifier.weight(0.28f)
                )
                Box(
                    modifier = Modifier
                        .weight(0.72f)
                        .height(10.dp)
                        .background(SurfaceElevated, RoundedCornerShape(6.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animFrac.coerceAtLeast(0.03f))
                            .height(10.dp)
                            .background(
                                Brush.horizontalGradient(listOf(DeepCrimson, NeonRed)),
                                RoundedCornerShape(6.dp)
                            )
                    )
                }
            }
        }
    }
}

private fun formatChartValue(v: Float): String {
    return if (v % 1f == 0f) v.toInt().toString() else String.format(java.util.Locale.US, "%.1f", v)
}
