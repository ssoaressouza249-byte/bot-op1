package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.DataAvailability
import com.example.data.model.DiagnosticStatus
import com.example.ui.theme.DeepCrimson
import com.example.ui.theme.LocalBotThemeExtras
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.StatusCritical
import com.example.ui.theme.StatusCriticalBg
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusOkBg
import com.example.ui.theme.StatusRestricted
import com.example.ui.theme.StatusRestrictedBg
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.StatusWarnBg
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.SurfaceCarbon
import com.example.ui.theme.SurfaceGlass
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun BotGlassCard(
    modifier: Modifier = Modifier,
    highlightBorder: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val highGlow = LocalBotThemeExtras.current.highGlowMode
    val borderColor = when {
        highlightBorder && highGlow -> NeonRedBorder
        highlightBorder -> DeepCrimson.copy(alpha = 0.65f)
        else -> SubtleBorder
    }
    val shape = RoundedCornerShape(16.dp)
    val baseModifier = modifier
        .fillMaxWidth()
        .clip(shape)
        .background(
            Brush.verticalGradient(
                colors = listOf(
                    SurfaceGlass,
                    SurfaceCarbon.copy(alpha = 0.94f)
                )
            )
        )
        .border(1.dp, borderColor, shape)
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }
        .padding(16.dp)

    Column(modifier = baseModifier, content = content)
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    trailing: (@Composable () -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            if (icon != null) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(NeonRed.copy(alpha = 0.14f), RoundedCornerShape(10.dp))
                        .border(1.dp, NeonRedBorder, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = NeonRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

@Composable
fun AvailabilityBadge(
    availability: DataAvailability,
    modifier: Modifier = Modifier
) {
    val (fg, bg) = when (availability) {
        DataAvailability.AVAILABLE -> StatusOk to StatusOkBg
        DataAvailability.PARTIAL -> StatusWarn to StatusWarnBg
        DataAvailability.RESTRICTED -> StatusRestricted to StatusRestrictedBg
        DataAvailability.UNAVAILABLE -> StatusCritical to StatusCriticalBg
    }
    StatusPill(label = availability.label, fg = fg, bg = bg, modifier = modifier)
}

@Composable
fun DiagnosticStatusBadge(
    status: DiagnosticStatus,
    modifier: Modifier = Modifier
) {
    val (fg, bg) = when (status) {
        DiagnosticStatus.OK -> StatusOk to StatusOkBg
        DiagnosticStatus.WARNING -> StatusWarn to StatusWarnBg
        DiagnosticStatus.RESTRICTED -> StatusRestricted to StatusRestrictedBg
        DiagnosticStatus.CRITICAL -> StatusCritical to StatusCriticalBg
    }
    StatusPill(label = status.label, fg = fg, bg = bg, modifier = modifier)
}

@Composable
fun StatusPill(
    label: String,
    fg: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = bg,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(fg, CircleShape)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = fg,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun TelemetrySpecRow(
    label: String,
    value: String,
    valueColor: Color = TextPrimary,
    showDivider: Boolean = true
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                modifier = Modifier.weight(0.44f)
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                color = valueColor,
                modifier = Modifier.weight(0.56f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (showDivider) {
            HorizontalDivider(color = SubtleBorder.copy(alpha = 0.55f), thickness = 0.5.dp)
        }
    }
}

@Composable
fun LimitationNoticeCard(
    title: String,
    message: String,
    modifier: Modifier = Modifier
) {
    BotGlassCard(modifier = modifier, highlightBorder = false) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(StatusWarn, CircleShape)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = StatusWarn
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }
}

@Composable
fun NeonPrimaryButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .heightIn(min = 50.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = NeonRed,
            contentColor = TextPrimary,
            disabledContainerColor = DeepCrimson.copy(alpha = 0.4f),
            disabledContentColor = TextMuted
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun NeonSecondaryButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .heightIn(min = 50.dp),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, NeonRedBorder),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = NeonRed,
            containerColor = NeonRed.copy(alpha = 0.08f)
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun FeatureStatusBadge(
    status: com.example.data.model.FeatureStatus,
    modifier: Modifier = Modifier
) {
    val (fg, bg) = when (status) {
        com.example.data.model.FeatureStatus.ACTIVE -> StatusOk to StatusOkBg
        com.example.data.model.FeatureStatus.OFF -> TextMuted to SurfaceCarbon
        com.example.data.model.FeatureStatus.REQUIRES_SHIZUKU -> StatusWarn to StatusWarnBg
        com.example.data.model.FeatureStatus.REQUIRES_PERMISSION -> NeonRed to StatusCriticalBg
        com.example.data.model.FeatureStatus.UNAVAILABLE_HARDWARE -> StatusRestricted to StatusRestrictedBg
    }
    StatusPill(label = status.label, fg = fg, bg = bg, modifier = modifier)
}

@Composable
fun OptimizationToggleCard(
    title: String,
    description: String,
    icon: ImageVector,
    checked: Boolean,
    status: com.example.data.model.FeatureStatus,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    BotGlassCard(
        modifier = modifier,
        highlightBorder = checked
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            if (checked) NeonRed.copy(alpha = 0.16f) else SurfaceCarbon,
                            RoundedCornerShape(10.dp)
                        )
                        .border(
                            1.dp,
                            if (checked) NeonRedBorder else SubtleBorder,
                            RoundedCornerShape(10.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (checked) NeonRed else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    FeatureStatusBadge(status = status)
                }
            }
            Spacer(Modifier.width(10.dp))
            androidx.compose.material3.Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                enabled = enabled,
                modifier = Modifier.minimumInteractiveComponentSize(),
                colors = androidx.compose.material3.SwitchDefaults.colors(
                    checkedThumbColor = TextPrimary,
                    checkedTrackColor = NeonRed,
                    uncheckedThumbColor = TextSecondary,
                    uncheckedTrackColor = SurfaceCarbon
                )
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }
}

@Composable
fun BotFloatingStatusBar(
    profileEnabled: Boolean,
    activeCount: Int,
    shizukuReady: Boolean,
    onToggleProfile: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val active = profileEnabled || activeCount > 0
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        color = SurfaceCarbon.copy(alpha = 0.96f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (active) NeonRedBorder else SubtleBorder
        ),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(
                            when {
                                active && activeCount > 0 -> StatusOk
                                active -> NeonRed
                                else -> TextMuted
                            },
                            CircleShape
                        )
                )
                Column {
                    Text(
                        text = if (active) {
                            "Ativo • $activeCount ${if (activeCount == 1) "função trabalhando" else "funções trabalhando"}"
                        } else {
                            "Perfil BOT OP1 desligado"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (shizukuReady) "Motor Shizuku conectado" else "Modo nativo Android 14+",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (shizukuReady) StatusOk else TextSecondary,
                        maxLines = 1
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            androidx.compose.material3.Switch(
                checked = active,
                onCheckedChange = onToggleProfile,
                colors = androidx.compose.material3.SwitchDefaults.colors(
                    checkedThumbColor = TextPrimary,
                    checkedTrackColor = NeonRed,
                    uncheckedThumbColor = TextSecondary,
                    uncheckedTrackColor = com.example.ui.theme.SurfaceElevated
                )
            )
        }
    }
}

