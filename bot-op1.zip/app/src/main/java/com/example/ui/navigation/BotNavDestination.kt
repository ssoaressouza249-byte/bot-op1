package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PermDeviceInformation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.DeveloperBoard
import androidx.compose.material.icons.outlined.DisplaySettings
import androidx.compose.material.icons.outlined.HealthAndSafety
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PermDeviceInformation
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.VideogameAsset
import androidx.compose.ui.graphics.vector.ImageVector

enum class BotNavDestination(
    val route: String,
    val label: String,
    val shortTitle: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    HOME(
        route = "home",
        label = "HOME",
        shortTitle = "DASHBOARD",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home
    ),
    RAM_ANALYZER(
        route = "ram_analyzer",
        label = "RAM ANALYZER",
        shortTitle = "RAM ANALYZER",
        selectedIcon = Icons.Filled.Memory,
        unselectedIcon = Icons.Outlined.Memory
    ),
    CPU_ANALYZER(
        route = "cpu_analyzer",
        label = "CPU ANALYZER",
        shortTitle = "CPU ANALYZER",
        selectedIcon = Icons.Filled.DeveloperBoard,
        unselectedIcon = Icons.Outlined.DeveloperBoard
    ),
    STORAGE(
        route = "storage",
        label = "STORAGE",
        shortTitle = "STORAGE",
        selectedIcon = Icons.Filled.Storage,
        unselectedIcon = Icons.Outlined.Storage
    ),
    BATTERY(
        route = "battery",
        label = "BATTERY",
        shortTitle = "BATTERY",
        selectedIcon = Icons.Filled.BatteryChargingFull,
        unselectedIcon = Icons.Outlined.BatteryChargingFull
    ),
    DISPLAY(
        route = "display",
        label = "DISPLAY",
        shortTitle = "DISPLAY",
        selectedIcon = Icons.Filled.DisplaySettings,
        unselectedIcon = Icons.Outlined.DisplaySettings
    ),
    GPU_INFO(
        route = "gpu_info",
        label = "GPU INFO",
        shortTitle = "GPU INFO",
        selectedIcon = Icons.Filled.VideogameAsset,
        unselectedIcon = Icons.Outlined.VideogameAsset
    ),
    SYSTEM_DIAGNOSTIC(
        route = "system_diagnostic",
        label = "SYSTEM DIAGNOSTIC",
        shortTitle = "DIAGNOSTIC",
        selectedIcon = Icons.Filled.HealthAndSafety,
        unselectedIcon = Icons.Outlined.HealthAndSafety
    ),
    DEVICE_INFO(
        route = "device_info",
        label = "DEVICE INFO",
        shortTitle = "DEVICE INFO",
        selectedIcon = Icons.Filled.PermDeviceInformation,
        unselectedIcon = Icons.Outlined.PermDeviceInformation
    ),
    SETTINGS(
        route = "settings",
        label = "SETTINGS",
        shortTitle = "CONFIGURAÇÕES",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings
    );

    companion object {
        fun fromRoute(route: String?): BotNavDestination =
            entries.firstOrNull { it.route == route } ?: HOME
    }
}
