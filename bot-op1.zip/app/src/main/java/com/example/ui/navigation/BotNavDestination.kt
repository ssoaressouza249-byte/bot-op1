package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PermDeviceInformation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.DeveloperBoard
import androidx.compose.material.icons.outlined.DisplaySettings
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.HealthAndSafety
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PermDeviceInformation
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.VideogameAsset
import androidx.compose.ui.graphics.vector.ImageVector

enum class BotNavDestination(
    val route: String,
    val label: String,
    val shortTitle: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    HOME(
        route = "home",
        label = "HOME",
        shortTitle = "Início",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home
    ),
    GAME_MODE(
        route = "game_mode",
        label = "MODO JOGO",
        shortTitle = "Jogo",
        selectedIcon = Icons.Filled.SportsEsports,
        unselectedIcon = Icons.Outlined.SportsEsports
    ),
    SYSTEM_TWEAKS(
        route = "system_tweaks",
        label = "SISTEMA & REDE",
        shortTitle = "Sistema",
        selectedIcon = Icons.Filled.Tune,
        unselectedIcon = Icons.Outlined.Tune
    ),
    MODULES(
        route = "modules",
        label = "MÓDULOS & SHIZUKU",
        shortTitle = "Módulos",
        selectedIcon = Icons.Filled.Extension,
        unselectedIcon = Icons.Outlined.Extension
    ),
    RAM_ANALYZER(
        route = "ram_analyzer",
        label = "RAM ANALYZER",
        shortTitle = "RAM",
        selectedIcon = Icons.Filled.Memory,
        unselectedIcon = Icons.Outlined.Memory
    ),
    CPU_ANALYZER(
        route = "cpu_analyzer",
        label = "CPU ANALYZER",
        shortTitle = "CPU",
        selectedIcon = Icons.Filled.DeveloperBoard,
        unselectedIcon = Icons.Outlined.DeveloperBoard
    ),
    STORAGE(
        route = "storage",
        label = "STORAGE",
        shortTitle = "Storage",
        selectedIcon = Icons.Filled.Storage,
        unselectedIcon = Icons.Outlined.Storage
    ),
    BATTERY(
        route = "battery",
        label = "BATTERY",
        shortTitle = "Bateria",
        selectedIcon = Icons.Filled.BatteryChargingFull,
        unselectedIcon = Icons.Outlined.BatteryChargingFull
    ),
    DISPLAY(
        route = "display",
        label = "DISPLAY",
        shortTitle = "Display",
        selectedIcon = Icons.Filled.DisplaySettings,
        unselectedIcon = Icons.Outlined.DisplaySettings
    ),
    GPU_INFO(
        route = "gpu_info",
        label = "GPU INFO",
        shortTitle = "GPU",
        selectedIcon = Icons.Filled.VideogameAsset,
        unselectedIcon = Icons.Outlined.VideogameAsset
    ),
    SYSTEM_DIAGNOSTIC(
        route = "system_diagnostic",
        label = "SYSTEM DIAGNOSTIC",
        shortTitle = "Diagnóstico",
        selectedIcon = Icons.Filled.HealthAndSafety,
        unselectedIcon = Icons.Outlined.HealthAndSafety
    ),
    DEVICE_INFO(
        route = "device_info",
        label = "DEVICE INFO",
        shortTitle = "Device",
        selectedIcon = Icons.Filled.PermDeviceInformation,
        unselectedIcon = Icons.Outlined.PermDeviceInformation
    ),
    SETTINGS(
        route = "settings",
        label = "SETTINGS",
        shortTitle = "Ajustes",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings
    );

    companion object {
        val primaryBottomTabs: List<BotNavDestination> = listOf(
            HOME,
            GAME_MODE,
            SYSTEM_TWEAKS,
            MODULES
        )

        fun fromRoute(route: String?): BotNavDestination =
            entries.firstOrNull { it.route == route } ?: HOME
    }
}
