package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.AvailabilityBadge
import com.example.ui.components.BotGlassCard
import com.example.ui.components.LimitationNoticeCard
import com.example.ui.components.NeonAreaLineChart
import com.example.ui.components.NeonRadialGauge
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusRestricted
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.TextSecondary
import com.example.util.Formatters

@Composable
fun BatteryAnalyzerScreen(
    state: SystemTelemetryState,
    onRefreshClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val battery = state.battery
    val level = battery.levelPercent
    val progress = ((level ?: 0) / 100f).coerceIn(0f, 1f)
    val gaugeColor = when {
        battery.isCharging -> StatusOk
        (level ?: 100) <= 20 -> NeonRed
        else -> StatusOk
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "BATTERY ANALYZER",
                    subtitle = "${battery.statusLabel} • ${battery.pluggedSourceLabel}",
                    icon = Icons.Filled.BatteryChargingFull,
                    trailing = { AvailabilityBadge(battery.availability) }
                )
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    NeonRadialGauge(
                        progress = progress,
                        centerLabel = level?.let { "$it%" } ?: "N/D",
                        subtitle = if (battery.isCharging) "CARREGANDO" else "BATERIA",
                        size = 132.dp,
                        accentColor = gaugeColor
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        TelemetrySpecRow("Estado", battery.statusLabel)
                        TelemetrySpecRow("Fonte de Energia", battery.pluggedSourceLabel)
                        TelemetrySpecRow(
                            label = "Tempo Estimado",
                            value = if (battery.isCharging) {
                                Formatters.formatChargeTimeRemaining(battery.chargeTimeRemainingMs)
                            } else {
                                "Apenas durante carga"
                            },
                            valueColor = if (battery.chargeTimeRemainingMs != null) StatusOk else StatusRestricted,
                            showDivider = false
                        )
                    }
                }
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "TELEMETRIA DO CONTROLADOR DE ENERGIA",
                    subtitle = "Exibindo apenas valores reais expostos pelo Android OS",
                    icon = Icons.Filled.Bolt
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Tecnologia", battery.technology ?: "Não reportada")
                TelemetrySpecRow("Tensão (Voltagem)", battery.voltageMv?.let { "$it mV" } ?: "Indisponível")
                TelemetrySpecRow(
                    label = "Temperatura",
                    value = battery.temperatureC?.let { String.format(java.util.Locale.US, "%.1f °C", it) } ?: "Não reportada pelo sensor",
                    valueColor = if (battery.temperatureC != null) TextSecondary else StatusRestricted
                )
                TelemetrySpecRow(
                    label = "Saúde Reportada (OS)",
                    value = battery.healthLabel ?: "Não reportada pelo OS",
                    valueColor = if (battery.healthLabel != null) StatusOk else StatusRestricted
                )
                TelemetrySpecRow(
                    label = "Corrente Instantânea",
                    value = battery.currentNowMa?.let { "$it mA" } ?: "Indisponível"
                )
                TelemetrySpecRow(
                    label = "Contador de Carga",
                    value = battery.chargeCounterUah?.let { "${it / 1000} mAh" } ?: "Indisponível",
                    showDivider = false
                )
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "HISTÓRICO DA BATERIA",
                    subtitle = "Variação percentual capturada na sessão",
                    icon = Icons.Outlined.Timeline
                )
                Spacer(Modifier.height(12.dp))
                NeonAreaLineChart(
                    values = state.batteryHistory.map { it.levelPercent.toFloat() },
                    minValue = 0f,
                    maxValue = 100f,
                    unitSuffix = "%",
                    lineColor = gaugeColor,
                    chartHeight = 145.dp
                )
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "DIAGNÓSTICO BÁSICO DE ENERGIA",
                    subtitle = "Avaliação baseada nas leituras atuais",
                    icon = Icons.Filled.BatteryChargingFull
                )
                Spacer(Modifier.height(8.dp))
                val diagMsg = when {
                    level == null -> "O dispositivo não forneceu percentual de bateria."
                    level <= 15 && !battery.isCharging -> "Carga crítica ($level%). Recomenda-se conectar o carregador imediatamente."
                    (battery.temperatureC ?: 0f) >= 43f -> "Temperatura elevada (${battery.temperatureC} °C). Evite uso intenso enquanto carrega."
                    battery.isCharging -> "Recebendo energia via ${battery.pluggedSourceLabel}. Monitoramento ativo."
                    else -> "Operação normal em bateria ($level%)."
                }
                Text(
                    text = diagMsg,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if ((level ?: 100) <= 15 && !battery.isCharging) StatusWarn else TextSecondary
                )
            }
        }

        item {
            LimitationNoticeCard(
                title = "POLÍTICA DE DADOS REAIS DE BATERIA",
                message = battery.limitationNote
            )
        }

        item {
            NeonSecondaryButton(
                text = "ATUALIZAR LEITURA DE BATERIA",
                icon = Icons.Filled.Refresh,
                onClick = onRefreshClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("battery_refresh_button")
            )
        }
    }
}
