package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.AvailabilityBadge
import com.example.ui.components.BotGlassCard
import com.example.ui.components.LimitationNoticeCard
import com.example.ui.components.NeonAreaLineChart
import com.example.ui.components.NeonCoreFrequencyBars
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusRestricted
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TextSecondary
import com.example.util.Formatters

@Composable
fun CpuAnalyzerScreen(
    state: SystemTelemetryState,
    onOpenGpuInfo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cpu = state.cpu
    val gpu = state.gpu

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "CPU ANALYZER",
                    subtitle = "${cpu.logicalProcessors} Processadores Lógicos • ${cpu.primaryAbi}",
                    icon = Icons.Filled.DeveloperBoard,
                    trailing = { AvailabilityBadge(cpu.availability) }
                )
                Spacer(Modifier.height(12.dp))
                TelemetrySpecRow("Processadores Lógicos", "${cpu.logicalProcessors} threads")
                TelemetrySpecRow("Arquitetura OS", cpu.osArch)
                TelemetrySpecRow("ABIs Suportadas", cpu.supportedAbis.joinToString(", ").ifEmpty { "Indisponível" })
                TelemetrySpecRow("SoC / Modelo", listOfNotNull(cpu.socManufacturer, cpu.socModel).joinToString(" ").ifBlank { cpu.cpuModelName ?: "Não exposto" })
                TelemetrySpecRow("Hardware / Board", "${cpu.hardware} • ${cpu.board}")
                TelemetrySpecRow(
                    label = "Leitura /proc/stat",
                    value = if (cpu.systemStatAccessible) "Acessível" else "Restrita pelo SELinux",
                    valueColor = if (cpu.systemStatAccessible) StatusOk else StatusRestricted,
                    showDivider = false
                )
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "FREQUÊNCIA POR NÚCLEO",
                    subtitle = "${cpu.coreFreqAccessibleCount}/${cpu.logicalProcessors} núcleos com leitura sysfs",
                    icon = Icons.Filled.Memory
                )
                Spacer(Modifier.height(12.dp))
                if (cpu.coreFreqAccessibleCount > 0) {
                    val maxOverall = cpu.cores.mapNotNull { it.maxFreqKhz ?: it.currentFreqKhz }.maxOrNull()?.toFloat() ?: 1f
                    val barItems = cpu.cores.map { core ->
                        val curText = Formatters.formatKhzToMhzOrGhz(core.currentFreqKhz ?: core.maxFreqKhz)
                        val frac = ((core.currentFreqKhz ?: core.maxFreqKhz ?: 0L).toFloat() / maxOverall).coerceIn(0f, 1f)
                        "CPU${core.coreIndex} ($curText)" to frac
                    }
                    NeonCoreFrequencyBars(items = barItems)
                } else {
                    Text(
                        text = "O kernel bloqueou a leitura direta de /sys/devices/system/cpu/cpu*/cpufreq neste dispositivo. Nenhum valor simulado foi exibido.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusWarn
                    )
                }
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "TELEMETRIA REAL DE CPU DO PROCESSO",
                    subtitle = "Tempo de CPU do app via Process.getElapsedCpuTime()",
                    icon = Icons.Outlined.Timeline
                )
                Spacer(Modifier.height(12.dp))
                NeonAreaLineChart(
                    values = state.cpuHistory.map { it.processCpuPercent },
                    minValue = 0f,
                    maxValue = 100f,
                    unitSuffix = "%",
                    lineColor = TelemetryCyan,
                    emptyMessage = "Coletando amostras reais de tempo de CPU do processo...",
                    chartHeight = 150.dp
                )
            }
        }

        item {
            BotGlassCard(onClick = onOpenGpuInfo) {
                SectionHeader(
                    title = "GPU DETECTADA (OPENGL ES / EGL)",
                    subtitle = gpu.renderer ?: "Sonda OpenGL ES ${gpu.glEsSystemVersion}",
                    icon = Icons.Filled.VideogameAsset,
                    trailing = { AvailabilityBadge(gpu.availability) }
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Renderizador GPU", gpu.renderer ?: "Indisponível")
                TelemetrySpecRow("Fabricante GPU", gpu.vendor ?: "Indisponível")
                TelemetrySpecRow("OpenGL ES", gpu.glVersion ?: gpu.glEsSystemVersion, showDivider = false)
                Spacer(Modifier.height(10.dp))
                NeonSecondaryButton(
                    text = "ABRIR GPU INFO COMPLETO",
                    icon = Icons.Filled.VideogameAsset,
                    onClick = onOpenGpuInfo,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cpu_open_gpu_button")
                )
            }
        }

        item {
            val is64Bit = cpu.supportedAbis.any { it.contains("64") }
            BotGlassCard {
                SectionHeader(
                    title = "DIAGNÓSTICO DE COMPATIBILIDADE",
                    subtitle = "Verificação de instruções e recursos",
                    icon = Icons.Filled.DeveloperBoard
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Suporte 64-bit", if (is64Bit) "Compatível (arm64 / x86_64)" else "Apenas 32-bit", if (is64Bit) StatusOk else StatusWarn)
                TelemetrySpecRow("Multiprocessamento", if (cpu.logicalProcessors >= 4) "Adequado (${cpu.logicalProcessors} núcleos)" else "Básico (${cpu.logicalProcessors} núcleos)")
                TelemetrySpecRow("Features CPU", cpu.cpuFeatures?.take(120) ?: "Não expostas pelo /proc/cpuinfo", showDivider = false)
            }
        }

        item {
            LimitationNoticeCard(
                title = "LIMITAÇÕES DE CPU NO ANDROID",
                message = cpu.limitationNote
            )
        }
    }
}
