package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PermDeviceInformation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.BotGlassCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.StatusOk
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.Formatters

@Composable
fun DeviceInfoScreen(
    state: SystemTelemetryState,
    modifier: Modifier = Modifier
) {
    val dev = state.device
    var sensorQuery by remember { mutableStateOf("") }
    val filteredSensors = remember(dev.sensors, sensorQuery) {
        if (sensorQuery.isBlank()) dev.sensors
        else dev.sensors.filter {
            it.name.contains(sensorQuery.trim(), ignoreCase = true) ||
                it.typeLabel.contains(sensorQuery.trim(), ignoreCase = true) ||
                it.vendor.contains(sensorQuery.trim(), ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "DEVICE INFO",
                    subtitle = "${dev.manufacturer} ${dev.model}",
                    icon = Icons.Filled.PermDeviceInformation
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Fabricante", dev.manufacturer)
                TelemetrySpecRow("Marca", dev.brand)
                TelemetrySpecRow("Modelo", dev.model)
                TelemetrySpecRow("Codinome / Device", "${dev.device} (${dev.product})")
                TelemetrySpecRow("Board / Hardware", "${dev.board} • ${dev.hardware}")
                TelemetrySpecRow("Bootloader", dev.bootloader, showDivider = false)
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "SISTEMA & KERNEL",
                    subtitle = "Android ${dev.androidVersion} (API ${dev.sdkInt})",
                    icon = Icons.Filled.Shield
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Versão Android", "Android ${dev.androidVersion} (SDK ${dev.sdkInt})", StatusOk)
                TelemetrySpecRow("Patch de Segurança", dev.securityPatch ?: "Não informado")
                TelemetrySpecRow("Build ID", dev.buildId)
                TelemetrySpecRow("Runtime / VM", dev.vmName)
                TelemetrySpecRow("Tempo Ligado (Uptime)", Formatters.formatUptime(dev.uptimeMs))
                TelemetrySpecRow("Rede Ativa", "${dev.networkStatus} (${dev.networkTransport})")
                TelemetrySpecRow("Kernel", dev.kernelVersion)
                TelemetrySpecRow("Fingerprint", dev.fingerprint, showDivider = false)
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "SENSORES DE HARDWARE",
                    subtitle = "${dev.sensors.size} sensores detectados via SensorManager",
                    icon = Icons.Filled.Sensors
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = sensorQuery,
                    onValueChange = { sensorQuery = it },
                    placeholder = { Text("Buscar sensor (acelerômetro, giroscópio...)", color = TextMuted) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = NeonRed) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonRedBorder,
                        unfocusedBorderColor = SubtleBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("device_sensor_search")
                )
                if (filteredSensors.isEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Nenhum sensor encontrado.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        items(filteredSensors) { sensor ->
            BotGlassCard {
                Text(
                    text = sensor.typeLabel.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonRed
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = sensor.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Spacer(Modifier.height(6.dp))
                TelemetrySpecRow("Fabricante", sensor.vendor)
                TelemetrySpecRow(
                    label = "Consumo Nominal",
                    value = String.format(java.util.Locale.US, "%.2f mA", sensor.powerMa),
                    showDivider = false
                )
            }
        }
    }
}
