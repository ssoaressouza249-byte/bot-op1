package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.HdrOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.AvailabilityBadge
import com.example.ui.components.BotGlassCard
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.StatusOk
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DisplayAnalyzerScreen(
    state: SystemTelemetryState,
    onRefreshClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val d = state.display
    val ratio = if (d.heightPx > 0 && d.widthPx > 0) {
        (d.widthPx.toFloat() / d.heightPx.toFloat()).coerceIn(0.4f, 2.4f)
    } else 0.56f

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "DISPLAY ANALYZER",
                    subtitle = "${d.widthPx} × ${d.heightPx} px • ${d.refreshRateHz.toInt()} Hz",
                    icon = Icons.Filled.DisplaySettings,
                    trailing = { AvailabilityBadge(d.availability) }
                )
                Spacer(Modifier.height(16.dp))

                // Proportional Visual Screen Preview
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 170.dp)
                            .fillMaxWidth(0.45f)
                            .aspectRatio(ratio)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        NeonRed.copy(alpha = 0.22f),
                                        SurfaceElevated
                                    )
                                ),
                                RoundedCornerShape(14.dp)
                            )
                            .border(1.5.dp, NeonRedBorder, RoundedCornerShape(14.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${d.widthPx}×${d.heightPx}",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = String.format(java.util.Locale.US, "~%.1f\" • %d dpi", d.approximateDiagonalInches, d.densityDpi),
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonRed
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = d.orientationLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "DIMENSÕES & DENSIDADE",
                    subtitle = "Métricas reais do WindowMetrics e DisplayMetrics",
                    icon = Icons.Filled.DisplaySettings
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Resolução Real (px)", "${d.widthPx} × ${d.heightPx} px")
                TelemetrySpecRow("Dimensões Lógicas (dp)", "${d.widthDp} × ${d.heightDp} dp")
                TelemetrySpecRow("Largura / Altura", "${d.widthPx} px / ${d.heightPx} px")
                TelemetrySpecRow("Densidade (Scale)", "${d.density}x (${d.densityDpi} dpi)")
                TelemetrySpecRow("Classificação DPI", d.densityBucket)
                TelemetrySpecRow("PPI Real (X / Y)", String.format(java.util.Locale.US, "%.1f × %.1f ppi", d.xdpi, d.ydpi))
                TelemetrySpecRow("Diagonal Aproximada", String.format(java.util.Locale.US, "%.2f polegadas", d.approximateDiagonalInches))
                TelemetrySpecRow("Orientação Atual", d.orientationLabel, showDivider = false)
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "CAPACIDADES GRÁFICAS DA TELA",
                    subtitle = "Taxa de atualização, gama de cores e HDR",
                    icon = Icons.Filled.HdrOn
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Taxa Atual", String.format(java.util.Locale.US, "%.1f Hz", d.refreshRateHz), StatusOk)
                TelemetrySpecRow(
                    label = "Modos Suportados",
                    value = d.supportedRefreshRatesHz.joinToString(" • ") { "${it.toInt()} Hz" }.ifBlank { "60 Hz" }
                )
                TelemetrySpecRow(
                    label = "Wide Color Gamut",
                    value = if (d.isWideColorGamut) "Suportado" else "Padrão sRGB",
                    valueColor = if (d.isWideColorGamut) StatusOk else TextSecondary
                )
                TelemetrySpecRow(
                    label = "Capacidades HDR",
                    value = if (d.hdrCapabilities.isEmpty()) "Não reportado / SDR" else d.hdrCapabilities.joinToString(", "),
                    showDivider = false
                )
            }
        }

        item {
            NeonSecondaryButton(
                text = "ATUALIZAR DADOS DO DISPLAY",
                icon = Icons.Filled.Refresh,
                onClick = onRefreshClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("display_refresh_button")
            )
        }
    }
}
