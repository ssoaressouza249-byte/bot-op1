package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.ScreenLockRotation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.FeatureStatus
import com.example.data.model.OptimizationState
import com.example.shizuku.ShizukuStatus
import com.example.ui.components.BotGlassCard
import com.example.ui.components.FeatureStatusBadge
import com.example.ui.components.NeonPrimaryButton
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.OptimizationToggleCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusOkBg
import com.example.ui.theme.StatusRestricted
import com.example.ui.theme.StatusRestrictedBg
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.SurfaceCarbon
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GameOptimizationScreen(
    optState: OptimizationState,
    shizukuStatus: ShizukuStatus,
    onLaunchNativeEngine: () -> Unit,
    onToggleAutoDnd: (Boolean) -> Unit,
    onToggleNoPopups: (Boolean) -> Unit,
    onToggleThermalShield: (Boolean) -> Unit,
    onToggleZeroAnimation: (Boolean) -> Unit,
    onToggleRotationLocked: (Boolean) -> Unit,
    onToggleNoVibration: (Boolean) -> Unit,
    onSelectDpi: (Int) -> Unit,
    onApplyDpi: () -> Unit,
    onKeepDpi: () -> Unit,
    onRevertDpi: () -> Unit,
    onSelectLongPress: (Int?) -> Unit,
    onSelectPointerSpeed: (Int) -> Unit,
    onToggleSensitiveTouch: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    // 15-second DPI Safety Countdown Dialog
    if (optState.dpiCountdown.isActive) {
        AlertDialog(
            onDismissRequest = onRevertDpi,
            containerColor = SurfaceCarbon,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = {
                Text(
                    text = "CONFIRMAR NOVO DPI (${optState.dpiCountdown.appliedDpi})",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = "O DPI foi alterado de ${optState.dpiCountdown.originalDpi} para ${optState.dpiCountdown.appliedDpi}. " +
                        "Revertendo automaticamente em ${optState.dpiCountdown.secondsRemaining}s caso não confirme.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = onKeepDpi,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonRed)
                ) {
                    Text("Manter (${optState.dpiCountdown.secondsRemaining}s)")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = onRevertDpi) {
                    Text("Reverter", color = TextPrimary)
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Smart Native Game Engine Banner
        item {
            BotGlassCard(highlightBorder = optState.nativeGameEngine.detected) {
                SectionHeader(
                    title = "MOTOR DE JOGOS NATIVO",
                    subtitle = optState.nativeGameEngine.engineName,
                    icon = Icons.Filled.SportsEsports,
                    trailing = {
                        if (optState.nativeGameEngine.detected) {
                            StatusPill("Detectado", StatusOk, StatusOkBg)
                        } else {
                            StatusPill("Indisponível", StatusRestricted, StatusRestrictedBg)
                        }
                    }
                )
                Spacer(Modifier.height(10.dp))
                if (optState.nativeGameEngine.detected) {
                    Text(
                        text = "Pacote detectado: ${optState.nativeGameEngine.packageName}. Abra o painel nativo do fabricante para perfis específicos por jogo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(10.dp))
                    NeonPrimaryButton(
                        text = "ABRIR ${optState.nativeGameEngine.engineName.uppercase()}",
                        icon = Icons.Filled.Launch,
                        onClick = onLaunchNativeEngine,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("launch_native_game_engine_button")
                    )
                } else {
                    Text(
                        text = "Nenhum motor OEM (Motorola Gametime, Samsung Game Booster, Game Turbo etc.) instalado neste dispositivo. Os controles do BOT OP1 permanecem ativos abaixo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Category 1: Durante o jogo
        item {
            Text(
                text = "DURANTE O JOGO",
                style = MaterialTheme.typography.titleSmall,
                color = NeonRed
            )
        }

        item {
            val status = when {
                optState.autoDndEnabled -> FeatureStatus.ACTIVE
                !optState.hasDndPolicyAccess -> FeatureStatus.REQUIRES_PERMISSION
                else -> FeatureStatus.OFF
            }
            OptimizationToggleCard(
                title = "Ativar Não Perturbe automaticamente",
                description = "Usa NotificationManager.setInterruptionFilter para silenciar alertas e chamadas durante a partida.",
                icon = Icons.Filled.DoNotDisturbOn,
                checked = optState.autoDndEnabled,
                status = status,
                onCheckedChange = onToggleAutoDnd
            )
        }

        item {
            val status = when {
                optState.noPopupsEnabled -> FeatureStatus.ACTIVE
                !shizukuStatus.isReady -> FeatureStatus.REQUIRES_SHIZUKU
                else -> FeatureStatus.OFF
            }
            OptimizationToggleCard(
                title = "Sem Pop-ups na Partida",
                description = "Desativa banners flutuantes (heads_up_notifications_enabled = 0) via Shizuku ou abre ajustes de notificação.",
                icon = Icons.Filled.NotificationsOff,
                checked = optState.noPopupsEnabled,
                status = status,
                onCheckedChange = onToggleNoPopups
            )
        }

        item {
            val tempC = optState.thermalInfo.temperatureC
            val status = when {
                optState.thermalShieldEnabled -> FeatureStatus.ACTIVE
                !optState.hasWriteSettings -> FeatureStatus.REQUIRES_PERMISSION
                else -> FeatureStatus.OFF
            }
            val tempText = tempC?.let { String.format(java.util.Locale.US, "%.1f°C", it) } ?: "Sensor indisponível"
            OptimizationToggleCard(
                title = "Escudo Térmico (Limite 39°C)",
                description = "Temperatura atual: $tempText. Acima de 39°C reduz automaticamente o brilho via WRITE_SETTINGS para conter aquecimento.",
                icon = Icons.Filled.Thermostat,
                checked = optState.thermalShieldEnabled,
                status = status,
                onCheckedChange = onToggleThermalShield
            )
        }

        item {
            val status = when {
                optState.zeroAnimationEnabled -> FeatureStatus.ACTIVE
                !shizukuStatus.isReady -> FeatureStatus.REQUIRES_SHIZUKU
                else -> FeatureStatus.OFF
            }
            OptimizationToggleCard(
                title = "Zero Animação",
                description = "Define WINDOW, TRANSITION e ANIMATOR_DURATION_SCALE para 0.0x via Shizuku ou abre Opções do Desenvolvedor.",
                icon = Icons.Filled.Animation,
                checked = optState.zeroAnimationEnabled,
                status = status,
                onCheckedChange = onToggleZeroAnimation
            )
        }

        item {
            val status = when {
                optState.rotationLockedEnabled -> FeatureStatus.ACTIVE
                !optState.hasWriteSettings -> FeatureStatus.REQUIRES_PERMISSION
                else -> FeatureStatus.OFF
            }
            OptimizationToggleCard(
                title = "Rotação Travada",
                description = "Bloqueia ACCELEROMETER_ROTATION = 0 usando WRITE_SETTINGS para impedir giros acidentais.",
                icon = Icons.Filled.ScreenLockRotation,
                checked = optState.rotationLockedEnabled,
                status = status,
                onCheckedChange = onToggleRotationLocked
            )
        }

        item {
            val status = when {
                optState.noVibrationEnabled -> FeatureStatus.ACTIVE
                !optState.hasWriteSettings && !shizukuStatus.isReady -> FeatureStatus.REQUIRES_PERMISSION
                else -> FeatureStatus.OFF
            }
            OptimizationToggleCard(
                title = "Sem Vibração",
                description = "Desativa retorno tátil e vibração do sistema (HAPTIC_FEEDBACK_ENABLED = 0) enquanto o perfil estiver ativo.",
                icon = Icons.Filled.Vibration,
                checked = optState.noVibrationEnabled,
                status = status,
                onCheckedChange = onToggleNoVibration
            )
        }

        // Category 2: Toque, Mira e DPI
        item {
            Spacer(Modifier.height(4.dp))
            Text(
                text = "TOQUE, MIRA E DPI",
                style = MaterialTheme.typography.titleSmall,
                color = NeonRed
            )
        }

        // 1. Custom DPI Card
        item {
            val dpiStatus = when {
                optState.currentDpi != optState.originalDpi -> FeatureStatus.ACTIVE
                !shizukuStatus.isReady -> FeatureStatus.REQUIRES_SHIZUKU
                else -> FeatureStatus.OFF
            }
            val scaleFactor = (optState.currentDpi.toFloat() / optState.selectedDpi.toFloat()).coerceIn(0.65f, 1.5f)
            BotGlassCard(highlightBorder = optState.currentDpi != optState.originalDpi) {
                SectionHeader(
                    title = "DPI Personalizado",
                    subtitle = "Atual: ${optState.currentDpi} dpi • Selecionado: ${optState.selectedDpi} dpi",
                    icon = Icons.Filled.AspectRatio,
                    trailing = { FeatureStatusBadge(dpiStatus) }
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Ajusta a densidade via 'wm density' (280–550) com contagem regressiva de segurança de 15s. Preview de escala: ${String.format(java.util.Locale.US, "%.2fx", scaleFactor)}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                Slider(
                    value = optState.selectedDpi.toFloat(),
                    onValueChange = { onSelectDpi(it.roundToInt()) },
                    valueRange = 280f..550f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonRed,
                        activeTrackColor = NeonRed,
                        inactiveTrackColor = SurfaceElevated
                    )
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(320, 380, 420, 480, 540).forEach { preset ->
                        FilterChip(
                            selected = optState.selectedDpi == preset,
                            onClick = { onSelectDpi(preset) },
                            label = { Text("$preset") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonRed,
                                selectedLabelColor = TextPrimary,
                                containerColor = SurfaceElevated,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NeonPrimaryButton(
                        text = "APLICAR DPI",
                        icon = Icons.Filled.AspectRatio,
                        onClick = onApplyDpi,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("apply_dpi_button")
                    )
                    if (optState.currentDpi != optState.originalDpi) {
                        NeonSecondaryButton(
                            text = "RESETAR",
                            icon = Icons.Filled.AspectRatio,
                            onClick = onRevertDpi,
                            modifier = Modifier.weight(0.75f)
                        )
                    }
                }
            }
        }

        // 2. Long Press Timeout Card
        item {
            val lpStatus = when {
                optState.longPressTimeoutMs != null && optState.longPressTimeoutMs != 400 -> FeatureStatus.ACTIVE
                !shizukuStatus.isReady -> FeatureStatus.REQUIRES_SHIZUKU
                else -> FeatureStatus.OFF
            }
            val options = listOf<Pair<String, Int?>>(
                "Padrão" to null,
                "150ms" to 150,
                "200ms" to 200,
                "250ms" to 250,
                "300ms" to 300,
                "400ms" to 400
            )
            BotGlassCard {
                SectionHeader(
                    title = "Tempo do Toque Longo",
                    subtitle = optState.longPressTimeoutMs?.let { "Atual no OS: ${it}ms" } ?: "Padrão do sistema",
                    icon = Icons.Filled.TouchApp,
                    trailing = { FeatureStatusBadge(lpStatus) }
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Ajusta long_press_timeout em Settings.Secure via Shizuku ou abre Acessibilidade.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    options.forEach { (label, ms) ->
                        val selected = if (ms == null) optState.longPressTimeoutMs == null else optState.longPressTimeoutMs == ms
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectLongPress(ms) },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonRed,
                                selectedLabelColor = TextPrimary,
                                containerColor = SurfaceElevated,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                borderColor = SubtleBorder,
                                selectedBorderColor = NeonRedBorder
                            )
                        )
                    }
                }
            }
        }

        // 3. Pointer Speed Card
        item {
            val psStatus = when {
                optState.pointerSpeed != 0 -> FeatureStatus.ACTIVE
                !shizukuStatus.isReady && !optState.hasWriteSettings -> FeatureStatus.REQUIRES_SHIZUKU
                else -> FeatureStatus.OFF
            }
            val speeds = listOf(-3, 0, 3, 5, 7)
            BotGlassCard {
                SectionHeader(
                    title = "Velocidade do Ponteiro",
                    subtitle = "Atual: ${if (optState.pointerSpeed > 0) "+${optState.pointerSpeed}" else "${optState.pointerSpeed}"}",
                    icon = Icons.Filled.Speed,
                    trailing = { FeatureStatusBadge(psStatus) }
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Ajusta Settings.System.POINTER_SPEED (-3 a +7) para resposta de mira/cursor.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    speeds.forEach { sp ->
                        val selected = optState.pointerSpeed == sp
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectPointerSpeed(sp) },
                            label = { Text(if (sp > 0) "+$sp" else "$sp") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonRed,
                                selectedLabelColor = TextPrimary,
                                containerColor = SurfaceElevated,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }
            }
        }

        // 4. Sensitive Touch
        item {
            val stStatus = when {
                optState.sensitiveTouchEnabled -> FeatureStatus.ACTIVE
                !shizukuStatus.isReady -> FeatureStatus.REQUIRES_SHIZUKU
                else -> FeatureStatus.OFF
            }
            OptimizationToggleCard(
                title = "Toque Sensível",
                description = "Ativa sensibilidade aumentada do painel (touch_sensitivity / modo película) via Shizuku ou abre Tela.",
                icon = Icons.Filled.TouchApp,
                checked = optState.sensitiveTouchEnabled,
                status = stStatus,
                onCheckedChange = onToggleSensitiveTouch
            )
        }
    }
}
