package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.AvailabilityBadge
import com.example.ui.components.BotGlassCard
import com.example.ui.components.LimitationNoticeCard
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.StatusOk
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GpuInfoScreen(
    state: SystemTelemetryState,
    onRefreshClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val gpu = state.gpu
    var query by remember { mutableStateOf("") }
    val filteredExtensions = remember(gpu.extensions, query) {
        if (query.isBlank()) gpu.extensions
        else gpu.extensions.filter { it.contains(query.trim(), ignoreCase = true) }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "GPU INFO",
                    subtitle = gpu.renderer ?: "OpenGL ES ${gpu.glEsSystemVersion}",
                    icon = Icons.Filled.VideogameAsset,
                    trailing = { AvailabilityBadge(gpu.availability) }
                )
                Spacer(Modifier.height(12.dp))
                TelemetrySpecRow("Renderizador (GL_RENDERER)", gpu.renderer ?: "Indisponível", StatusOk)
                TelemetrySpecRow("Fabricante (GL_VENDOR)", gpu.vendor ?: "Indisponível")
                TelemetrySpecRow("Versão OpenGL ES", gpu.glVersion ?: gpu.glEsSystemVersion)
                TelemetrySpecRow("Versão GLSL", gpu.glslVersion ?: "Indisponível")
                TelemetrySpecRow("Versão Sistema (AM)", "OpenGL ES ${gpu.glEsSystemVersion}", showDivider = false)
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "LIMITES DO PIPELINE GRÁFICO",
                    subtitle = "Parâmetros consultados via GLES20",
                    icon = Icons.Filled.VideogameAsset
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow(
                    label = "Tamanho Máx. de Textura",
                    value = gpu.maxTextureSize?.let { "${it} × ${it} px" } ?: "Indisponível"
                )
                TelemetrySpecRow(
                    label = "Viewport Máximo",
                    value = if (gpu.maxViewportWidth != null && gpu.maxViewportHeight != null) {
                        "${gpu.maxViewportWidth} × ${gpu.maxViewportHeight} px"
                    } else "Indisponível"
                )
                TelemetrySpecRow(
                    label = "Atributos de Vértice",
                    value = gpu.maxVertexAttribs?.toString() ?: "Indisponível"
                )
                TelemetrySpecRow(
                    label = "Total de Extensões",
                    value = "${gpu.extensions.size} extensões detectadas",
                    showDivider = false
                )
            }
        }

        if (gpu.errorNote != null) {
            item {
                LimitationNoticeCard(
                    title = "OBSERVAÇÃO DA SONDA EGL",
                    message = gpu.errorNote
                )
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "EXTENSÕES OPENGL ES",
                    subtitle = "${filteredExtensions.size} de ${gpu.extensions.size} exibidas",
                    icon = Icons.Filled.Extension
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Filtrar extensões (ex: texture, depth, astc)...", color = TextMuted) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = NeonRed) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonRedBorder,
                        unfocusedBorderColor = SubtleBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gpu_extension_search")
                )
                Spacer(Modifier.height(12.dp))
                if (filteredExtensions.isEmpty()) {
                    Text(
                        text = if (gpu.extensions.isEmpty()) {
                            "Nenhuma extensão retornada pelo contexto OpenGL ES."
                        } else {
                            "Nenhuma extensão corresponde ao filtro."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                } else {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        filteredExtensions.take(80).forEach { ext ->
                            Surface(
                                color = SurfaceElevated,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = ext,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                    if (filteredExtensions.size > 80) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "+ ${filteredExtensions.size - 80} extensões adicionais. Use a busca acima para filtrar.",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }
            }
        }

        item {
            NeonSecondaryButton(
                text = "RE-SONDAR GPU AGORA",
                icon = Icons.Filled.Refresh,
                onClick = onRefreshClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("gpu_refresh_button")
            )
        }
    }
}
