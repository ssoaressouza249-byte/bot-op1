package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.DiagnosticStatus
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.BotGlassCard
import com.example.ui.components.DiagnosticStatusBadge
import com.example.ui.components.NeonAreaLineChart
import com.example.ui.components.NeonPrimaryButton
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.navigation.BotNavDestination
import com.example.ui.theme.BgPureBlack
import com.example.ui.theme.DeepCrimson
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.Formatters

@Composable
fun HomeDashboardScreen(
    state: SystemTelemetryState,
    onRefreshClick: () -> Unit,
    onRunFullDiagnostic: () -> Unit,
    onNavigate: (BotNavDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val overallStatus = state.diagnosticReport?.overallStatus ?: DiagnosticStatus.OK

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Brand Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(172.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, NeonRedBorder, RoundedCornerShape(20.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_bot_op1_banner_1794581695102),
                    contentDescription = stringResource(R.string.cd_hero_banner),
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    BgPureBlack.copy(alpha = 0.94f),
                                    BgPureBlack.copy(alpha = 0.72f),
                                    BgPureBlack.copy(alpha = 0.35f)
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.bot_op1_icon_1794581691859),
                            contentDescription = stringResource(R.string.cd_bot_logo),
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, NeonRedBorder, RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.headlineLarge,
                                color = TextPrimary
                            )
                            Text(
                                text = stringResource(R.string.app_subtitle),
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonRed
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DiagnosticStatusBadge(status = overallStatus)
                        Text(
                            text = "SYNC ${Formatters.formatTimestamp(state.lastUpdatedMs)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Primary Action Buttons
        item {
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                val isWide = maxWidth >= 460.dp
                if (isWide) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        NeonSecondaryButton(
                            text = stringResource(R.string.action_refresh_analysis),
                            icon = Icons.Filled.Refresh,
                            onClick = onRefreshClick,
                            enabled = !state.isRefreshing,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("refresh_analysis_button")
                        )
                        NeonPrimaryButton(
                            text = stringResource(R.string.action_full_diagnostic),
                            icon = Icons.Filled.HealthAndSafety,
                            onClick = onRunFullDiagnostic,
                            enabled = !state.isScanningDiagnostic,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("full_diagnostic_button")
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        NeonPrimaryButton(
                            text = stringResource(R.string.action_full_diagnostic),
                            icon = Icons.Filled.HealthAndSafety,
                            onClick = onRunFullDiagnostic,
                            enabled = !state.isScanningDiagnostic,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("full_diagnostic_button")
                        )
                        NeonSecondaryButton(
                            text = stringResource(R.string.action_refresh_analysis),
                            icon = Icons.Filled.Refresh,
                            onClick = onRefreshClick,
                            enabled = !state.isRefreshing,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("refresh_analysis_button")
                        )
                    }
                }
            }
        }

        // Device Identification Card
        item {
            BotGlassCard(
                highlightBorder = true,
                onClick = { onNavigate(BotNavDestination.DEVICE_INFO) }
            ) {
                SectionHeader(
                    title = "IDENTIFICAÇÃO DO DISPOSITIVO",
                    subtitle = "${state.device.manufacturer} ${state.device.model}",
                    icon = Icons.Filled.Smartphone,
                    trailing = {
                        Text(
                            text = "VER MAIS →",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonRed
                        )
                    }
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Fabricante / Marca", "${state.device.manufacturer} (${state.device.brand})")
                TelemetrySpecRow("Modelo / Hardware", "${state.device.model} • ${state.device.hardware}")
                TelemetrySpecRow("Sistema Android", "Android ${state.device.androidVersion} (API ${state.device.sdkInt})")
                TelemetrySpecRow("Rede & Tempo Ligado", "${state.device.networkStatus} (${state.device.networkTransport}) • ${Formatters.formatUptime(state.device.uptimeMs)}", showDivider = false)
            }
        }

        // 2x2 Subsystem Summary Grid (RAM, CPU, Storage, Battery)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val ramPct = state.ram.usedPercent
                    DashboardMetricTile(
                        title = "MEMÓRIA RAM",
                        headline = if (state.ram.totalBytes > 0) Formatters.formatPercent(ramPct) else "N/D",
                        detail = if (state.ram.totalBytes > 0) {
                            "${Formatters.formatBytes(state.ram.usedBytes)} / ${Formatters.formatBytes(state.ram.totalBytes)}"
                        } else "Indisponível",
                        progress = ramPct,
                        accent = NeonRed,
                        icon = Icons.Filled.Memory,
                        onClick = { onNavigate(BotNavDestination.RAM_ANALYZER) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_ram_card")
                    )

                    val cpuProc = state.cpu.processCpuPercent
                    DashboardMetricTile(
                        title = "CPU & NÚCLEOS",
                        headline = "${state.cpu.logicalProcessors} CORES",
                        detail = if (cpuProc != null) {
                            "App CPU: ${String.format(java.util.Locale.US, "%.1f%%", cpuProc)} • ${state.cpu.primaryAbi}"
                        } else {
                            "${state.cpu.primaryAbi} • ${state.cpu.socModel ?: state.cpu.hardware}"
                        },
                        progress = ((cpuProc ?: 15f) / 100f).coerceIn(0.08f, 1f),
                        accent = TelemetryCyan,
                        icon = Icons.Filled.DeveloperBoard,
                        onClick = { onNavigate(BotNavDestination.CPU_ANALYZER) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_cpu_card")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val storagePct = state.storage.internalUsedPercent
                    DashboardMetricTile(
                        title = "STORAGE (/data)",
                        headline = if (state.storage.internalTotalBytes > 0) Formatters.formatPercent(storagePct) else "N/D",
                        detail = "${Formatters.formatBytes(state.storage.internalAvailableBytes)} livres",
                        progress = storagePct,
                        accent = if (storagePct > 0.85f) StatusWarn else NeonRed,
                        icon = Icons.Filled.Storage,
                        onClick = { onNavigate(BotNavDestination.STORAGE) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_storage_card")
                    )

                    val batLevel = state.battery.levelPercent
                    val batPct = (batLevel ?: 0) / 100f
                    DashboardMetricTile(
                        title = "BATERIA",
                        headline = batLevel?.let { "$it%" } ?: "N/D",
                        detail = "${state.battery.statusLabel} • ${state.battery.pluggedSourceLabel}",
                        progress = batPct,
                        accent = if (state.battery.isCharging) StatusOk else if ((batLevel ?: 100) <= 20) NeonRed else StatusOk,
                        icon = Icons.Filled.BatteryChargingFull,
                        onClick = { onNavigate(BotNavDestination.BATTERY) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_battery_card")
                    )
                }
            }
        }

        // Live Telemetry Charts Card
        item {
            BotGlassCard {
                SectionHeader(
                    title = "MONITORAMENTO EM TEMPO REAL",
                    subtitle = "Histórico real coletado nesta sessão",
                    icon = Icons.Outlined.Timeline
                )
                Spacer(Modifier.height(14.dp))
                Text(
                    text = "USO DE RAM DO SISTEMA (%)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(6.dp))
                NeonAreaLineChart(
                    values = state.ramHistory.map { it.usedPercent * 100f },
                    minValue = 0f,
                    maxValue = 100f,
                    unitSuffix = "%",
                    lineColor = NeonRed,
                    chartHeight = 125.dp
                )
                Spacer(Modifier.height(14.dp))
                Text(
                    text = "NÍVEL DE BATERIA (%)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(6.dp))
                NeonAreaLineChart(
                    values = state.batteryHistory.map { it.levelPercent.toFloat() },
                    minValue = 0f,
                    maxValue = 100f,
                    unitSuffix = "%",
                    lineColor = StatusOk,
                    emptyMessage = "Aguardando amostras de bateria...",
                    chartHeight = 110.dp
                )
            }
        }
    }
}

@Composable
private fun DashboardMetricTile(
    title: String,
    headline: String,
    detail: String,
    progress: Float,
    accent: Color,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BotGlassCard(
        modifier = modifier,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            text = headline,
            style = MaterialTheme.typography.headlineMedium,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = detail,
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape),
            color = accent,
            trackColor = SurfaceElevated,
            strokeCap = StrokeCap.Round
        )
    }
}
