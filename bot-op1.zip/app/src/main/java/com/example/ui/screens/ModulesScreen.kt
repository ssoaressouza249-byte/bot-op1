package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PermDeviceInformation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.OptimizationState
import com.example.shizuku.ShizukuStatus
import com.example.ui.components.BotGlassCard
import com.example.ui.components.NeonPrimaryButton
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.navigation.BotNavDestination
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusOkBg
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.StatusWarnBg
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ModulesScreen(
    optState: OptimizationState,
    shizukuStatus: ShizukuStatus,
    onRequestShizukuPermission: () -> Unit,
    onOpenShizukuApp: () -> Unit,
    onTestShizukuCommand: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onRequestBluetoothPermission: () -> Unit,
    onOpenSystemIntent: (Intent) -> Unit,
    onNavigate: (BotNavDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Shizuku & ADB Wireless Engine Card
        item {
            val statusLabel = when {
                shizukuStatus.isReady -> "Ativo (UID ${if (shizukuStatus.privilegedUid >= 0) shizukuStatus.privilegedUid else "2000"})"
                shizukuStatus.isBinderAlive -> "Requer Permissão"
                shizukuStatus.isShizukuInstalled -> "Serviço Parado"
                else -> "Shizuku Não Instalado"
            }
            val statusFg = if (shizukuStatus.isReady) StatusOk else StatusWarn
            val statusBg = if (shizukuStatus.isReady) StatusOkBg else StatusWarnBg

            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "INTEGRAÇÃO SHIZUKU / ADB",
                    subtitle = "Comandos privilegiados sem root (Android 14+)",
                    icon = Icons.Filled.Terminal,
                    trailing = { StatusPill(statusLabel, statusFg, statusBg) }
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("App Shizuku", if (shizukuStatus.isShizukuInstalled) "Instalado" else "Não instalado")
                TelemetrySpecRow("Binder Shizuku", if (shizukuStatus.isBinderAlive) "Conectado" else "Inativo")
                TelemetrySpecRow("Permissão API", if (shizukuStatus.isPermissionGranted) "Concedida" else "Pendente")
                TelemetrySpecRow(
                    "Último Retorno",
                    shizukuStatus.lastCommandOutput.ifBlank { "Nenhum comando executado" },
                    showDivider = false
                )
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NeonPrimaryButton(
                        text = if (shizukuStatus.isReady) "TESTAR (ID)" else "AUTORIZAR",
                        icon = Icons.Filled.Terminal,
                        onClick = {
                            if (shizukuStatus.isReady) onTestShizukuCommand()
                            else onRequestShizukuPermission()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("shizuku_action_button")
                    )
                    NeonSecondaryButton(
                        text = "ABRIR SHIZUKU",
                        icon = Icons.Filled.Extension,
                        onClick = onOpenShizukuApp,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Engine & Permissions Status
        item {
            BotGlassCard {
                SectionHeader(
                    title = "STATUS DO MOTOR & PERMISSÕES",
                    subtitle = "${optState.activeFeatureCount} módulos ativos no perfil BOT OP1",
                    icon = Icons.Filled.AdminPanelSettings
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow(
                    "Modificar Sistema (WRITE_SETTINGS)",
                    if (optState.hasWriteSettings) "Concedida" else "Pendente",
                    if (optState.hasWriteSettings) StatusOk else StatusWarn
                )
                TelemetrySpecRow(
                    "Política Não Perturbe (DND)",
                    if (optState.hasDndPolicyAccess) "Concedida" else "Pendente",
                    if (optState.hasDndPolicyAccess) StatusOk else StatusWarn
                )
                TelemetrySpecRow(
                    "Notificações (Android 13+)",
                    if (optState.hasNotificationPermission) "Concedida" else "Pendente",
                    if (optState.hasNotificationPermission) StatusOk else StatusWarn
                )
                TelemetrySpecRow(
                    "Bluetooth Connect (Android 12+)",
                    if (optState.hasBluetoothPermission) "Concedida" else "Pendente",
                    if (optState.hasBluetoothPermission) StatusOk else StatusWarn,
                    showDivider = false
                )
                Spacer(Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!optState.hasWriteSettings) {
                        AssistChip(
                            onClick = {
                                onOpenSystemIntent(
                                    Intent(
                                        Settings.ACTION_MANAGE_WRITE_SETTINGS,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                )
                            },
                            label = { Text("Liberar WRITE_SETTINGS") },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = SurfaceElevated,
                                labelColor = NeonRed
                            )
                        )
                    }
                    if (!optState.hasDndPolicyAccess) {
                        AssistChip(
                            onClick = {
                                onOpenSystemIntent(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                            },
                            label = { Text("Liberar Não Perturbe") },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = SurfaceElevated,
                                labelColor = NeonRed
                            )
                        )
                    }
                    if (!optState.hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        AssistChip(
                            onClick = onRequestNotificationPermission,
                            label = { Text("Permitir Notificação") },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = SurfaceElevated,
                                labelColor = NeonRed
                            )
                        )
                    }
                    if (!optState.hasBluetoothPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        AssistChip(
                            onClick = onRequestBluetoothPermission,
                            label = { Text("Permitir Bluetooth") },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = SurfaceElevated,
                                labelColor = NeonRed
                            )
                        )
                    }
                }
            }
        }

        // System Quick Shortcuts
        item {
            BotGlassCard {
                SectionHeader(
                    title = "ATALHOS RÁPIDOS DO SISTEMA",
                    subtitle = "Acesso direto às configurações nativas do Android",
                    icon = Icons.Filled.DeveloperMode
                )
                Spacer(Modifier.height(12.dp))
                val shortcuts: List<Triple<String, ImageVector, Intent>> = listOf(
                    Triple("Opções do Desenvolvedor", Icons.Filled.DeveloperMode, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)),
                    Triple("Não Perturbe", Icons.Filled.DoNotDisturbOn, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)),
                    Triple("Economia de Bateria", Icons.Filled.BatterySaver, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)),
                    Triple("Wi-Fi / Rede", Icons.Filled.Wifi, Intent(Settings.ACTION_WIFI_SETTINGS)),
                    Triple("Tela / Taxa Hz", Icons.Filled.DisplaySettings, Intent(Settings.ACTION_DISPLAY_SETTINGS)),
                    Triple("Acessibilidade", Icons.Filled.Accessibility, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    shortcuts.forEach { (title, icon, intent) ->
                        AssistChip(
                            onClick = { onOpenSystemIntent(intent) },
                            leadingIcon = {
                                Icon(icon, contentDescription = null, tint = NeonRed)
                            },
                            label = { Text(title) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = SurfaceElevated,
                                labelColor = TextPrimary
                            ),
                            border = AssistChipDefaults.assistChipBorder(
                                enabled = true,
                                borderColor = SubtleBorder
                            )
                        )
                    }
                }
            }
        }

        // Deep Telemetry Analyzers Access
        item {
            BotGlassCard {
                SectionHeader(
                    title = "ANALISADORES & TELEMETRIA DETALHADA",
                    subtitle = "Módulos avançados de diagnóstico BOT OP1",
                    icon = Icons.Filled.HealthAndSafety
                )
                Spacer(Modifier.height(12.dp))
                val analyzers = listOf(
                    BotNavDestination.RAM_ANALYZER to Icons.Filled.Memory,
                    BotNavDestination.CPU_ANALYZER to Icons.Filled.DeveloperBoard,
                    BotNavDestination.STORAGE to Icons.Filled.Storage,
                    BotNavDestination.BATTERY to Icons.Filled.BatteryChargingFull,
                    BotNavDestination.DISPLAY to Icons.Filled.DisplaySettings,
                    BotNavDestination.GPU_INFO to Icons.Filled.VideogameAsset,
                    BotNavDestination.SYSTEM_DIAGNOSTIC to Icons.Filled.HealthAndSafety,
                    BotNavDestination.DEVICE_INFO to Icons.Filled.PermDeviceInformation,
                    BotNavDestination.SETTINGS to Icons.Filled.Settings
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    analyzers.forEach { (dest, icon) ->
                        AssistChip(
                            onClick = { onNavigate(dest) },
                            leadingIcon = {
                                Icon(icon, contentDescription = null, tint = NeonRed)
                            },
                            label = { Text(dest.shortTitle) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = SurfaceElevated,
                                labelColor = TextPrimary
                            ),
                            border = AssistChipDefaults.assistChipBorder(
                                enabled = true,
                                borderColor = NeonRedBorder.copy(alpha = 0.45f)
                            )
                        )
                    }
                }
            }
        }
    }
}
