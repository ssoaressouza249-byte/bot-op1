package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.AvailabilityBadge
import com.example.ui.components.BotGlassCard
import com.example.ui.components.LimitationNoticeCard
import com.example.ui.components.NeonAreaLineChart
import com.example.ui.components.NeonRadialGauge
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TextSecondary
import com.example.util.Formatters

@Composable
fun RamAnalyzerScreen(
    state: SystemTelemetryState,
    autoRefreshEnabled: Boolean,
    refreshIntervalSec: Int,
    onRefreshClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ram = state.ram
    val performanceAnalysis = when {
        ram.isLowMemory -> "Alerta de baixa memória ativo pelo Android OS. O sistema pode encerrar processos em segundo plano."
        ram.usedPercent > 0.85f -> "Uso elevado de RAM (${Formatters.formatPercent(ram.usedPercent)}). Multitarefa pesada pode acionar compactação de memória."
        ram.usedPercent > 0.65f -> "Uso moderado. Margem adequada para uso cotidiano e alternância de aplicativos."
        else -> "Excelente folga de memória RAM disponível para processos e cache de sistema."
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "RAM ANALYZER",
                    subtitle = if (autoRefreshEnabled) "Auto-atualização a cada ${refreshIntervalSec}s" else "Modo manual",
                    icon = Icons.Filled.Memory,
                    trailing = { AvailabilityBadge(ram.availability) }
                )
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    NeonRadialGauge(
                        progress = ram.usedPercent,
                        centerLabel = Formatters.formatPercent(ram.usedPercent),
                        subtitle = "EM USO",
                        size = 132.dp,
                        accentColor = if (ram.isLowMemory || ram.usedPercent > 0.85f) StatusWarn else NeonRed
                    )
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        TelemetrySpecRow("RAM Total", Formatters.formatBytes(ram.totalBytes))
                        TelemetrySpecRow("RAM Disponível", Formatters.formatBytes(ram.availableBytes), StatusOk)
                        TelemetrySpecRow("RAM Alocada", Formatters.formatBytes(ram.usedBytes), NeonRed, showDivider = false)
                    }
                }
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "HISTÓRICO DE MEMÓRIA",
                    subtitle = "Amostras reais de consumo RAM (%)",
                    icon = Icons.Outlined.Timeline
                )
                Spacer(Modifier.height(12.dp))
                NeonAreaLineChart(
                    values = state.ramHistory.map { it.usedPercent * 100f },
                    minValue = 0f,
                    maxValue = 100f,
                    unitSuffix = "%",
                    lineColor = NeonRed,
                    chartHeight = 160.dp
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "HEAP JVM DO PROCESSO ATUAL (MB)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(6.dp))
                NeonAreaLineChart(
                    values = state.ramHistory.map { it.appHeapUsedMb.toFloat() },
                    minValue = 0f,
                    maxValue = (ram.jvmMaxBytes / (1024f * 1024f)).coerceAtLeast(32f),
                    unitSuffix = " MB",
                    lineColor = TelemetryCyan,
                    chartHeight = 115.dp
                )
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "ANÁLISE DE DESEMPENHO & HEAP",
                    subtitle = "Métricas detalhadas do ActivityManager e ART",
                    icon = Icons.Filled.Speed
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = performanceAnalysis,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Limiar Low-Memory OS", Formatters.formatBytes(ram.lowMemoryThresholdBytes))
                TelemetrySpecRow("Estado Low-Memory", if (ram.isLowMemory) "SIM (CRÍTICO)" else "Normal", if (ram.isLowMemory) NeonRed else StatusOk)
                TelemetrySpecRow("Memory Class (App)", "${ram.memoryClassMb} MB (Large: ${ram.largeMemoryClassMb} MB)")
                TelemetrySpecRow("Heap JVM Usado / Máx", "${Formatters.formatBytes(ram.jvmUsedBytes)} / ${Formatters.formatBytes(ram.jvmMaxBytes)}")
                TelemetrySpecRow("Heap Nativo Alocado", Formatters.formatBytes(ram.nativeHeapAllocatedBytes), showDivider = false)
            }
        }

        item {
            LimitationNoticeCard(
                title = "TRANSPARÊNCIA & LIMITAÇÕES DE MEMÓRIA",
                message = ram.limitationNote
            )
        }

        item {
            NeonSecondaryButton(
                text = "ATUALIZAR LEITURA DE RAM",
                icon = Icons.Filled.Refresh,
                onClick = onRefreshClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ram_refresh_button")
            )
        }
    }
}
