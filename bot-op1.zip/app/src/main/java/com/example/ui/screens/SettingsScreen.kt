package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppSettings
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.BotGlassCard
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.BgPureBlack
import com.example.ui.theme.DeepCrimson
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.StatusOk
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    telemetry: SystemTelemetryState,
    onToggleAutoRefresh: (Boolean) -> Unit,
    onSelectInterval: (Int) -> Unit,
    onToggleHighGlow: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val intervals = listOf(1, 2, 5, 10, 30)
    val totalSamples = telemetry.ramHistory.size +
        telemetry.cpuHistory.size +
        telemetry.storageHistory.size +
        telemetry.batteryHistory.size

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "CONFIGURAÇÕES",
                    subtitle = "Preferências salvas localmente no dispositivo",
                    icon = Icons.Filled.Settings
                )
                Spacer(Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Tema Vermelho & Preto Neon Intensificado",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Realça bordas neon #FF1744 e brilho nos gráficos sobre fundo #050505.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(
                        checked = settings.highGlowMode,
                        onCheckedChange = onToggleHighGlow,
                        modifier = Modifier.testTag("settings_glow_switch"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TextPrimary,
                            checkedTrackColor = NeonRed,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = SurfaceElevated
                        )
                    )
                }

                Spacer(Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Atualização Automática",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Coleta contínua de RAM, CPU do processo, Storage e Bateria.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(
                        checked = settings.autoRefresh,
                        onCheckedChange = onToggleAutoRefresh,
                        modifier = Modifier.testTag("settings_autorefresh_switch"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TextPrimary,
                            checkedTrackColor = NeonRed,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = SurfaceElevated
                        )
                    )
                }
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "INTERVALO DE ATUALIZAÇÃO",
                    subtitle = "Frequência do loop de monitoramento",
                    icon = Icons.Filled.Timer
                )
                Spacer(Modifier.height(12.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    intervals.forEach { sec ->
                        val selected = settings.refreshIntervalSec == sec
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectInterval(sec) },
                            enabled = settings.autoRefresh,
                            label = {
                                Text(
                                    text = "${sec}s",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonRed,
                                selectedLabelColor = TextPrimary,
                                containerColor = SurfaceElevated,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = settings.autoRefresh,
                                selected = selected,
                                borderColor = SubtleBorder,
                                selectedBorderColor = NeonRedBorder
                            )
                        )
                    }
                }
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "HISTÓRICO LOCAL",
                    subtitle = "$totalSamples amostras armazenadas localmente",
                    icon = Icons.Filled.DeleteSweep
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Os gráficos históricos de RAM, Storage e Bateria são armazenados localmente via DataStore sem envio para servidores externos.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(12.dp))
                NeonSecondaryButton(
                    text = "LIMPAR HISTÓRICO LOCAL",
                    icon = Icons.Filled.DeleteSweep,
                    onClick = onClearHistory,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_clear_history_button")
                )
            }
        }

        item {
            BotGlassCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.bot_op1_icon_1794581691859),
                        contentDescription = stringResource(R.string.cd_bot_logo),
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, NeonRedBorder, RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = stringResource(R.string.app_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonRed
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                TelemetrySpecRow("Versão", stringResource(R.string.app_version_label), StatusOk)
                TelemetrySpecRow("Tema Visual", "OLED #050505 • Vermelho Neon #FF1E42")
                TelemetrySpecRow("Persistência Local", "Jetpack DataStore Preferences")
                TelemetrySpecRow(
                    label = "Compromisso de Telemetria",
                    value = "100% APIs nativas reais (sem dados fictícios)",
                    showDivider = false
                )
            }
        }
    }
}
