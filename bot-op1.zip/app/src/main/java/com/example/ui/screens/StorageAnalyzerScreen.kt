package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.AvailabilityBadge
import com.example.ui.components.BotGlassCard
import com.example.ui.components.LimitationNoticeCard
import com.example.ui.components.NeonAreaLineChart
import com.example.ui.components.NeonRadialGauge
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.TextSecondary
import com.example.util.Formatters

@Composable
fun StorageAnalyzerScreen(
    state: SystemTelemetryState,
    onRefreshClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val storage = state.storage
    val usedPct = storage.internalUsedPercent

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "STORAGE ANALYZER",
                    subtitle = "Partição Interna de Dados (/data) & Sandbox",
                    icon = Icons.Filled.Storage,
                    trailing = { AvailabilityBadge(storage.availability) }
                )
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    NeonRadialGauge(
                        progress = usedPct,
                        centerLabel = Formatters.formatPercent(usedPct),
                        subtitle = "OCUPADO",
                        size = 132.dp,
                        accentColor = if (usedPct > 0.85f) StatusWarn else NeonRed
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        TelemetrySpecRow("Total (/data)", Formatters.formatBytes(storage.internalTotalBytes))
                        TelemetrySpecRow("Disponível ao App", Formatters.formatBytes(storage.internalAvailableBytes), StatusOk)
                        TelemetrySpecRow("Usado (/data)", Formatters.formatBytes(storage.internalUsedBytes), NeonRed, showDivider = false)
                    }
                }
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "ESPAÇO & COTA DO APLICATIVO",
                    subtitle = "Medição isolada do sandbox BOT OP1",
                    icon = Icons.Filled.Folder
                )
                Spacer(Modifier.height(10.dp))
                TelemetrySpecRow("Arquivos do App (filesDir)", Formatters.formatBytes(storage.appFilesBytes))
                TelemetrySpecRow("Cache do App (cacheDir)", Formatters.formatBytes(storage.appCacheBytes))
                TelemetrySpecRow("Total Usado pelo App", Formatters.formatBytes(storage.appTotalUsedBytes))
                TelemetrySpecRow(
                    label = "Cota de Cache (StorageManager)",
                    value = storage.appCacheQuotaBytes?.let { Formatters.formatBytes(it) } ?: "Não exposta (API < 26)",
                    showDivider = false
                )
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "HISTÓRICO DE UTILIZAÇÃO",
                    subtitle = "Percentual ocupado registrado localmente",
                    icon = Icons.Outlined.Timeline
                )
                Spacer(Modifier.height(12.dp))
                NeonAreaLineChart(
                    values = state.storageHistory.map { it.usedPercent * 100f },
                    minValue = 0f,
                    maxValue = 100f,
                    unitSuffix = "%",
                    lineColor = NeonRed,
                    chartHeight = 145.dp
                )
            }
        }

        item {
            BotGlassCard {
                SectionHeader(
                    title = "RELATÓRIO DE ARMAZENAMENTO",
                    subtitle = "Análise de saúde e capacidade",
                    icon = Icons.Filled.Storage
                )
                Spacer(Modifier.height(8.dp))
                val reportText = when {
                    usedPct >= 0.90f -> "Capacidade crítica (>90%). O Android pode restringir instalações e caches."
                    usedPct >= 0.75f -> "Uso moderado-alto (${Formatters.formatPercent(usedPct)}). Monitore grandes arquivos de mídia."
                    else -> "Espaço livre saudável (${Formatters.formatBytes(storage.internalAvailableBytes)} disponíveis)."
                }
                Text(
                    text = reportText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                TelemetrySpecRow("Blocos Livres Brutos", Formatters.formatBytes(storage.internalFreeBytes), showDivider = false)
            }
        }

        item {
            LimitationNoticeCard(
                title = "ESCOPO DA PARTIÇÃO /data VS MEMÓRIA TOTAL",
                message = storage.limitationNote
            )
        }

        item {
            NeonSecondaryButton(
                text = "ATUALIZAR ARMAZENAMENTO",
                icon = Icons.Filled.Refresh,
                onClick = onRefreshClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("storage_refresh_button")
            )
        }
    }
}
