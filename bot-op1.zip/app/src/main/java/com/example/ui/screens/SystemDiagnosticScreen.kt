package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.DiagnosticStatus
import com.example.data.model.SystemTelemetryState
import com.example.ui.components.BotGlassCard
import com.example.ui.components.DiagnosticStatusBadge
import com.example.ui.components.LimitationNoticeCard
import com.example.ui.components.NeonPrimaryButton
import com.example.ui.components.NeonRadialGauge
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusRestricted
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.Formatters

@Composable
fun SystemDiagnosticScreen(
    state: SystemTelemetryState,
    onRunDiagnostic: () -> Unit,
    modifier: Modifier = Modifier
) {
    val report = state.diagnosticReport

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotGlassCard(highlightBorder = true) {
                SectionHeader(
                    title = "SYSTEM DIAGNOSTIC",
                    subtitle = if (report != null) {
                        "Última auditoria às ${Formatters.formatTimestamp(report.timestampMs)}"
                    } else {
                        "Auditoria de compatibilidade e telemetria"
                    },
                    icon = Icons.Filled.HealthAndSafety,
                    trailing = {
                        if (report != null) {
                            DiagnosticStatusBadge(report.overallStatus)
                        }
                    }
                )
                Spacer(Modifier.height(16.dp))

                if (report != null) {
                    val scoreColor = when (report.overallStatus) {
                        DiagnosticStatus.OK -> StatusOk
                        DiagnosticStatus.WARNING -> StatusWarn
                        DiagnosticStatus.RESTRICTED -> StatusRestricted
                        DiagnosticStatus.CRITICAL -> NeonRed
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        NeonRadialGauge(
                            progress = report.scorePercent / 100f,
                            centerLabel = "${report.scorePercent}%",
                            subtitle = "ÍNDICE",
                            size = 128.dp,
                            accentColor = scoreColor
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            TelemetrySpecRow("Sub-sistemas OK", "${report.okCount}", StatusOk)
                            TelemetrySpecRow("Alertas / Atenção", "${report.warningCount}", StatusWarn)
                            TelemetrySpecRow("Restritos pelo OS", "${report.restrictedCount}", StatusRestricted, showDivider = false)
                        }
                    }
                }

                AnimatedVisibility(visible = state.isScanningDiagnostic) {
                    Column(modifier = Modifier.fillMaxWidth().padding(top = 14.dp)) {
                        Text(
                            text = state.scanStepLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonRed
                        )
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { state.scanProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape),
                            color = NeonRed,
                            trackColor = SurfaceElevated,
                            strokeCap = StrokeCap.Round
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))
                NeonPrimaryButton(
                    text = if (state.isScanningDiagnostic) "ANALISANDO..." else "EXECUTAR DIAGNÓSTICO COMPLETO",
                    icon = Icons.Filled.PlayArrow,
                    onClick = onRunDiagnostic,
                    enabled = !state.isScanningDiagnostic,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("run_diagnostic_button")
                )
            }
        }

        if (report != null && report.missingDataNotes.isNotEmpty()) {
            item {
                LimitationNoticeCard(
                    title = "INFORMAÇÕES AUSENTES OU RESTRITAS PELO OS",
                    message = report.missingDataNotes.joinToString("\n• ", prefix = "• ")
                )
            }
        }

        if (report != null) {
            items(report.checks, key = { it.id }) { check ->
                BotGlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = check.subsystem,
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonRed
                            )
                            Text(
                                text = check.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                        }
                        DiagnosticStatusBadge(check.status)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = check.summary,
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = check.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val icon = when (check.status) {
                            DiagnosticStatus.OK -> Icons.Filled.CheckCircle
                            DiagnosticStatus.WARNING, DiagnosticStatus.CRITICAL -> Icons.Filled.Warning
                            DiagnosticStatus.RESTRICTED -> Icons.Filled.Info
                        }
                        val tint = when (check.status) {
                            DiagnosticStatus.OK -> StatusOk
                            DiagnosticStatus.WARNING, DiagnosticStatus.CRITICAL -> StatusWarn
                            DiagnosticStatus.RESTRICTED -> StatusRestricted
                        }
                        androidx.compose.material3.Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = tint,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        Text(
                            text = check.recommendation,
                            style = MaterialTheme.typography.bodySmall,
                            color = tint
                        )
                    }
                }
            }
        }
    }
}
