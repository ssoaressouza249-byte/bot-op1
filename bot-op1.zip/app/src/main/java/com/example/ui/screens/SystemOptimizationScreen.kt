package com.example.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DataSaverOn
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.FeatureStatus
import com.example.data.model.OptimizationState
import com.example.data.model.SystemTelemetryState
import com.example.shizuku.ShizukuStatus
import com.example.ui.components.BotGlassCard
import com.example.ui.components.FeatureStatusBadge
import com.example.ui.components.NeonPrimaryButton
import com.example.ui.components.NeonSecondaryButton
import com.example.ui.components.OptimizationToggleCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.TelemetrySpecRow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBorder
import com.example.ui.theme.StatusOk
import com.example.ui.theme.StatusOkBg
import com.example.ui.theme.StatusRestricted
import com.example.ui.theme.StatusRestrictedBg
import com.example.ui.theme.StatusWarn
import com.example.ui.theme.StatusWarnBg
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.Formatters

private enum class SystemFilter(val label: String) {
    INTERNET("Internet"),
    THERMAL_POWER("Calor e Energia"),
    CPU_CLEANER("Processador e Limpeza")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SystemOptimizationScreen(
    optState: OptimizationState,
    telemetry: SystemTelemetryState,
    shizukuStatus: ShizukuStatus,
    onRunPingTest: () -> Unit,
    onToggleCaptivePortal: (Boolean) -> Unit,
    onToggleBackgroundData: (Boolean) -> Unit,
    onTriggerBluetoothOff: (Boolean) -> Unit,
    onRequestBluetoothPermission: () -> Unit,
    onToggleNfc: (Boolean) -> Unit,
    onToggleThermalShield: (Boolean) -> Unit,
    onOpenSystemIntent: (Intent) -> Unit,
    onCleanRam: () -> Unit,
    onLoadApps: () -> Unit,
    onForceStopApp: (String) -> Unit,
    onToggleFreezeApp: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeFilter by remember { mutableStateOf(SystemFilter.INTERNET) }
    var appSearch by remember { mutableStateOf("") }

    LaunchedEffect(activeFilter) {
        if (activeFilter == SystemFilter.CPU_CLEANER) {
            onLoadApps()
        }
    }

    val filteredApps = remember(optState.installedApps, appSearch) {
        val list = if (appSearch.isBlank()) optState.installedApps
        else optState.installedApps.filter {
            it.appName.contains(appSearch.trim(), ignoreCase = true) ||
                it.packageName.contains(appSearch.trim(), ignoreCase = true)
        }
        list.take(50)
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Filter Pills
        item {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SystemFilter.entries.forEach { filter ->
                    val selected = activeFilter == filter
                    FilterChip(
                        selected = selected,
                        onClick = { activeFilter = filter },
                        label = {
                            Text(
                                text = filter.label,
                                style = MaterialTheme.typography.labelMedium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonRed,
                            selectedLabelColor = TextPrimary,
                            containerColor = SurfaceElevated,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = SubtleBorder,
                            selectedBorderColor = NeonRedBorder
                        )
                    )
                }
            }
        }

        when (activeFilter) {
            SystemFilter.INTERNET -> {
                item {
                    val lat = optState.latencyInfo
                    BotGlassCard(highlightBorder = true) {
                        SectionHeader(
                            title = "MONITOR DE PING & REDE",
                            subtitle = "${lat.transportLabel} • Host ${lat.hostTested}",
                            icon = Icons.Filled.NetworkCheck,
                            trailing = {
                                val ping = lat.pingMs
                                if (ping != null) {
                                    val color = when {
                                        ping < 60 -> StatusOk
                                        ping < 130 -> StatusWarn
                                        else -> NeonRed
                                    }
                                    StatusPill("${ping} ms", color, color.copy(alpha = 0.16f))
                                } else {
                                    StatusPill("Offline / Timeout", StatusRestricted, StatusRestrictedBg)
                                }
                            }
                        )
                        Spacer(Modifier.height(10.dp))
                        TelemetrySpecRow("Latência TCP Real", lat.pingMs?.let { "$it ms" } ?: "Sem resposta")
                        TelemetrySpecRow("Transporte Ativo", lat.transportLabel)
                        TelemetrySpecRow(
                            "Largura Estimada",
                            lat.downstreamKbps?.let { "${it / 1000} Mbps" } ?: "Indisponível"
                        )
                        TelemetrySpecRow("Economia de Dados OS", lat.dataSaverStatusLabel, showDivider = false)
                        Spacer(Modifier.height(10.dp))
                        NeonSecondaryButton(
                            text = if (lat.isTesting) "MEDINDO..." else "MEDIR PING AGORA",
                            icon = Icons.Filled.Refresh,
                            onClick = onRunPingTest,
                            enabled = !lat.isTesting,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("measure_ping_button")
                        )
                    }
                }

                item {
                    val status = when {
                        optState.captivePortalDisabled -> FeatureStatus.ACTIVE
                        !shizukuStatus.isReady -> FeatureStatus.REQUIRES_SHIZUKU
                        else -> FeatureStatus.OFF
                    }
                    OptimizationToggleCard(
                        title = "Sem Teste de Conexão (Captive Portal)",
                        description = "Define captive_portal_mode = 0 via Shizuku para evitar verificações periódicas em segundo plano.",
                        icon = Icons.Filled.WifiOff,
                        checked = optState.captivePortalDisabled,
                        status = status,
                        onCheckedChange = onToggleCaptivePortal
                    )
                }

                item {
                    val status = when {
                        optState.restrictBackgroundDataEnabled -> FeatureStatus.ACTIVE
                        !shizukuStatus.isReady -> FeatureStatus.REQUIRES_SHIZUKU
                        else -> FeatureStatus.OFF
                    }
                    OptimizationToggleCard(
                        title = "Economia de Dados / Cortar Fundo",
                        description = "Restringe tráfego em segundo plano via 'cmd netpolicy' (Shizuku) ou abre a tela nativa de Economia de Dados.",
                        icon = Icons.Filled.DataSaverOn,
                        checked = optState.restrictBackgroundDataEnabled,
                        status = status,
                        onCheckedChange = onToggleBackgroundData
                    )
                }

                item {
                    val btStatus = when {
                        !optState.hasBluetoothHardware -> FeatureStatus.UNAVAILABLE_HARDWARE
                        !optState.hasBluetoothPermission -> FeatureStatus.REQUIRES_PERMISSION
                        optState.bluetoothAutoOffInGame -> FeatureStatus.ACTIVE
                        !optState.isBluetoothEnabled -> FeatureStatus.OFF
                        else -> FeatureStatus.OFF
                    }
                    OptimizationToggleCard(
                        title = "Bluetooth Off no Jogo",
                        description = when {
                            !optState.hasBluetoothHardware -> "Hardware Bluetooth ausente neste dispositivo."
                            !optState.hasBluetoothPermission -> "Conceda BLUETOOTH_CONNECT para verificar se há fone conectado antes de desligar."
                            optState.hasBluetoothAudioConnected -> "Fone/áudio Bluetooth conectado — rádio preservado para não cortar o som."
                            else -> "Verifica fones A2DP/Headset conectados; se livre, desliga o rádio Bluetooth para economizar energia."
                        },
                        icon = Icons.Filled.BluetoothDisabled,
                        checked = optState.bluetoothAutoOffInGame,
                        status = btStatus,
                        enabled = optState.hasBluetoothHardware,
                        onCheckedChange = { wantEnable ->
                            if (!optState.hasBluetoothPermission) {
                                onRequestBluetoothPermission()
                            } else {
                                onTriggerBluetoothOff(wantEnable)
                            }
                        }
                    )
                }

                item {
                    val nfcStatus = when {
                        !optState.hasNfcHardware -> FeatureStatus.UNAVAILABLE_HARDWARE
                        optState.isNfcEnabled -> FeatureStatus.ACTIVE
                        !shizukuStatus.isReady -> FeatureStatus.REQUIRES_SHIZUKU
                        else -> FeatureStatus.OFF
                    }
                    BotGlassCard {
                        SectionHeader(
                            title = "NFC Off",
                            subtitle = if (optState.hasNfcHardware) {
                                if (optState.isNfcEnabled) "Chip NFC ligado" else "Chip NFC desligado"
                            } else {
                                "Indisponível — Seu aparelho não possui NFC"
                            },
                            icon = Icons.Filled.Nfc,
                            trailing = { FeatureStatusBadge(nfcStatus) }
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = if (optState.hasNfcHardware) {
                                "Desativa o leitor NFC durante sessões de jogo via Shizuku ou abre as configurações de NFC."
                            } else {
                                "NfcAdapter.getDefaultAdapter retornou nulo: não existe hardware NFC neste aparelho."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        if (optState.hasNfcHardware) {
                            Spacer(Modifier.height(10.dp))
                            NeonSecondaryButton(
                                text = if (optState.isNfcEnabled) "DESLIGAR NFC" else "ABRIR AJUSTES NFC",
                                icon = Icons.Filled.Nfc,
                                onClick = { onToggleNfc(!optState.isNfcEnabled) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            SystemFilter.THERMAL_POWER -> {
                item {
                    val t = optState.thermalInfo
                    val tempStr = t.temperatureC?.let { String.format(java.util.Locale.US, "%.1f °C", it) }
                        ?: "Indisponível no hardware"
                    BotGlassCard(highlightBorder = t.isThermalThrottling) {
                        SectionHeader(
                            title = "CALOR E ENERGIA EM TEMPO REAL",
                            subtitle = t.thermalStatusLabel,
                            icon = Icons.Filled.Thermostat,
                            trailing = {
                                if (t.isThermalThrottling) {
                                    StatusPill("Throttling", StatusWarn, StatusWarnBg)
                                } else {
                                    StatusPill("Estável", StatusOk, StatusOkBg)
                                }
                            }
                        )
                        Spacer(Modifier.height(10.dp))
                        TelemetrySpecRow("Temperatura da Bateria", tempStr)
                        TelemetrySpecRow("Estado Térmico OS", t.thermalStatusLabel)
                        TelemetrySpecRow("Economia de Bateria", if (t.isPowerSaveMode) "Ativada" else "Desativada")
                        TelemetrySpecRow(
                            "Tensão / Corrente",
                            "${telemetry.battery.voltageMv?.let { "${it} mV" } ?: "N/D"} • ${telemetry.battery.currentNowMa?.let { "${it} mA" } ?: "N/D"}",
                            showDivider = false
                        )
                    }
                }

                item {
                    val shieldStatus = when {
                        optState.thermalShieldEnabled -> FeatureStatus.ACTIVE
                        !optState.hasWriteSettings -> FeatureStatus.REQUIRES_PERMISSION
                        else -> FeatureStatus.OFF
                    }
                    OptimizationToggleCard(
                        title = "Escudo Térmico Automático (>39°C)",
                        description = "Reduz o brilho automaticamente quando a bateria ultrapassa 39°C e restaura ao esfriar.",
                        icon = Icons.Filled.Thermostat,
                        checked = optState.thermalShieldEnabled,
                        status = shieldStatus,
                        onCheckedChange = onToggleThermalShield
                    )
                }

                item {
                    NeonSecondaryButton(
                        text = "ABRIR ECONOMIA DE BATERIA DO ANDROID",
                        icon = Icons.Filled.BatterySaver,
                        onClick = { onOpenSystemIntent(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            SystemFilter.CPU_CLEANER -> {
                item {
                    val res = optState.lastRamCleanResult
                    BotGlassCard(highlightBorder = true) {
                        SectionHeader(
                            title = "MEMÓRIA DE RESERVA (LIMPEZA DE RAM)",
                            subtitle = "Disponível agora: ${Formatters.formatBytes(telemetry.ram.availableBytes)}",
                            icon = Icons.Filled.CleaningServices
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Executa ActivityManager.killBackgroundProcesses nos pacotes permitidos e limpa o cache interno da aplicação.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        if (res != null) {
                            Spacer(Modifier.height(10.dp))
                            TelemetrySpecRow("RAM Livre Antes", Formatters.formatBytes(res.availableBeforeBytes))
                            TelemetrySpecRow("RAM Livre Depois", Formatters.formatBytes(res.availableAfterBytes), StatusOk)
                            TelemetrySpecRow("Saldo Liberado", Formatters.formatBytes(res.freedBytes), NeonRed)
                            TelemetrySpecRow("Apps sinalizados / Cache", "${res.processesKilledHint} pacotes • ${Formatters.formatBytes(res.cacheClearedBytes)}", showDivider = false)
                        }
                        Spacer(Modifier.height(12.dp))
                        NeonPrimaryButton(
                            text = if (optState.isCleaningRam) "LIMPANDO RAM..." else "LIMPAR MEMÓRIA DE RESERVA",
                            icon = Icons.Filled.CleaningServices,
                            onClick = onCleanRam,
                            enabled = !optState.isCleaningRam,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("clean_ram_button")
                        )
                    }
                }

                item {
                    BotGlassCard {
                        SectionHeader(
                            title = "APPS INSTALADOS (${optState.installedApps.size})",
                            subtitle = if (shizukuStatus.isReady) {
                                "Forçar parada e congelar via Shizuku ativos"
                            } else {
                                "Abre detalhes nativos ou use Shizuku para congelar"
                            },
                            icon = Icons.Filled.StopCircle,
                            trailing = {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = "Recarregar lista",
                                    tint = NeonRed
                                )
                            }
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = appSearch,
                            onValueChange = { appSearch = it },
                            placeholder = { Text("Filtrar aplicativo por nome ou pacote...", color = TextMuted) },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = NeonRed) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonRedBorder,
                                unfocusedBorderColor = SubtleBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                items(filteredApps, key = { it.packageName }) { app ->
                    BotGlassCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = app.appName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = app.packageName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                            StatusPill(
                                label = if (app.isEnabled) "Ativo" else "Congelado",
                                fg = if (app.isEnabled) StatusOk else StatusWarn,
                                bg = if (app.isEnabled) StatusOkBg else StatusWarnBg
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onForceStopApp(app.packageName) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Forçar Parada", color = TextPrimary)
                            }
                            OutlinedButton(
                                onClick = { onToggleFreezeApp(app.packageName, app.isEnabled) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (app.isEnabled) "Congelar" else "Reativar",
                                    color = NeonRed
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
