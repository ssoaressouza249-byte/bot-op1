package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core BOT OP1 Deep Obsidian & Neon Crimson Palette
val BgPureBlack = Color(0xFF050505)
val SurfaceCarbon = Color(0xFF0C0C0F)
val SurfaceGlass = Color(0xD9121217)
val SurfaceElevated = Color(0xFF191920)
val SurfaceHighlight = Color(0xFF23232C)

val NeonRed = Color(0xFFFF1E42)
val DeepCrimson = Color(0xFFB00020)
val NeonRedBright = Color(0xFFFF4D6B)
val NeonRedSoft = Color(0x26FF1E42)
val NeonRedBorder = Color(0x55FF1E42)
val SubtleBorder = Color(0xFF262630)

val TextPrimary = Color(0xFFF5F5F7)
val TextSecondary = Color(0xFFB0B0BD)
val TextMuted = Color(0xFF727280)

// Diagnostic & Telemetry Semantic Colors
val StatusOk = Color(0xFF00E676)
val StatusOkBg = Color(0x2200E676)
val StatusWarn = Color(0xFFFFAB00)
val StatusWarnBg = Color(0x22FFAB00)
val StatusCritical = Color(0xFFFF1744)
val StatusCriticalBg = Color(0x26FF1744)
val StatusRestricted = Color(0xFF90A4AE)
val StatusRestrictedBg = Color(0x2290A4AE)
val TelemetryCyan = Color(0xFF00E5FF)
