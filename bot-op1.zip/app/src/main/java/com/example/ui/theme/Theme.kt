package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.dp

data class BotThemeExtras(
    val highGlowMode: Boolean = true
)

val LocalBotThemeExtras = staticCompositionLocalOf { BotThemeExtras() }

private val BotOp1DarkColorScheme = darkColorScheme(
    primary = NeonRed,
    onPrimary = TextPrimary,
    primaryContainer = DeepCrimson,
    onPrimaryContainer = TextPrimary,
    secondary = DeepCrimson,
    onSecondary = TextPrimary,
    secondaryContainer = SurfaceElevated,
    onSecondaryContainer = TextPrimary,
    tertiary = NeonRedBright,
    onTertiary = BgPureBlack,
    background = BgPureBlack,
    onBackground = TextPrimary,
    surface = SurfaceCarbon,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = NeonRedBorder,
    outlineVariant = SubtleBorder,
    error = NeonRed,
    onError = TextPrimary
)

val BotShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun BotOp1Theme(
    highGlowMode: Boolean = true,
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalBotThemeExtras provides BotThemeExtras(highGlowMode)) {
        MaterialTheme(
            colorScheme = BotOp1DarkColorScheme,
            typography = BotTypography,
            shapes = BotShapes,
            content = content
        )
    }
}
