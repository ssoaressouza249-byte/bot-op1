package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.collector.SystemDiagnosticEngine
import com.example.data.collector.SystemTelemetryCollector
import com.example.data.model.AppSettings
import com.example.data.model.BatteryPoint
import com.example.data.model.CpuPoint
import com.example.data.model.RamPoint
import com.example.data.model.StoragePoint
import com.example.data.model.SystemTelemetryState
import com.example.data.preferences.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class BotOp1ViewModel(application: Application) : AndroidViewModel(application) {

    private val collector = SystemTelemetryCollector(application.applicationContext)
    private val settingsRepo = SettingsRepository(application.applicationContext)
    private val collectMutex = Mutex()

    private val _telemetry = MutableStateFlow(SystemTelemetryState())
    val telemetry: StateFlow<SystemTelemetryState> = _telemetry.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettings()
        )

    private var saveCounter = 0

    init {
        viewModelScope.launch {
            val (savedRam, savedStorage, savedBattery) = withContext(Dispatchers.IO) {
                settingsRepo.loadHistories()
            }
            _telemetry.update {
                it.copy(
                    ramHistory = savedRam,
                    storageHistory = savedStorage,
                    batteryHistory = savedBattery
                )
            }
            collectSnapshot(forceGpu = true, runDiagnostic = true, persistNow = true)

            settingsRepo.settingsFlow.collectLatest { currentSettings ->
                while (currentSettings.autoRefresh) {
                    delay(currentSettings.refreshIntervalSec * 1000L)
                    collectSnapshot(forceGpu = false, runDiagnostic = false, persistNow = false)
                }
            }
        }
    }

    fun refreshNow() {
        viewModelScope.launch {
            collectSnapshot(forceGpu = true, runDiagnostic = false, persistNow = true)
        }
    }

    fun runFullDiagnostic(onComplete: (() -> Unit)? = null) {
        viewModelScope.launch {
            if (_telemetry.value.isScanningDiagnostic) return@launch
            _telemetry.update {
                it.copy(
                    isScanningDiagnostic = true,
                    scanProgress = 0.08f,
                    scanStepLabel = "Inicializando varredura de hardware..."
                )
            }

            delay(180)
            _telemetry.update { it.copy(scanProgress = 0.25f, scanStepLabel = "Auditando Memória RAM e Heap ART...") }
            val ram = withContext(Dispatchers.IO) { collector.collectRam() }

            delay(160)
            _telemetry.update { it.copy(scanProgress = 0.42f, scanStepLabel = "Analisando núcleos lógicos e arquitetura CPU...") }
            val cpu = withContext(Dispatchers.IO) { collector.collectCpu() }

            delay(160)
            _telemetry.update { it.copy(scanProgress = 0.58f, scanStepLabel = "Sondando GPU OpenGL ES / EGL...") }
            val gpu = withContext(Dispatchers.Default) { collector.collectGpu(forceRefresh = true) }

            delay(160)
            _telemetry.update { it.copy(scanProgress = 0.74f, scanStepLabel = "Verificando partição /data e cotas de armazenamento...") }
            val storage = withContext(Dispatchers.IO) { collector.collectStorage() }

            delay(160)
            _telemetry.update { it.copy(scanProgress = 0.88f, scanStepLabel = "Lendo controlador de bateria, tela e sensores...") }
            val battery = withContext(Dispatchers.IO) { collector.collectBattery() }
            val display = withContext(Dispatchers.Main) { collector.collectDisplay() }
            val device = withContext(Dispatchers.IO) { collector.collectDeviceInfo() }

            val report = SystemDiagnosticEngine.analyze(
                ram = ram,
                cpu = cpu,
                gpu = gpu,
                storage = storage,
                battery = battery,
                display = display,
                device = device
            )

            val now = System.currentTimeMillis()
            val updated = applySnapshotToState(
                now = now,
                ram = ram,
                cpu = cpu,
                gpu = gpu,
                storage = storage,
                battery = battery,
                display = display,
                device = device,
                report = report
            )
            _telemetry.value = updated.copy(
                isScanningDiagnostic = false,
                scanProgress = 1f,
                scanStepLabel = "Diagnóstico concluído"
            )
            withContext(Dispatchers.IO) {
                settingsRepo.saveHistories(
                    updated.ramHistory,
                    updated.storageHistory,
                    updated.batteryHistory
                )
            }
            onComplete?.invoke()
        }
    }

    fun setAutoRefresh(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setAutoRefresh(enabled) }
    }

    fun setRefreshInterval(seconds: Int) {
        viewModelScope.launch { settingsRepo.setRefreshIntervalSec(seconds) }
    }

    fun setHighGlowMode(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setHighGlowMode(enabled) }
    }

    fun clearLocalHistory() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                settingsRepo.clearLocalHistory()
            }
            _telemetry.update {
                it.copy(
                    ramHistory = emptyList(),
                    cpuHistory = emptyList(),
                    storageHistory = emptyList(),
                    batteryHistory = emptyList()
                )
            }
        }
    }

    private suspend fun collectSnapshot(
        forceGpu: Boolean,
        runDiagnostic: Boolean,
        persistNow: Boolean
    ) {
        collectMutex.withLock {
            _telemetry.update { it.copy(isRefreshing = true) }
            val ram = withContext(Dispatchers.IO) { collector.collectRam() }
            val cpu = withContext(Dispatchers.IO) { collector.collectCpu() }
            val gpu = if (forceGpu || _telemetry.value.gpu.renderer == null) {
                withContext(Dispatchers.Default) { collector.collectGpu(forceRefresh = forceGpu) }
            } else {
                _telemetry.value.gpu
            }
            val storage = withContext(Dispatchers.IO) { collector.collectStorage() }
            val battery = withContext(Dispatchers.IO) { collector.collectBattery() }
            val display = withContext(Dispatchers.Main) { collector.collectDisplay() }
            val device = withContext(Dispatchers.IO) { collector.collectDeviceInfo() }

            val report = if (runDiagnostic || _telemetry.value.diagnosticReport == null) {
                SystemDiagnosticEngine.analyze(ram, cpu, gpu, storage, battery, display, device)
            } else {
                _telemetry.value.diagnosticReport
            }

            val now = System.currentTimeMillis()
            val updated = applySnapshotToState(
                now = now,
                ram = ram,
                cpu = cpu,
                gpu = gpu,
                storage = storage,
                battery = battery,
                display = display,
                device = device,
                report = report
            )
            _telemetry.value = updated.copy(isRefreshing = false)

            saveCounter++
            if (persistNow || saveCounter % 3 == 0) {
                withContext(Dispatchers.IO) {
                    settingsRepo.saveHistories(
                        updated.ramHistory,
                        updated.storageHistory,
                        updated.batteryHistory
                    )
                }
            }
        }
    }

    private fun applySnapshotToState(
        now: Long,
        ram: com.example.data.model.RamInfo,
        cpu: com.example.data.model.CpuInfo,
        gpu: com.example.data.model.GpuInfo,
        storage: com.example.data.model.StorageInfo,
        battery: com.example.data.model.BatteryInfo,
        display: com.example.data.model.DisplayInfo,
        device: com.example.data.model.DeviceFullInfo,
        report: com.example.data.model.DiagnosticReport?
    ): SystemTelemetryState {
        val prev = _telemetry.value

        val newRamHistory = if (ram.totalBytes > 0L) {
            (prev.ramHistory + RamPoint(
                timestampMs = now,
                usedMb = ram.usedBytes / (1024L * 1024L),
                totalMb = ram.totalBytes / (1024L * 1024L),
                appHeapUsedMb = ram.jvmUsedBytes / (1024L * 1024L)
            )).takeLast(30)
        } else prev.ramHistory

        val newCpuHistory = if (cpu.processCpuPercent != null) {
            (prev.cpuHistory + CpuPoint(
                timestampMs = now,
                processCpuPercent = cpu.processCpuPercent
            )).takeLast(30)
        } else prev.cpuHistory

        val newStorageHistory = if (storage.internalTotalBytes > 0L) {
            (prev.storageHistory + StoragePoint(
                timestampMs = now,
                usedBytes = storage.internalUsedBytes,
                totalBytes = storage.internalTotalBytes
            )).takeLast(24)
        } else prev.storageHistory

        val newBatteryHistory = if (battery.levelPercent != null) {
            (prev.batteryHistory + BatteryPoint(
                timestampMs = now,
                levelPercent = battery.levelPercent,
                isCharging = battery.isCharging
            )).takeLast(30)
        } else prev.batteryHistory

        return prev.copy(
            ram = ram,
            cpu = cpu,
            gpu = gpu,
            storage = storage,
            battery = battery,
            display = display,
            device = device,
            ramHistory = newRamHistory,
            cpuHistory = newCpuHistory,
            storageHistory = newStorageHistory,
            batteryHistory = newBatteryHistory,
            diagnosticReport = report,
            lastUpdatedMs = now
        )
    }
}
