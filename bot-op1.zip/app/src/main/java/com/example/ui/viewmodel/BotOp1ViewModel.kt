package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.collector.ActionOutcome
import com.example.data.collector.AndroidOptimizationEngine
import com.example.data.collector.SystemDiagnosticEngine
import com.example.data.collector.SystemTelemetryCollector
import com.example.data.model.AppSettings
import com.example.data.model.BatteryPoint
import com.example.data.model.CpuPoint
import com.example.data.model.DpiCountdownState
import com.example.data.model.OptimizationState
import com.example.data.model.RamPoint
import com.example.data.model.StoragePoint
import com.example.data.model.SystemTelemetryState
import com.example.data.preferences.SettingsRepository
import com.example.service.BotNotificationEventBus
import com.example.service.OptimizationNotificationManager
import com.example.shizuku.ShizukuBridge
import com.example.shizuku.ShizukuStatus
import com.example.util.Formatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

sealed interface BotUiEvent {
    data class ShowMessage(val message: String) : BotUiEvent
    data class LaunchSystemIntent(val intent: Intent) : BotUiEvent
}

class BotOp1ViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val collector = SystemTelemetryCollector(appContext)
    private val settingsRepo = SettingsRepository(appContext)
    val shizukuBridge = ShizukuBridge(appContext)
    private val optimizer = AndroidOptimizationEngine(appContext, shizukuBridge)
    private val collectMutex = Mutex()

    private val _telemetry = MutableStateFlow(SystemTelemetryState())
    val telemetry: StateFlow<SystemTelemetryState> = _telemetry.asStateFlow()

    private val _optimization = MutableStateFlow(OptimizationState())
    val optimization: StateFlow<OptimizationState> = _optimization.asStateFlow()

    val shizukuStatus: StateFlow<ShizukuStatus> = shizukuBridge.status

    val settings: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettings()
        )

    private val _events = MutableSharedFlow<BotUiEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<BotUiEvent> = _events.asSharedFlow()

    private var saveCounter = 0
    private var savedBrightnessBeforeShield: Pair<Int, Int>? = null
    private var dpiCountdownJob: Job? = null

    init {
        shizukuBridge.registerListeners()
        refreshOptimizationStatus()

        viewModelScope.launch {
            BotNotificationEventBus.disableAllEvents.collect {
                disableAllOptimizations()
            }
        }

        viewModelScope.launch {
            val (savedRam, savedStorage, savedBattery) = withContext(Dispatchers.IO) {
                settingsRepo.loadHistories()
            }
            _telemetry.update {
                it.copy(
                    ramHistory = savedRam,
                    storageHistory = savedStorage,
                    batteryHistory = savedBattery
                )
            }
            collectSnapshot(forceGpu = true, runDiagnostic = true, persistNow = true)
            runPingTest()

            settingsRepo.settingsFlow.collectLatest { currentSettings ->
                while (currentSettings.autoRefresh) {
                    delay(currentSettings.refreshIntervalSec * 1000L)
                    collectSnapshot(forceGpu = false, runDiagnostic = false, persistNow = false)
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        dpiCountdownJob?.cancel()
        shizukuBridge.unregisterListeners()
    }

    fun refreshOptimizationStatus() {
        shizukuBridge.refreshStatus()
        val dpi = optimizer.readCurrentDpi()
        val (hasBt, btOn, btAudio) = optimizer.readBluetoothHardwareState()
        val (hasNfc, nfcOn) = optimizer.readNfcHardwareState()
        val thermal = optimizer.collectThermalStatus()
        val engine = optimizer.detectNativeGameEngine()

        _optimization.update { cur ->
            val origDpi = if (cur.originalDpi == 420 && dpi != 420 && cur.currentDpi == 420) dpi else cur.originalDpi
            val selDpi = if (cur.selectedDpi == 420 && dpi != 420) dpi.coerceIn(280, 550) else cur.selectedDpi
            cur.copy(
                nativeGameEngine = engine,
                hasWriteSettings = optimizer.hasWriteSettings(),
                hasDndPolicyAccess = optimizer.hasDndAccess(),
                hasBluetoothPermission = optimizer.hasBluetoothPermission(),
                hasNotificationPermission = optimizer.hasNotificationPermission(),
                hasBluetoothHardware = hasBt,
                isBluetoothEnabled = btOn,
                hasBluetoothAudioConnected = btAudio,
                hasNfcHardware = hasNfc,
                isNfcEnabled = nfcOn,
                autoDndEnabled = optimizer.isDndActive(),
                rotationLockedEnabled = optimizer.isRotationLocked(),
                noVibrationEnabled = optimizer.isVibrationDisabled(),
                zeroAnimationEnabled = optimizer.readZeroAnimationEnabled(),
                captivePortalDisabled = optimizer.readCaptivePortalDisabled(),
                longPressTimeoutMs = optimizer.readLongPressTimeout(),
                pointerSpeed = optimizer.readPointerSpeed(),
                sensitiveTouchEnabled = optimizer.readTouchSensitivity(),
                currentDpi = dpi,
                originalDpi = origDpi,
                selectedDpi = selDpi,
                thermalInfo = thermal.copy(shieldReducedBrightness = savedBrightnessBeforeShield != null)
            )
        }
        evaluateThermalShield()
        syncNotification()
    }

    fun toggleProfileEnabled(enable: Boolean) {
        if (!enable) {
            disableAllOptimizations()
        } else {
            _optimization.update { it.copy(profileEnabled = true) }
            syncNotification()
            _events.tryEmit(BotUiEvent.ShowMessage("Perfil BOT OP1 ativado. Ajuste os módulos desejados."))
        }
    }

    fun disableAllOptimizations() {
        viewModelScope.launch {
            val cur = _optimization.value
            if (cur.autoDndEnabled) optimizer.setDndEnabled(false)
            if (cur.rotationLockedEnabled) optimizer.setRotationLocked(false)
            if (cur.noVibrationEnabled) optimizer.setNoVibration(false)
            if (cur.zeroAnimationEnabled && shizukuStatus.value.isReady) optimizer.setZeroAnimation(false)
            if (cur.noPopupsEnabled && shizukuStatus.value.isReady) optimizer.setNoPopupsEnabled(false)
            if (cur.captivePortalDisabled && shizukuStatus.value.isReady) optimizer.setCaptivePortalDisabled(false)
            if (cur.sensitiveTouchEnabled && shizukuStatus.value.isReady) optimizer.setTouchSensitivity(false)
            if (cur.pointerSpeed != 0) optimizer.setPointerSpeed(0)
            if (cur.currentDpi != cur.originalDpi && shizukuStatus.value.isReady) optimizer.resetDpi()

            restoreThermalBrightnessIfNeeded()

            _optimization.update {
                it.copy(
                    profileEnabled = false,
                    autoDndEnabled = false,
                    noPopupsEnabled = false,
                    thermalShieldEnabled = false,
                    zeroAnimationEnabled = false,
                    rotationLockedEnabled = false,
                    noVibrationEnabled = false,
                    sensitiveTouchEnabled = false,
                    captivePortalDisabled = false,
                    restrictBackgroundDataEnabled = false,
                    bluetoothAutoOffInGame = false,
                    pointerSpeed = 0,
                    longPressTimeoutMs = null
                )
            }
            OptimizationNotificationManager.cancel(appContext)
            refreshOptimizationStatus()
            _events.tryEmit(BotUiEvent.ShowMessage("Todas as otimizações BOT OP1 foram desativadas."))
        }
    }

    fun launchNativeGameEngine() {
        val pkg = _optimization.value.nativeGameEngine.packageName ?: return
        if (!optimizer.launchPackage(pkg)) {
            _events.tryEmit(BotUiEvent.ShowMessage("Não foi possível abrir o motor de jogos nativo."))
        }
    }

    fun toggleAutoDnd(enable: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.setDndEnabled(enable)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        autoDndEnabled = enable,
                        profileEnabled = it.profileEnabled || enable
                    )
                }
                syncNotification()
            }
        }
    }

    fun toggleNoPopups(enable: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.setNoPopupsEnabled(enable)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        noPopupsEnabled = enable,
                        profileEnabled = it.profileEnabled || enable
                    )
                }
                syncNotification()
            }
        }
    }

    fun toggleThermalShield(enable: Boolean) {
        viewModelScope.launch {
            if (enable && !optimizer.hasWriteSettings()) {
                val intent = android.content.Intent(
                    android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS,
                    android.net.Uri.parse("package:${appContext.packageName}")
                )
                _events.tryEmit(BotUiEvent.ShowMessage("Permita 'Modificar configurações do sistema' para o Escudo Térmico."))
                _events.tryEmit(BotUiEvent.LaunchSystemIntent(intent))
                return@launch
            }
            if (!enable) {
                restoreThermalBrightnessIfNeeded()
            }
            _optimization.update {
                it.copy(
                    thermalShieldEnabled = enable,
                    profileEnabled = it.profileEnabled || enable
                )
            }
            evaluateThermalShield()
            syncNotification()
            _events.tryEmit(
                BotUiEvent.ShowMessage(
                    if (enable) "Escudo Térmico ativo (monitorando limite de 39°C)."
                    else "Escudo Térmico desativado."
                )
            )
        }
    }

    fun toggleZeroAnimation(enable: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.setZeroAnimation(enable)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        zeroAnimationEnabled = enable,
                        profileEnabled = it.profileEnabled || enable
                    )
                }
                syncNotification()
            }
        }
    }

    fun toggleRotationLocked(enable: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.setRotationLocked(enable)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        rotationLockedEnabled = enable,
                        profileEnabled = it.profileEnabled || enable
                    )
                }
                syncNotification()
            }
        }
    }

    fun toggleNoVibration(enable: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.setNoVibration(enable)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        noVibrationEnabled = enable,
                        profileEnabled = it.profileEnabled || enable
                    )
                }
                syncNotification()
            }
        }
    }

    fun updateSelectedDpi(dpi: Int) {
        _optimization.update { it.copy(selectedDpi = dpi.coerceIn(280, 550)) }
    }

    fun applySelectedDpi() {
        viewModelScope.launch {
            val currentDpi = optimizer.readCurrentDpi()
            val target = _optimization.value.selectedDpi
            val outcome = optimizer.applyCustomDpi(target)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        currentDpi = target,
                        profileEnabled = true,
                        dpiCountdown = DpiCountdownState(
                            isActive = true,
                            originalDpi = currentDpi,
                            appliedDpi = target,
                            secondsRemaining = 15
                        )
                    )
                }
                syncNotification()
                startDpiSafetyCountdown(currentDpi)
            }
        }
    }

    private fun startDpiSafetyCountdown(originalDpi: Int) {
        dpiCountdownJob?.cancel()
        dpiCountdownJob = viewModelScope.launch {
            for (sec in 15 downTo 1) {
                _optimization.update {
                    it.copy(dpiCountdown = it.dpiCountdown.copy(secondsRemaining = sec))
                }
                delay(1000L)
            }
            revertDpiInternal(originalDpi)
        }
    }

    fun confirmKeepDpi() {
        dpiCountdownJob?.cancel()
        _optimization.update {
            it.copy(dpiCountdown = DpiCountdownState(isActive = false))
        }
        _events.tryEmit(BotUiEvent.ShowMessage("DPI ${_optimization.value.currentDpi} mantido com sucesso."))
    }

    fun revertDpi() {
        dpiCountdownJob?.cancel()
        viewModelScope.launch {
            revertDpiInternal(_optimization.value.dpiCountdown.originalDpi.takeIf { it > 0 } ?: _optimization.value.originalDpi)
        }
    }

    private suspend fun revertDpiInternal(originalDpi: Int) {
        val outcome = optimizer.resetDpi()
        _optimization.update {
            it.copy(
                currentDpi = originalDpi,
                selectedDpi = originalDpi.coerceIn(280, 550),
                dpiCountdown = DpiCountdownState(isActive = false)
            )
        }
        syncNotification()
        if (outcome.success) {
            _events.tryEmit(BotUiEvent.ShowMessage("DPI revertido por segurança para $originalDpi."))
        }
    }

    fun selectLongPressTimeout(ms: Int?) {
        viewModelScope.launch {
            val outcome = optimizer.setLongPressTimeout(ms)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        longPressTimeoutMs = ms,
                        profileEnabled = it.profileEnabled || ms != null
                    )
                }
                syncNotification()
            }
        }
    }

    fun selectPointerSpeed(speed: Int) {
        viewModelScope.launch {
            val outcome = optimizer.setPointerSpeed(speed)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        pointerSpeed = speed,
                        profileEnabled = it.profileEnabled || speed != 0
                    )
                }
                syncNotification()
            }
        }
    }

    fun toggleSensitiveTouch(enable: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.setTouchSensitivity(enable)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        sensitiveTouchEnabled = enable,
                        profileEnabled = it.profileEnabled || enable
                    )
                }
                syncNotification()
            }
        }
    }

    fun runPingTest() {
        viewModelScope.launch {
            _optimization.update {
                it.copy(latencyInfo = it.latencyInfo.copy(isTesting = true))
            }
            val result = optimizer.measureNetworkLatency()
            _optimization.update { it.copy(latencyInfo = result.copy(isTesting = false)) }
        }
    }

    fun toggleCaptivePortalDisabled(disable: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.setCaptivePortalDisabled(disable)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        captivePortalDisabled = disable,
                        profileEnabled = it.profileEnabled || disable
                    )
                }
                syncNotification()
            }
        }
    }

    fun toggleBackgroundDataRestriction(enable: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.toggleBackgroundDataSaver(enable)
            handleOutcome(outcome)
            if (outcome.success) {
                _optimization.update {
                    it.copy(
                        restrictBackgroundDataEnabled = enable,
                        profileEnabled = it.profileEnabled || enable
                    )
                }
                syncNotification()
                runPingTest()
            }
        }
    }

    fun triggerBluetoothOffInGame(enable: Boolean) {
        viewModelScope.launch {
            if (!enable) {
                _optimization.update { it.copy(bluetoothAutoOffInGame = false) }
                syncNotification()
                return@launch
            }
            val outcome = optimizer.disableBluetoothIfNoAudio()
            handleOutcome(outcome)
            if (outcome.success) {
                val (hasBt, btOn, btAudio) = optimizer.readBluetoothHardwareState()
                _optimization.update {
                    it.copy(
                        bluetoothAutoOffInGame = true,
                        hasBluetoothHardware = hasBt,
                        isBluetoothEnabled = btOn,
                        hasBluetoothAudioConnected = btAudio,
                        profileEnabled = true
                    )
                }
                syncNotification()
            }
        }
    }

    fun toggleNfcState(enable: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.toggleNfc(enable)
            handleOutcome(outcome)
            val (hasNfc, nfcOn) = optimizer.readNfcHardwareState()
            _optimization.update {
                it.copy(hasNfcHardware = hasNfc, isNfcEnabled = nfcOn)
            }
        }
    }

    fun cleanRamNow() {
        viewModelScope.launch {
            if (_optimization.value.isCleaningRam) return@launch
            _optimization.update { it.copy(isCleaningRam = true) }
            val result = optimizer.cleanRamAndCache()
            _optimization.update {
                it.copy(
                    isCleaningRam = false,
                    lastRamCleanResult = result
                )
            }
            collectSnapshot(forceGpu = false, runDiagnostic = false, persistNow = true)
            _events.tryEmit(
                BotUiEvent.ShowMessage(
                    "Limpeza concluída: ${Formatters.formatBytes(result.freedBytes)} liberados na RAM disponível."
                )
            )
        }
    }

    fun loadInstalledAppsIfNeeded(force: Boolean = false) {
        val current = _optimization.value
        if (!force && current.installedApps.isNotEmpty()) return
        viewModelScope.launch {
            _optimization.update { it.copy(isLoadingApps = true) }
            val apps = optimizer.loadInstalledApps()
            _optimization.update { it.copy(installedApps = apps, isLoadingApps = false) }
        }
    }

    fun forceStopApp(packageName: String) {
        viewModelScope.launch {
            val outcome = optimizer.forceStopApp(packageName)
            handleOutcome(outcome)
        }
    }

    fun toggleFreezeApp(packageName: String, freeze: Boolean) {
        viewModelScope.launch {
            val outcome = optimizer.setAppFrozen(packageName, freeze)
            handleOutcome(outcome)
            if (outcome.success) {
                loadInstalledAppsIfNeeded(force = true)
            }
        }
    }

    fun requestShizukuPermission() {
        val sent = shizukuBridge.requestPermission()
        if (!sent) {
            _events.tryEmit(BotUiEvent.ShowMessage("Shizuku não está em execução. Inicie o serviço Shizuku primeiro."))
        } else {
            refreshOptimizationStatus()
        }
    }

    fun openShizukuApp() {
        if (!shizukuBridge.openShizukuApp()) {
            _events.tryEmit(BotUiEvent.ShowMessage("Aplicativo Shizuku (moe.shizuku.privileged.api) não instalado."))
        }
    }

    fun testShizukuCommand() {
        viewModelScope.launch {
            val res = shizukuBridge.runCommand("id")
            _events.tryEmit(
                BotUiEvent.ShowMessage(
                    if (res.success) "Shizuku ativo: ${res.output}"
                    else "Shizuku: ${res.output}"
                )
            )
            refreshOptimizationStatus()
        }
    }

    fun launchSystemIntent(intent: Intent) {
        _events.tryEmit(BotUiEvent.LaunchSystemIntent(intent))
    }

    private fun handleOutcome(outcome: ActionOutcome) {
        _events.tryEmit(BotUiEvent.ShowMessage(outcome.message))
        if (outcome.requiresIntent != null) {
            _events.tryEmit(BotUiEvent.LaunchSystemIntent(outcome.requiresIntent))
        }
    }

    private fun evaluateThermalShield() {
        val cur = _optimization.value
        val thermal = optimizer.collectThermalStatus()
        val temp = thermal.temperatureC
        if (cur.thermalShieldEnabled && temp != null && temp > 39.0f) {
            if (savedBrightnessBeforeShield == null) {
                savedBrightnessBeforeShield = optimizer.readCurrentScreenBrightness()
            }
            val reduced = optimizer.applyThermalBrightnessReduction(reduce = true)
            _optimization.update {
                it.copy(thermalInfo = thermal.copy(shieldReducedBrightness = reduced))
            }
        } else if (!cur.thermalShieldEnabled || (temp != null && temp <= 38.0f)) {
            restoreThermalBrightnessIfNeeded()
            _optimization.update {
                it.copy(thermalInfo = thermal.copy(shieldReducedBrightness = false))
            }
        } else {
            _optimization.update {
                it.copy(thermalInfo = thermal.copy(shieldReducedBrightness = savedBrightnessBeforeShield != null))
            }
        }
    }

    private fun restoreThermalBrightnessIfNeeded() {
        val saved = savedBrightnessBeforeShield ?: return
        optimizer.applyThermalBrightnessReduction(
            reduce = false,
            restoreMode = saved.first,
            restoreLevel = saved.second
        )
        savedBrightnessBeforeShield = null
    }

    private fun syncNotification() {
        val opt = _optimization.value
        val activeCount = opt.activeFeatureCount
        val shouldShow = opt.profileEnabled && activeCount > 0
        OptimizationNotificationManager.updateNotification(
            context = appContext,
            profileActive = shouldShow,
            activeCount = activeCount
        )
    }

    fun refreshNow() {
        viewModelScope.launch {
            collectSnapshot(forceGpu = true, runDiagnostic = false, persistNow = true)
            refreshOptimizationStatus()
        }
    }

    fun runFullDiagnostic(onComplete: (() -> Unit)? = null) {
        viewModelScope.launch {
            if (_telemetry.value.isScanningDiagnostic) return@launch
            _telemetry.update {
                it.copy(
                    isScanningDiagnostic = true,
                    scanProgress = 0.08f,
                    scanStepLabel = "Inicializando varredura de hardware..."
                )
            }

            delay(180)
            _telemetry.update { it.copy(scanProgress = 0.25f, scanStepLabel = "Auditando Memória RAM e Heap ART...") }
            val ram = withContext(Dispatchers.IO) { collector.collectRam() }

            delay(160)
            _telemetry.update { it.copy(scanProgress = 0.42f, scanStepLabel = "Analisando núcleos lógicos e arquitetura CPU...") }
            val cpu = withContext(Dispatchers.IO) { collector.collectCpu() }

            delay(160)
            _telemetry.update { it.copy(scanProgress = 0.58f, scanStepLabel = "Sondando GPU OpenGL ES / EGL...") }
            val gpu = withContext(Dispatchers.Default) { collector.collectGpu(forceRefresh = true) }

            delay(160)
            _telemetry.update { it.copy(scanProgress = 0.74f, scanStepLabel = "Verificando partição /data e cotas de armazenamento...") }
            val storage = withContext(Dispatchers.IO) { collector.collectStorage() }

            delay(160)
            _telemetry.update { it.copy(scanProgress = 0.88f, scanStepLabel = "Lendo controlador de bateria, tela e sensores...") }
            val battery = withContext(Dispatchers.IO) { collector.collectBattery() }
            val display = withContext(Dispatchers.Main) { collector.collectDisplay() }
            val device = withContext(Dispatchers.IO) { collector.collectDeviceInfo() }

            val report = SystemDiagnosticEngine.analyze(
                ram = ram,
                cpu = cpu,
                gpu = gpu,
                storage = storage,
                battery = battery,
                display = display,
                device = device
            )

            val now = System.currentTimeMillis()
            val updated = applySnapshotToState(
                now = now,
                ram = ram,
                cpu = cpu,
                gpu = gpu,
                storage = storage,
                battery = battery,
                display = display,
                device = device,
                report = report
            )
            _telemetry.value = updated.copy(
                isScanningDiagnostic = false,
                scanProgress = 1f,
                scanStepLabel = "Diagnóstico concluído"
            )
            withContext(Dispatchers.IO) {
                settingsRepo.saveHistories(
                    updated.ramHistory,
                    updated.storageHistory,
                    updated.batteryHistory
                )
            }
            onComplete?.invoke()
        }
    }

    fun setAutoRefresh(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setAutoRefresh(enabled) }
    }

    fun setRefreshInterval(seconds: Int) {
        viewModelScope.launch { settingsRepo.setRefreshIntervalSec(seconds) }
    }

    fun setHighGlowMode(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setHighGlowMode(enabled) }
    }

    fun clearLocalHistory() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                settingsRepo.clearLocalHistory()
            }
            _telemetry.update {
                it.copy(
                    ramHistory = emptyList(),
                    cpuHistory = emptyList(),
                    storageHistory = emptyList(),
                    batteryHistory = emptyList()
                )
            }
        }
    }

    private suspend fun collectSnapshot(
        forceGpu: Boolean,
        runDiagnostic: Boolean,
        persistNow: Boolean
    ) {
        collectMutex.withLock {
            _telemetry.update { it.copy(isRefreshing = true) }
            val ram = withContext(Dispatchers.IO) { collector.collectRam() }
            val cpu = withContext(Dispatchers.IO) { collector.collectCpu() }
            val gpu = if (forceGpu || _telemetry.value.gpu.renderer == null) {
                withContext(Dispatchers.Default) { collector.collectGpu(forceRefresh = forceGpu) }
            } else {
                _telemetry.value.gpu
            }
            val storage = withContext(Dispatchers.IO) { collector.collectStorage() }
            val battery = withContext(Dispatchers.IO) { collector.collectBattery() }
            val display = withContext(Dispatchers.Main) { collector.collectDisplay() }
            val device = withContext(Dispatchers.IO) { collector.collectDeviceInfo() }

            val report = if (runDiagnostic || _telemetry.value.diagnosticReport == null) {
                SystemDiagnosticEngine.analyze(ram, cpu, gpu, storage, battery, display, device)
            } else {
                _telemetry.value.diagnosticReport
            }

            val now = System.currentTimeMillis()
            val updated = applySnapshotToState(
                now = now,
                ram = ram,
                cpu = cpu,
                gpu = gpu,
                storage = storage,
                battery = battery,
                display = display,
                device = device,
                report = report
            )
            _telemetry.value = updated.copy(isRefreshing = false)

            evaluateThermalShield()

            saveCounter++
            if (persistNow || saveCounter % 3 == 0) {
                withContext(Dispatchers.IO) {
                    settingsRepo.saveHistories(
                        updated.ramHistory,
                        updated.storageHistory,
                        updated.batteryHistory
                    )
                }
            }
        }
    }

    private fun applySnapshotToState(
        now: Long,
        ram: com.example.data.model.RamInfo,
        cpu: com.example.data.model.CpuInfo,
        gpu: com.example.data.model.GpuInfo,
        storage: com.example.data.model.StorageInfo,
        battery: com.example.data.model.BatteryInfo,
        display: com.example.data.model.DisplayInfo,
        device: com.example.data.model.DeviceFullInfo,
        report: com.example.data.model.DiagnosticReport?
    ): SystemTelemetryState {
        val prev = _telemetry.value

        val newRamHistory = if (ram.totalBytes > 0L) {
            (prev.ramHistory + RamPoint(
                timestampMs = now,
                usedMb = ram.usedBytes / (1024L * 1024L),
                totalMb = ram.totalBytes / (1024L * 1024L),
                appHeapUsedMb = ram.jvmUsedBytes / (1024L * 1024L)
            )).takeLast(30)
        } else prev.ramHistory

        val newCpuHistory = if (cpu.processCpuPercent != null) {
            (prev.cpuHistory + CpuPoint(
                timestampMs = now,
                processCpuPercent = cpu.processCpuPercent
            )).takeLast(30)
        } else prev.cpuHistory

        val newStorageHistory = if (storage.internalTotalBytes > 0L) {
            (prev.storageHistory + StoragePoint(
                timestampMs = now,
                usedBytes = storage.internalUsedBytes,
                totalBytes = storage.internalTotalBytes
            )).takeLast(24)
        } else prev.storageHistory

        val newBatteryHistory = if (battery.levelPercent != null) {
            (prev.batteryHistory + BatteryPoint(
                timestampMs = now,
                levelPercent = battery.levelPercent,
                isCharging = battery.isCharging
            )).takeLast(30)
        } else prev.batteryHistory

        return prev.copy(
            ram = ram,
            cpu = cpu,
            gpu = gpu,
            storage = storage,
            battery = battery,
            display = display,
            device = device,
            ramHistory = newRamHistory,
            cpuHistory = newCpuHistory,
            storageHistory = newStorageHistory,
            batteryHistory = newBatteryHistory,
            diagnosticReport = report,
            lastUpdatedMs = now
        )
    }
}
