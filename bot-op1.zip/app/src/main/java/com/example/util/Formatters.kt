package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

object Formatters {

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0
        val tb = gb * 1024.0
        return when {
            bytes >= tb -> String.format(Locale.US, "%.2f TB", bytes / tb)
            bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
            bytes >= kb -> String.format(Locale.US, "%.0f KB", bytes / kb)
            else -> "$bytes B"
        }
    }

    fun formatMb(mb: Long): String {
        return if (mb >= 1024L) {
            String.format(Locale.US, "%.2f GB", mb / 1024.0)
        } else {
            "$mb MB"
        }
    }

    fun formatKhzToMhzOrGhz(khz: Long?): String {
        if (khz == null || khz <= 0L) return "Restrito"
        val mhz = khz / 1000.0
        return if (mhz >= 1000.0) {
            String.format(Locale.US, "%.2f GHz", mhz / 1000.0)
        } else {
            "${mhz.roundToInt()} MHz"
        }
    }

    fun formatPercent(fraction: Float): String {
        val pct = (fraction.coerceIn(0f, 1f) * 100f)
        return String.format(Locale.US, "%.1f%%", pct)
    }

    fun formatUptime(uptimeMs: Long): String {
        val totalSeconds = (uptimeMs / 1000L).coerceAtLeast(0L)
        val days = totalSeconds / 86400L
        val hours = (totalSeconds % 86400L) / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return when {
            days > 0 -> "${days}d ${hours}h ${minutes}m"
            hours > 0 -> "${hours}h ${minutes}m ${seconds}s"
            else -> "${minutes}m ${seconds}s"
        }
    }

    fun formatChargeTimeRemaining(ms: Long?): String {
        if (ms == null || ms < 0L) return "Indisponível"
        val totalMinutes = ms / 60000L
        val hours = totalMinutes / 60L
        val minutes = totalMinutes % 60L
        return if (hours > 0) "${hours}h ${minutes}m restantes" else "${minutes}m restantes"
    }

    fun formatTimestamp(ms: Long): String {
        if (ms <= 0L) return "--:--:--"
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(ms))
    }
}
