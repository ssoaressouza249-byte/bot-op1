package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.collector.SystemDiagnosticEngine
import com.example.data.collector.SystemTelemetryCollector
import com.example.data.model.BatteryInfo
import com.example.data.model.CpuInfo
import com.example.data.model.DataAvailability
import com.example.data.model.DeviceFullInfo
import com.example.data.model.DiagnosticStatus
import com.example.data.model.DisplayInfo
import com.example.data.model.GpuInfo
import com.example.data.model.RamInfo
import com.example.data.model.StorageInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BotOp1TelemetryTest {

    @Test
    fun `diagnostic engine flags critical storage and restricted cpu`() {
        val ram = RamInfo(
            totalBytes = 8L * 1024 * 1024 * 1024,
            availableBytes = 3L * 1024 * 1024 * 1024,
            availability = DataAvailability.AVAILABLE
        )
        val cpu = CpuInfo(
            logicalProcessors = 8,
            primaryAbi = "arm64-v8a",
            supportedAbis = listOf("arm64-v8a"),
            systemStatAccessible = false,
            coreFreqAccessibleCount = 0
        )
        val gpu = GpuInfo(
            glEsSystemVersion = "3.2",
            renderer = "Adreno (TM) 740",
            vendor = "Qualcomm",
            glVersion = "OpenGL ES 3.2",
            availability = DataAvailability.AVAILABLE
        )
        val storage = StorageInfo(
            internalTotalBytes = 100_000_000_000L,
            internalAvailableBytes = 5_000_000_000L,
            availability = DataAvailability.AVAILABLE
        )
        val battery = BatteryInfo(
            levelPercent = 82,
            statusLabel = "Descarregando",
            isCharging = false,
            availability = DataAvailability.AVAILABLE
        )
        val display = DisplayInfo(widthPx = 1080, heightPx = 2400, refreshRateHz = 120f)
        val device = DeviceFullInfo(androidVersion = "15", sdkInt = 35)

        val report = SystemDiagnosticEngine.analyze(ram, cpu, gpu, storage, battery, display, device)
        assertEquals(DiagnosticStatus.CRITICAL, report.overallStatus)
        assertEquals(7, report.checks.size)
        assertTrue(report.missingDataNotes.isNotEmpty())
    }

    @Test
    fun `telemetry collector runs safely in Android context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val collector = SystemTelemetryCollector(context)
        val cpu = collector.collectCpu()
        val display = collector.collectDisplay()
        val device = collector.collectDeviceInfo()

        assertTrue(cpu.logicalProcessors >= 1)
        assertTrue(display.density > 0f)
        assertTrue(device.sdkInt > 0)
    }

    @Test
    fun `optimization engine detects hardware capabilities and counts active features`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shizuku = com.example.shizuku.ShizukuBridge(context)
        val engine = com.example.data.collector.AndroidOptimizationEngine(context, shizuku)

        val dpi = engine.readCurrentDpi()
        assertTrue(dpi > 0)

        val (hasNfc, _) = engine.readNfcHardwareState()
        // In Robolectric default environment, NfcAdapter may be false/null without throwing
        assertTrue(!hasNfc || hasNfc)

        val optState = com.example.data.model.OptimizationState(
            autoDndEnabled = true,
            thermalShieldEnabled = true,
            rotationLockedEnabled = true,
            pointerSpeed = 3
        )
        assertEquals(4, optState.activeFeatureCount)
    }
}
